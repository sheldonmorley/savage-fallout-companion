// Generated from the Companion's Scavenging Loot tables by build_loot.py. Edit the tables, then rebuild.
export const LOOT = {
 "ammo": {
  "gamma round": {
   "item": "Compendium.fallout-companion.fallout-equipment.Item.reh1qlB6fnUMu0BA",
   "name": "Gamma Round"
  },
  "5.56mm": {
   "item": "Compendium.fallout-companion.fallout-equipment.Item.IXyYqENCm2XR1YPB",
   "name": "5.56mm"
  },
  "shotgun shell": {
   "item": "Compendium.fallout-companion.fallout-equipment.Item.Ti9v7YIvbQOk48dY",
   "name": "Shotgun Shell"
  },
  "mini nuke": {
   "item": "Compendium.fallout-companion.fallout-equipment.Item.zFh0l4sexPQT9N4j",
   "name": "Mini Nuke"
  },
  ".38": {
   "item": "Compendium.fallout-companion.fallout-equipment.Item.cf2lJflhr70DPPJ9",
   "name": ".38"
  },
  "arrow/bolt": {
   "item": "Compendium.fallout-companion.fallout-equipment.Item.iGiW9zg7c1fiAHdK",
   "name": "Arrow/Bolt"
  },
  "2mm ec": {
   "item": "Compendium.fallout-companion.fallout-equipment.Item.nyvNoJXwW5TvJmoV",
   "name": "2mm EC"
  },
  "fusion core": {
   "item": "Compendium.fallout-companion.fallout-equipment.Item.ZEJaFQZ8yfmsvgOT",
   "name": "Fusion Core"
  },
  "fusion cell": {
   "item": "Compendium.fallout-companion.fallout-equipment.Item.W5S0bEDvo1cZei0K",
   "name": "Fusion Cell"
  },
  "railway spike": {
   "item": "Compendium.fallout-companion.fallout-equipment.Item.YTmnnKJQzvePC8n8",
   "name": "Railway Spike"
  },
  ".308": {
   "item": "Compendium.fallout-companion.fallout-equipment.Item.2PFsZ7jc9FtwIYUR",
   "name": ".308"
  },
  "missile": {
   "item": "Compendium.fallout-companion.fallout-equipment.Item.xWqVq0Cr8MtPPgb5",
   "name": "Missile"
  },
  ".44": {
   "item": "Compendium.fallout-companion.fallout-equipment.Item.GH7KHgxGBiO6zJgy",
   "name": ".44"
  },
  ".50": {
   "item": "Compendium.fallout-companion.fallout-equipment.Item.wY7qMi0mheCzP9Is",
   "name": ".50"
  },
  "cryo cell": {
   "item": "Compendium.fallout-companion.fallout-equipment.Item.Gx2vm94d5cYy1uvA",
   "name": "Cryo Cell"
  },
  ".45": {
   "item": "Compendium.fallout-companion.fallout-equipment.Item.nvgUfZmsYTTqSOnh",
   "name": ".45"
  },
  "flamer fuel": {
   "item": "Compendium.fallout-companion.fallout-equipment.Item.v6mgo4NdEZK1kM6p",
   "name": "Flamer Fuel"
  },
  "5mm": {
   "item": "Compendium.fallout-companion.fallout-equipment.Item.HOgsxe8F0lcbElOf",
   "name": "5mm"
  },
  "plasma cartridge": {
   "item": "Compendium.fallout-companion.fallout-equipment.Item.dUQF4jVMhYzorObc",
   "name": "Plasma Cartridge"
  },
  "10mm": {
   "item": "Compendium.fallout-companion.fallout-equipment.Item.qzPdDQnqpEGDFfdC",
   "name": "10mm"
  },
  "flare": {
   "item": "Compendium.fallout-companion.fallout-equipment.Item.yq3y27SrhGf6Wiv9",
   "name": "Flare"
  },
  "syringer dart": {
   "item": "Compendium.fallout-companion.fallout-equipment.Item.lMJHlow78QtoppHh",
   "name": "Syringer Dart"
  }
 },
 "suits": {
  "clubs": [
   {
    "min": 2,
    "max": 5,
    "text": "Roll a d6: 1 Board; 2 Lead Pipe; 3 Rolling Pin; 4 Pool Cue; 5 Tire Iron; 6 2d6 .38 rounds",
    "options": [
     {
      "item": "Compendium.fallout-companion.fallout-weapons.Item.62Fmfxhi0rQTug7L",
      "name": "Board",
      "qty": "1",
      "text": "Board"
     },
     {
      "item": "Compendium.fallout-companion.fallout-weapons.Item.HOo8dHYhhGZ1Ntv3",
      "name": "Lead Pipe",
      "qty": "1",
      "text": "Lead Pipe"
     },
     {
      "item": "Compendium.fallout-companion.fallout-weapons.Item.iRfQosIeHfgf3GiQ",
      "name": "Rolling Pin",
      "qty": "1",
      "text": "Rolling Pin"
     },
     {
      "item": "Compendium.fallout-companion.fallout-weapons.Item.U1dXuqGFY30vMj0v",
      "name": "Pool Cue",
      "qty": "1",
      "text": "Pool Cue"
     },
     {
      "item": "Compendium.fallout-companion.fallout-weapons.Item.Ms7zL7or3H6xCH1I",
      "name": "Tire Iron",
      "qty": "1",
      "text": "Tire Iron"
     },
     {
      "item": "Compendium.fallout-companion.fallout-equipment.Item.cf2lJflhr70DPPJ9",
      "name": ".38",
      "qty": "2d6",
      "text": "2d6 .38 rounds"
     }
    ]
   },
   {
    "min": 6,
    "max": 8,
    "text": "Roll a d6: 1 Pipe Gun; 2 Pipe Revolver; 3 Switchblade; 4 Baseball Bat; 5 2d6 10mm rounds; 6 1d6 Shotgun Shells",
    "options": [
     {
      "item": "Compendium.fallout-companion.fallout-weapons.Item.1O6sxZnuk8KSwzXj",
      "name": "Pipe Gun",
      "qty": "1",
      "ammo": {
       "item": "Compendium.fallout-companion.fallout-equipment.Item.cf2lJflhr70DPPJ9",
       "name": ".38",
       "qty": "2d6"
      },
      "text": "Pipe Gun"
     },
     {
      "item": "Compendium.fallout-companion.fallout-weapons.Item.dvwnb8DQEP8UkX15",
      "name": "Pipe Revolver",
      "qty": "1",
      "ammo": {
       "item": "Compendium.fallout-companion.fallout-equipment.Item.nvgUfZmsYTTqSOnh",
       "name": ".45",
       "qty": "2d6"
      },
      "text": "Pipe Revolver"
     },
     {
      "item": "Compendium.fallout-companion.fallout-weapons.Item.KJsTSb5LiIJIMEhK",
      "name": "Switchblade",
      "qty": "1",
      "text": "Switchblade"
     },
     {
      "item": "Compendium.fallout-companion.fallout-weapons.Item.37RrAO6nMWR07LmA",
      "name": "Baseball Bat",
      "qty": "1",
      "text": "Baseball Bat"
     },
     {
      "item": "Compendium.fallout-companion.fallout-equipment.Item.qzPdDQnqpEGDFfdC",
      "name": "10mm",
      "qty": "2d6",
      "text": "2d6 10mm rounds"
     },
     {
      "item": "Compendium.fallout-companion.fallout-equipment.Item.Ti9v7YIvbQOk48dY",
      "name": "Shotgun Shell",
      "qty": "1d6",
      "text": "1d6 Shotgun Shells"
     }
    ]
   },
   {
    "min": 9,
    "max": 10,
    "text": "Roll a d6: 1 10mm Pistol; 2 Double-Barrel Shotgun; 3 Pipe Bolt Action; 4 Machete; 5 1d3 Molotov Cocktails; 6 2d6 .308 rounds",
    "options": [
     {
      "item": "Compendium.fallout-companion.fallout-weapons.Item.WoHtnxLqImjH9sJH",
      "name": "10mm Pistol",
      "qty": "1",
      "ammo": {
       "item": "Compendium.fallout-companion.fallout-equipment.Item.qzPdDQnqpEGDFfdC",
       "name": "10mm",
       "qty": "2d6"
      },
      "text": "10mm Pistol"
     },
     {
      "item": "Compendium.fallout-companion.fallout-weapons.Item.cNFFmZID5gB3NbvD",
      "name": "Double-Barrel Shotgun",
      "qty": "1",
      "ammo": {
       "item": "Compendium.fallout-companion.fallout-equipment.Item.Ti9v7YIvbQOk48dY",
       "name": "Shotgun Shell",
       "qty": "2d6"
      },
      "text": "Double-Barrel Shotgun"
     },
     {
      "item": "Compendium.fallout-companion.fallout-weapons.Item.jHhZLXuRq1r52Cfj",
      "name": "Pipe Bolt-Action",
      "qty": "1",
      "ammo": {
       "item": "Compendium.fallout-companion.fallout-equipment.Item.2PFsZ7jc9FtwIYUR",
       "name": ".308",
       "qty": "2d6"
      },
      "text": "Pipe Bolt Action"
     },
     {
      "item": "Compendium.fallout-companion.fallout-weapons.Item.rw3sWha000BJ2Mpo",
      "name": "Machete",
      "qty": "1",
      "text": "Machete"
     },
     {
      "item": "Compendium.fallout-companion.fallout-weapons.Item.ps0EIbkAeFTbhmLK",
      "name": "Molotov Cocktail",
      "qty": "1d3",
      "text": "1d3 Molotov Cocktails"
     },
     {
      "item": "Compendium.fallout-companion.fallout-equipment.Item.2PFsZ7jc9FtwIYUR",
      "name": ".308",
      "qty": "2d6",
      "text": "2d6 .308 rounds"
     }
    ]
   },
   {
    "min": 11,
    "max": 12,
    "text": "Roll a d6: 1 Hunting Rifle; 2 .44 Pistol; 3 Submachine Gun; 4 Laser Pistol (1d6 Fusion Cells); 5 1d3 Frag Grenades; 6 Sledgehammer",
    "options": [
     {
      "item": "Compendium.fallout-companion.fallout-weapons.Item.Z71WjhttJkxYbGtf",
      "name": "Hunting Rifle",
      "qty": "1",
      "ammo": {
       "item": "Compendium.fallout-companion.fallout-equipment.Item.2PFsZ7jc9FtwIYUR",
       "name": ".308",
       "qty": "2d6"
      },
      "text": "Hunting Rifle"
     },
     {
      "item": "Compendium.fallout-companion.fallout-weapons.Item.2XHJdcKCcdZ5yGX6",
      "name": ".44 Pistol",
      "qty": "1",
      "ammo": {
       "item": "Compendium.fallout-companion.fallout-equipment.Item.GH7KHgxGBiO6zJgy",
       "name": ".44",
       "qty": "2d6"
      },
      "text": ".44 Pistol"
     },
     {
      "item": "Compendium.fallout-companion.fallout-weapons.Item.2iS800cdLawpGRiM",
      "name": "Submachine Gun",
      "qty": "1",
      "ammo": {
       "item": "Compendium.fallout-companion.fallout-equipment.Item.nvgUfZmsYTTqSOnh",
       "name": ".45",
       "qty": "2d6"
      },
      "text": "Submachine Gun"
     },
     {
      "item": "Compendium.fallout-companion.fallout-weapons.Item.UePhPjDHRV6qdF0g",
      "name": "Laser Pistol",
      "qty": "1",
      "ammo": {
       "item": "Compendium.fallout-companion.fallout-equipment.Item.W5S0bEDvo1cZei0K",
       "name": "Fusion Cell",
       "qty": "1d6"
      },
      "text": "Laser Pistol (1d6 Fusion Cells)"
     },
     {
      "item": "Compendium.fallout-companion.fallout-weapons.Item.IBGaNhnqhdpOYQEk",
      "name": "Frag Grenade",
      "qty": "1d3",
      "text": "1d3 Frag Grenades"
     },
     {
      "item": "Compendium.fallout-companion.fallout-weapons.Item.tk2mnfQCjUDwFgZ6",
      "name": "Sledgehammer",
      "qty": "1",
      "text": "Sledgehammer"
     }
    ]
   },
   {
    "min": 13,
    "max": 13,
    "text": "Roll a d6: 1 Combat Rifle; 2 Combat Shotgun; 3 Laser Rifle; 4 Plasma Pistol (1d6 Plasma Cartridges); 5 Ripper; 6 2d6 5.56mm rounds",
    "options": [
     {
      "item": "Compendium.fallout-companion.fallout-weapons.Item.MlmYixt7j3pBDB5B",
      "name": "Combat Rifle",
      "qty": "1",
      "ammo": {
       "item": "Compendium.fallout-companion.fallout-equipment.Item.nvgUfZmsYTTqSOnh",
       "name": ".45",
       "qty": "2d6"
      },
      "text": "Combat Rifle"
     },
     {
      "item": "Compendium.fallout-companion.fallout-weapons.Item.7Pg7eje1uZhtrJe2",
      "name": "Combat Shotgun",
      "qty": "1",
      "ammo": {
       "item": "Compendium.fallout-companion.fallout-equipment.Item.Ti9v7YIvbQOk48dY",
       "name": "Shotgun Shell",
       "qty": "2d6"
      },
      "text": "Combat Shotgun"
     },
     {
      "item": "Compendium.fallout-companion.fallout-weapons.Item.CINloPqFKoRZyq2Z",
      "name": "Laser Rifle",
      "qty": "1",
      "ammo": {
       "item": "Compendium.fallout-companion.fallout-equipment.Item.W5S0bEDvo1cZei0K",
       "name": "Fusion Cell",
       "qty": "2d6"
      },
      "text": "Laser Rifle"
     },
     {
      "item": "Compendium.fallout-companion.fallout-weapons.Item.u1GyxQbknfbj3MPN",
      "name": "Plasma Pistol",
      "qty": "1",
      "ammo": {
       "item": "Compendium.fallout-companion.fallout-equipment.Item.dUQF4jVMhYzorObc",
       "name": "Plasma Cartridge",
       "qty": "1d6"
      },
      "text": "Plasma Pistol (1d6 Plasma Cartridges)"
     },
     {
      "item": "Compendium.fallout-companion.fallout-weapons.Item.1xdA95vTX47d6pwr",
      "name": "Ripper",
      "qty": "1",
      "text": "Ripper"
     },
     {
      "item": "Compendium.fallout-companion.fallout-equipment.Item.IXyYqENCm2XR1YPB",
      "name": "5.56mm",
      "qty": "2d6",
      "text": "2d6 5.56mm rounds"
     }
    ]
   },
   {
    "min": 14,
    "max": 14,
    "text": "Roll a d6: 1 Assault Rifle; 2 Plasma Rifle; 3 Gauss Rifle (1d6 2mm EC); 4 Super Sledge; 5 Missile Launcher (1d3 Missiles); 6 Flamer (2d6 Flamer Fuel)",
    "options": [
     {
      "item": "Compendium.fallout-companion.fallout-weapons.Item.QqLhAAvgyHFtG5UC",
      "name": "Assault Rifle",
      "qty": "1",
      "ammo": {
       "item": "Compendium.fallout-companion.fallout-equipment.Item.IXyYqENCm2XR1YPB",
       "name": "5.56mm",
       "qty": "2d6"
      },
      "text": "Assault Rifle"
     },
     {
      "item": "Compendium.fallout-companion.fallout-weapons.Item.1tmvoPlkair44txt",
      "name": "Plasma Rifle",
      "qty": "1",
      "ammo": {
       "item": "Compendium.fallout-companion.fallout-equipment.Item.dUQF4jVMhYzorObc",
       "name": "Plasma Cartridge",
       "qty": "2d6"
      },
      "text": "Plasma Rifle"
     },
     {
      "item": "Compendium.fallout-companion.fallout-weapons.Item.lcWbMNuXBI8uuvN5",
      "name": "Gauss Rifle",
      "qty": "1",
      "ammo": {
       "item": "Compendium.fallout-companion.fallout-equipment.Item.nyvNoJXwW5TvJmoV",
       "name": "2mm EC",
       "qty": "1d6"
      },
      "text": "Gauss Rifle (1d6 2mm EC)"
     },
     {
      "item": "Compendium.fallout-companion.fallout-weapons.Item.X3XqgYLANMKIas0M",
      "name": "Super Sledge",
      "qty": "1",
      "text": "Super Sledge"
     },
     {
      "item": "Compendium.fallout-companion.fallout-weapons.Item.gBd8Xr7SRBihqWyr",
      "name": "Missile Launcher",
      "qty": "1",
      "ammo": {
       "item": "Compendium.fallout-companion.fallout-equipment.Item.xWqVq0Cr8MtPPgb5",
       "name": "Missile",
       "qty": "1d3"
      },
      "text": "Missile Launcher (1d3 Missiles)"
     },
     {
      "item": "Compendium.fallout-companion.fallout-weapons.Item.b5rHxZxj55Mc4Ybz",
      "name": "Flamer",
      "qty": "1",
      "ammo": {
       "item": "Compendium.fallout-companion.fallout-equipment.Item.v6mgo4NdEZK1kM6p",
       "name": "Flamer Fuel",
       "qty": "2d6"
      },
      "text": "Flamer (2d6 Flamer Fuel)"
     }
    ]
   }
  ],
  "diamonds": [
   {
    "min": 2,
    "max": 5,
    "text": "Roll a d6: 1–2 1d6 caps; 3 1d4 Bobby Pins; 4 Note or holotape; 5 Alarm Clock (junk, 3 caps); 6 Locket (trade good, 10 caps)",
    "options": [
     {
      "caps": "1d6",
      "text": "1d6 caps"
     },
     {
      "caps": "1d6",
      "text": "1d6 caps"
     },
     {
      "item": "Compendium.fallout-companion.fallout-equipment.Item.6uRaGCyaAvJ7DUnM",
      "name": "Bobby Pin",
      "qty": "1d4",
      "text": "1d4 Bobby Pins"
     },
     {
      "gm": "Note or holotape: a password, a map to a new location, a clue, or a Rare recipe. The GM decides.",
      "text": "Note or holotape"
     },
     {
      "junk": "3",
      "label": "Alarm Clock",
      "text": "Alarm Clock (junk, 3 caps)"
     },
     {
      "item": "Compendium.fallout-companion.fallout-equipment.Item.9W9QX3j1byDFbtjM",
      "name": "Locket",
      "qty": "1",
      "text": "Locket (trade good, 10 caps)"
     }
    ]
   },
   {
    "min": 6,
    "max": 8,
    "text": "Roll a d6: 1–2 2d6 caps; 3 Flashlight; 4 Canteen; 5 Duct Tape; 6 Pre-War money worth 2d6 caps",
    "options": [
     {
      "caps": "2d6",
      "text": "2d6 caps"
     },
     {
      "caps": "2d6",
      "text": "2d6 caps"
     },
     {
      "item": "Compendium.fallout-companion.fallout-equipment.Item.FSYABPtJEG36e6fa",
      "name": "Flashlight",
      "qty": "1",
      "text": "Flashlight"
     },
     {
      "item": "Compendium.fallout-companion.fallout-equipment.Item.ggoY6zt17MpuvzaB",
      "name": "Canteen",
      "qty": "1",
      "text": "Canteen"
     },
     {
      "item": "Compendium.fallout-companion.fallout-equipment.Item.OFKpViXdRsopLE1l",
      "name": "Duct Tape",
      "qty": "1",
      "text": "Duct Tape"
     },
     {
      "item": "Compendium.fallout-companion.fallout-equipment.Item.zqUSUb0yLjwUqLQ8",
      "name": "Pre-War Money",
      "qty": "2d6",
      "text": "Pre-War money worth 2d6 caps"
     }
    ]
   },
   {
    "min": 9,
    "max": 10,
    "text": "Roll a d6: 1–2 3d6 caps; 3 Silver Pocketwatch (trade good, 25 caps); 4 Binoculars; 5 Radio; 6 Key or password",
    "options": [
     {
      "caps": "3d6",
      "text": "3d6 caps"
     },
     {
      "caps": "3d6",
      "text": "3d6 caps"
     },
     {
      "item": "Compendium.fallout-companion.fallout-equipment.Item.fZ2GstrTIuOEqbZg",
      "name": "Silver Pocketwatch",
      "qty": "1",
      "text": "Silver Pocketwatch (trade good, 25 caps)"
     },
     {
      "item": "Compendium.fallout-companion.fallout-equipment.Item.SljxmWhYfYliXSzs",
      "name": "Binoculars",
      "qty": "1",
      "text": "Binoculars"
     },
     {
      "item": "Compendium.fallout-companion.fallout-equipment.Item.bVIzLhxSvA1lwMmH",
      "name": "Radio",
      "qty": "1",
      "text": "Radio"
     },
     {
      "gm": "Key or password: opens one lock or terminal here or at a later location. The GM decides.",
      "text": "Key or password"
     }
    ]
   },
   {
    "min": 11,
    "max": 12,
    "text": "Roll a d6: 1–2 5d6 caps; 3 Gas Mask; 4 Holotape Player; 5 Electronic Lock Picks; 6 Locked container (see below)",
    "options": [
     {
      "caps": "5d6",
      "text": "5d6 caps"
     },
     {
      "caps": "5d6",
      "text": "5d6 caps"
     },
     {
      "item": "Compendium.fallout-companion.fallout-armor.Item.DID3OkgD5Da5x8xw",
      "name": "Gas Mask",
      "qty": "1",
      "text": "Gas Mask"
     },
     {
      "item": "Compendium.fallout-companion.fallout-equipment.Item.IcX7AiNFUjhmLbor",
      "name": "Holotape Player",
      "qty": "1",
      "text": "Holotape Player"
     },
     {
      "item": "Compendium.fallout-companion.fallout-equipment.Item.hxzRAHPa40etiVxY",
      "name": "Electronic Lockpicker",
      "qty": "1",
      "text": "Electronic Lock Picks"
     },
     {
      "locked": 1,
      "text": "Locked container (see below)"
     }
    ]
   },
   {
    "min": 13,
    "max": 13,
    "text": "Roll a d6: 1–2 8d6 caps; 3 First Aid Kit; 4 Multi-Tool; 5 Field Radio; 6 Locked container",
    "options": [
     {
      "caps": "8d6",
      "text": "8d6 caps"
     },
     {
      "caps": "8d6",
      "text": "8d6 caps"
     },
     {
      "item": "Compendium.fallout-companion.fallout-equipment.Item.5Zh70js5ZMuUuElc",
      "name": "First Aid Kit",
      "qty": "1",
      "text": "First Aid Kit"
     },
     {
      "item": "Compendium.fallout-companion.fallout-equipment.Item.FDKxpzXg1S1nVOsX",
      "name": "Multi-Tool",
      "qty": "1",
      "text": "Multi-Tool"
     },
     {
      "item": "Compendium.fallout-companion.fallout-equipment.Item.R9se4iZL8u0RySFs",
      "name": "Field Radio",
      "qty": "1",
      "text": "Field Radio"
     },
     {
      "locked": 1,
      "text": "Locked container"
     }
    ]
   },
   {
    "min": 14,
    "max": 14,
    "text": "Roll a d6: 1 10d6 caps; 2 Doctor's Bag; 3 Deluxe Toolkit; 4 AC-Radz Particle Detector; 5 Fusion Core; 6 Locked container with two cards inside",
    "options": [
     {
      "caps": "10d6",
      "text": "10d6 caps"
     },
     {
      "item": "Compendium.fallout-companion.fallout-equipment.Item.bdkQurPf3TG3zHFl",
      "name": "Doctor's Bag",
      "qty": "1",
      "text": "Doctor's Bag"
     },
     {
      "item": "Compendium.fallout-companion.fallout-equipment.Item.rj2uyPBB3upTcW4w",
      "name": "Deluxe Toolkit",
      "qty": "1",
      "text": "Deluxe Toolkit"
     },
     {
      "item": "Compendium.fallout-companion.fallout-equipment.Item.1EtuW5f02nrCKvfF",
      "name": "AC-Radz Particle Detector",
      "qty": "1",
      "text": "AC-Radz Particle Detector"
     },
     {
      "item": "Compendium.fallout-companion.fallout-equipment.Item.ZEJaFQZ8yfmsvgOT",
      "name": "Fusion Core",
      "qty": "1",
      "text": "Fusion Core"
     },
     {
      "locked": 2,
      "text": "Locked container with two cards inside"
     }
    ]
   }
  ],
  "hearts": [
   {
    "min": 2,
    "max": 5,
    "text": "Roll a d6: 1 Dirty Water; 2 Canned Dog Food; 3 Gumdrops; 4 Potato Crisps; 5 Sweet Roll; 6 Dirty Water",
    "options": [
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.D4NsKSPINoKlJcVe",
      "name": "Dirty Water",
      "qty": "1",
      "text": "Dirty Water"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.xV7uVuAAanGHmhZR",
      "name": "Canned Dog Food",
      "qty": "1",
      "text": "Canned Dog Food"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.d8ef7hdsKRkCM9rM",
      "name": "Gumdrops",
      "qty": "1",
      "text": "Gumdrops"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.BF5eK51Y57S3IGl2",
      "name": "Potato Crisps",
      "qty": "1",
      "text": "Potato Crisps"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.c47vsh1cCqOHcju5",
      "name": "Sweet Roll",
      "qty": "1",
      "text": "Sweet Roll"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.D4NsKSPINoKlJcVe",
      "name": "Dirty Water",
      "qty": "1",
      "text": "Dirty Water"
     }
    ]
   },
   {
    "min": 6,
    "max": 8,
    "text": "Roll a d6: 1 Pork 'n' Beans; 2 InstaMash; 3 BlamCo Brand Mac & Cheese; 4 Sugar Bombs; 5 Beer; 6 Nuka-Cola",
    "options": [
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.w2ijCCHS73ap5wtY",
      "name": "Pork 'n' Beans",
      "qty": "1",
      "text": "Pork 'n' Beans"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.5WD2XtYdod10SAqb",
      "name": "InstaMash",
      "qty": "1",
      "text": "InstaMash"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.MJDHhJIhLVysKaqH",
      "name": "BlamCo Brand Mac & Cheese",
      "qty": "1",
      "text": "BlamCo Brand Mac & Cheese"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.vFHhPC7UCnefmQYH",
      "name": "Sugar Bombs",
      "qty": "1",
      "text": "Sugar Bombs"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.UwwIcPkbhUOlJSzq",
      "name": "Beer",
      "qty": "1",
      "text": "Beer"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.WgTvrQaFV1zX3vhP",
      "name": "Nuka-Cola",
      "qty": "1",
      "text": "Nuka-Cola"
     }
    ]
   },
   {
    "min": 9,
    "max": 10,
    "text": "Roll a d6: 1 Cram; 2 Salisbury Steak; 3 Purified Water; 4 Whiskey; 5 Fancy Lads Snack Cakes; 6 Dandy Boy Apples",
    "options": [
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.7icyXB4jRCQ912Kn",
      "name": "Cram",
      "qty": "1",
      "text": "Cram"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.G9KDezScGJvec6rD",
      "name": "Salisbury Steak",
      "qty": "1",
      "text": "Salisbury Steak"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.djOxMAG8OmYvIx41",
      "name": "Purified Water",
      "qty": "1",
      "text": "Purified Water"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.36FhjTAPH6Eq5oXS",
      "name": "Whiskey",
      "qty": "1",
      "text": "Whiskey"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.3a9wohiPSLL50Ev3",
      "name": "Fancy Lads Snack Cakes",
      "qty": "1",
      "text": "Fancy Lads Snack Cakes"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.OsT7AJRBIAFiLlCz",
      "name": "Dandy Boy Apples",
      "qty": "1",
      "text": "Dandy Boy Apples"
     }
    ]
   },
   {
    "min": 11,
    "max": 12,
    "text": "Roll a d6: 1 Stimpak; 2 Rad-X; 3 Jet; 4 Mentats; 5 Antiseptic; 6 Brahmin Milk",
    "options": [
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.h0zXW8hmQ6CXQVzO",
      "name": "Stimpak",
      "qty": "1",
      "text": "Stimpak"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.nB9UDBYYmYycGa4A",
      "name": "Rad-X",
      "qty": "1",
      "text": "Rad-X"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.PcRpj02cHTEZbBSS",
      "name": "Jet",
      "qty": "1",
      "text": "Jet"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.b4IEDKbgmHVT1gz1",
      "name": "Mentats",
      "qty": "1",
      "text": "Mentats"
     },
     {
      "item": "Compendium.fallout-companion.fallout-crafting-materials.Item.mYWVNtZCcb8eaSGp",
      "name": "Antiseptic",
      "qty": "1",
      "text": "Antiseptic"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.ClYzKXBnUMQm8LwQ",
      "name": "Brahmin Milk",
      "qty": "1",
      "text": "Brahmin Milk"
     }
    ]
   },
   {
    "min": 13,
    "max": 13,
    "text": "Roll a d6: 1 RadAway; 2 Psycho; 3 Buffout; 4 Antibiotics; 5 Calmex; 6 Stimpak ×2",
    "options": [
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.zDvCiM2IRb8I7WnW",
      "name": "RadAway",
      "qty": "1",
      "text": "RadAway"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.GTl5ub79rij0kryp",
      "name": "Psycho",
      "qty": "1",
      "text": "Psycho"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.6VDMIySMmWKKEJmF",
      "name": "Buffout",
      "qty": "1",
      "text": "Buffout"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.uu9OGZpDLcKnuUFn",
      "name": "Antibiotics",
      "qty": "1",
      "text": "Antibiotics"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.U2Twv167fQX17jRI",
      "name": "Calmex",
      "qty": "1",
      "text": "Calmex"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.h0zXW8hmQ6CXQVzO",
      "name": "Stimpak",
      "qty": "2",
      "text": "Stimpak ×2"
     }
    ]
   },
   {
    "min": 14,
    "max": 14,
    "text": "Roll a d6: 1 Perfectly Preserved Pie; 2 Addictol; 3 Day Tripper; 4 Daddy-O; 5 Nuka-Cola Quantum; 6 Refreshing Beverage",
    "options": [
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.5sveLZW5sCnWiWTc",
      "name": "Perfectly Preserved Pie",
      "qty": "1",
      "text": "Perfectly Preserved Pie"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.5LBbsvlx0olU2eFR",
      "name": "Addictol",
      "qty": "1",
      "text": "Addictol"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.spej9A26jBrQ2PxA",
      "name": "Day Tripper",
      "qty": "1",
      "text": "Day Tripper"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.d9kT0dwrlkzr1zw8",
      "name": "Daddy-O",
      "qty": "1",
      "text": "Daddy-O"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.CYa5E3eqIopSzMLa",
      "name": "Nuka-Cola Quantum",
      "qty": "1",
      "text": "Nuka-Cola Quantum"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.gvh7nkrM7Q5kqxY2",
      "name": "Refreshing Beverage",
      "qty": "1",
      "text": "Refreshing Beverage"
     }
    ]
   }
  ],
  "spades": [
   {
    "min": 2,
    "max": 5,
    "text": "Roll a d6: 1–3 Junk worth 1d6 caps; 4 Casual Clothing; 5 Sack Hood; 6 1d4 Common Resources",
    "options": [
     {
      "junk": "1d6",
      "text": "Junk worth 1d6 caps"
     },
     {
      "junk": "1d6",
      "text": "Junk worth 1d6 caps"
     },
     {
      "junk": "1d6",
      "text": "Junk worth 1d6 caps"
     },
     {
      "item": "Compendium.fallout-companion.fallout-armor.Item.F24g6gA3md6jDOj7",
      "name": "Casual Clothing",
      "qty": "1",
      "text": "Casual Clothing"
     },
     {
      "item": "Compendium.fallout-companion.fallout-armor.Item.yTdzQmg2atSxwLoe",
      "name": "Sack Hood",
      "qty": "1",
      "text": "Sack Hood"
     },
     {
      "item": "Compendium.fallout-companion.fallout-crafting-materials.Item.F1XcosU81qNg1dBW",
      "name": "Common Materials",
      "qty": "1d4",
      "text": "1d4 Common Resources"
     }
    ]
   },
   {
    "min": 6,
    "max": 8,
    "text": "Roll a d6: 1–2 Junk worth 2d6 caps; 3 Tough Clothing; 4 Road Leathers; 5 Harness; 6 1d6 Common Resources",
    "options": [
     {
      "junk": "2d6",
      "text": "Junk worth 2d6 caps"
     },
     {
      "junk": "2d6",
      "text": "Junk worth 2d6 caps"
     },
     {
      "item": "Compendium.fallout-companion.fallout-armor.Item.6QLrxK2rgYl7l0hd",
      "name": "Tough Clothing",
      "qty": "1",
      "text": "Tough Clothing"
     },
     {
      "item": "Compendium.fallout-companion.fallout-armor.Item.f90fSLX9Ldr5sQAI",
      "name": "Road Leathers",
      "qty": "1",
      "text": "Road Leathers"
     },
     {
      "item": "Compendium.fallout-companion.fallout-armor.Item.kXb3wbtiWKYhqmZe",
      "name": "Harness",
      "qty": "1",
      "text": "Harness"
     },
     {
      "item": "Compendium.fallout-companion.fallout-crafting-materials.Item.F1XcosU81qNg1dBW",
      "name": "Common Materials",
      "qty": "1d6",
      "text": "1d6 Common Resources"
     }
    ]
   },
   {
    "min": 9,
    "max": 10,
    "text": "Roll a d6: 1 Junk worth 3d6 caps; 2 Raider armor piece; 3 Leather armor piece; 4 Military Fatigues; 5 Hard Hat or Army Helmet; 6 1d4 Uncommon Resources",
    "options": [
     {
      "junk": "3d6",
      "text": "Junk worth 3d6 caps"
     },
     {
      "armor": "Raider",
      "pieces": {
       "torso": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.iTyHnRtCIKxiRKqv",
        "name": "Raider Chest Piece"
       },
       "arms": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.LjUqvjBlRAsREn3H",
        "name": "Raider Arms"
       },
       "legs": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.TbAmyk3avD49J9yM",
        "name": "Raider Legs"
       },
       "head": null
      },
      "text": "Raider armor piece"
     },
     {
      "armor": "Leather",
      "pieces": {
       "torso": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.jCbSyHKwsX77eYSc",
        "name": "Leather Chest Piece"
       },
       "arms": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.nocQ5YZlHFKzBvnR",
        "name": "Leather Arms"
       },
       "legs": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.fQvk0JTkfGkSXsdN",
        "name": "Leather Legs"
       },
       "head": null
      },
      "text": "Leather armor piece"
     },
     {
      "item": "Compendium.fallout-companion.fallout-armor.Item.8OQ38qMLUb5WBUwH",
      "name": "Military Fatigues",
      "qty": "1",
      "text": "Military Fatigues"
     },
     {
      "pick": [
       {
        "item": "Compendium.fallout-companion.fallout-armor.Item.blDBpv7ivXFbLpMt",
        "name": "Hard Hat",
        "qty": "1"
       },
       {
        "item": "Compendium.fallout-companion.fallout-armor.Item.cjrg8BQlOe9oz40R",
        "name": "Army Helmet",
        "qty": "1"
       }
      ],
      "text": "Hard Hat or Army Helmet"
     },
     {
      "item": "Compendium.fallout-companion.fallout-crafting-materials.Item.VlYSIFDJ7GLLDcNJ",
      "name": "Uncommon Materials",
      "qty": "1d4",
      "text": "1d4 Uncommon Resources"
     }
    ]
   },
   {
    "min": 11,
    "max": 12,
    "text": "Roll a d6: 1 Metal armor piece; 2 Combat armor piece; 3 Heavy Coat; 4 Lab Coat; 5 Hazmat Suit; 6 1d6 Uncommon Resources",
    "options": [
     {
      "armor": "Metal",
      "pieces": {
       "torso": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.69sMRSjGzvfQgfa1",
        "name": "Metal Chest Piece"
       },
       "arms": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.82fjeZcPy5WcgLl4",
        "name": "Metal Arms"
       },
       "legs": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.C6I1C5sWImE1M73N",
        "name": "Metal Legs"
       },
       "head": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.g6rXmZxAdTktDC4R",
        "name": "Metal Helmet"
       }
      },
      "text": "Metal armor piece"
     },
     {
      "armor": "Combat",
      "pieces": {
       "torso": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.D7JhmFyo2fh7C2rQ",
        "name": "Combat Chest Piece"
       },
       "arms": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.5mxgq9qVmKfRrIYj",
        "name": "Combat Arms"
       },
       "legs": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.RoCSV0T2ZJzSeSMF",
        "name": "Combat Legs"
       },
       "head": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.wxceDXLvWGpRTbKx",
        "name": "Combat Helmet"
       }
      },
      "text": "Combat armor piece"
     },
     {
      "item": "Compendium.fallout-companion.fallout-armor.Item.kQahKTkMHDmkK3oU",
      "name": "Heavy Coat",
      "qty": "1",
      "text": "Heavy Coat"
     },
     {
      "item": "Compendium.fallout-companion.fallout-armor.Item.Kx8TBtb63cpnwewa",
      "name": "Lab Coat",
      "qty": "1",
      "text": "Lab Coat"
     },
     {
      "item": "Compendium.fallout-companion.fallout-armor.Item.SiBDuKaMI8un2x3z",
      "name": "Hazmat Suit",
      "qty": "1",
      "text": "Hazmat Suit"
     },
     {
      "item": "Compendium.fallout-companion.fallout-crafting-materials.Item.VlYSIFDJ7GLLDcNJ",
      "name": "Uncommon Materials",
      "qty": "1d6",
      "text": "1d6 Uncommon Resources"
     }
    ]
   },
   {
    "min": 13,
    "max": 13,
    "text": "Roll a d6: 1 Sturdy Combat armor piece; 2 Synth armor piece; 3 Vault-Tec Security Armor piece; 4 Heavy Leather armor piece; 5 Engineer's Armor; 6 1d4 Rare Resources",
    "options": [
     {
      "armor": "Sturdy Combat",
      "pieces": {
       "torso": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.iJwVhZATk7PPGwlB",
        "name": "Sturdy Combat Chest Piece"
       },
       "arms": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.LLVJdHbOZiZCrwHp",
        "name": "Sturdy Combat Arms"
       },
       "legs": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.uqiFDNtddOlaGLCt",
        "name": "Sturdy Combat Legs"
       },
       "head": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.nZhwtI5S3kNN15Lm",
        "name": "Sturdy Combat Helmet"
       }
      },
      "text": "Sturdy Combat armor piece"
     },
     {
      "armor": "Synth",
      "pieces": {
       "torso": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.pVeP8SzMaPBwy8Qq",
        "name": "Synth Chest Piece"
       },
       "arms": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.wBUyZhjWKFi1BEe2",
        "name": "Synth Arms"
       },
       "legs": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.gmb9BAjPivOnZZt0",
        "name": "Synth Legs"
       },
       "head": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.AJP4YQnXLuMW5Ana",
        "name": "Synth Helmet"
       }
      },
      "text": "Synth armor piece"
     },
     {
      "armor": "Vault-Tec Security Armor",
      "pieces": {
       "torso": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.wYOaYG4LvL6uu0DO",
        "name": "Vault-Tec Security Armor"
       },
       "arms": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.wYOaYG4LvL6uu0DO",
        "name": "Vault-Tec Security Armor"
       },
       "legs": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.wYOaYG4LvL6uu0DO",
        "name": "Vault-Tec Security Armor"
       },
       "head": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.Dobj4XxoLc8ZTITV",
        "name": "Vault-Tec Security Helmet"
       }
      },
      "text": "Vault-Tec Security Armor piece"
     },
     {
      "armor": "Heavy Leather",
      "pieces": {
       "torso": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.QDJ15jW8djhTXLRp",
        "name": "Heavy Leather Chest Piece"
       },
       "arms": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.9wcNhc8IuQNygUi7",
        "name": "Heavy Leather Arms"
       },
       "legs": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.MReD45pU7dKFVtc9",
        "name": "Heavy Leather Legs"
       },
       "head": null
      },
      "text": "Heavy Leather armor piece"
     },
     {
      "item": "Compendium.fallout-companion.fallout-armor.Item.iEG5x4hx085Z5xZW",
      "name": "Engineer's Armor",
      "qty": "1",
      "text": "Engineer's Armor"
     },
     {
      "item": "Compendium.fallout-companion.fallout-crafting-materials.Item.lKjtqStdqyPuOjrm",
      "name": "Rare Materials",
      "qty": "1d4",
      "text": "1d4 Rare Resources"
     }
    ]
   },
   {
    "min": 14,
    "max": 14,
    "text": "Roll a d6: 1 Heavy Combat armor piece; 2 Heavy Metal armor piece; 3 Sturdy Synth armor piece; 4 Brotherhood of Steel Uniform; 5 1d6 Rare Resources; 6 Fusion Core",
    "options": [
     {
      "armor": "Heavy Combat",
      "pieces": {
       "torso": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.Vb106u03RK4HEu8Y",
        "name": "Heavy Combat Chest Piece"
       },
       "arms": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.iSqc26l022a91uBh",
        "name": "Heavy Combat Arms"
       },
       "legs": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.VMQqeIZRz15s85Md",
        "name": "Heavy Combat Legs"
       },
       "head": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.7baQ9KJe8PSdsH7z",
        "name": "Heavy Combat Helmet"
       }
      },
      "text": "Heavy Combat armor piece"
     },
     {
      "armor": "Heavy Metal",
      "pieces": {
       "torso": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.7Go3lkCt6SQ6CIzw",
        "name": "Heavy Metal Chest Piece"
       },
       "arms": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.Gm136b7qOfRLOz4M",
        "name": "Heavy Metal Arms"
       },
       "legs": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.XRgBqZfbRWmXleDl",
        "name": "Heavy Metal Legs"
       },
       "head": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.jsvydC3huyyvHEDS",
        "name": "Heavy Metal Helmet"
       }
      },
      "text": "Heavy Metal armor piece"
     },
     {
      "armor": "Sturdy Synth",
      "pieces": {
       "torso": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.ZaRXd3zyqVgu8CRH",
        "name": "Sturdy Synth Chest Piece"
       },
       "arms": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.OWaSec88BtiOxuPg",
        "name": "Sturdy Synth Arms"
       },
       "legs": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.Kh9kvcWFMxBbiyBd",
        "name": "Sturdy Synth Legs"
       },
       "head": {
        "item": "Compendium.fallout-companion.fallout-armor.Item.mwBOflWhuaXlR80E",
        "name": "Sturdy Synth Helmet"
       }
      },
      "text": "Sturdy Synth armor piece"
     },
     {
      "item": "Compendium.fallout-companion.fallout-armor.Item.RFUjxsp4s2KupsGW",
      "name": "Brotherhood of Steel Uniform",
      "qty": "1",
      "text": "Brotherhood of Steel Uniform"
     },
     {
      "item": "Compendium.fallout-companion.fallout-crafting-materials.Item.lKjtqStdqyPuOjrm",
      "name": "Rare Materials",
      "qty": "1d6",
      "text": "1d6 Rare Resources"
     },
     {
      "item": "Compendium.fallout-companion.fallout-equipment.Item.ZEJaFQZ8yfmsvgOT",
      "name": "Fusion Core",
      "qty": "1",
      "text": "Fusion Core"
     }
    ]
   }
  ]
 },
 "jackpot": [
  {
   "table": "Vault-Tec Bobbleheads",
   "text": "A Vault-Tec Bobblehead (roll on the Vault-Tec Bobbleheads table)"
  },
  {
   "draw": 3,
   "text": "A stash: draw three more cards and keep them all"
  },
  {
   "pick": [
    {
     "item": "Compendium.fallout-companion.fallout-equipment.Item.zFh0l4sexPQT9N4j",
     "name": "Mini Nuke",
     "qty": "1"
    },
    {
     "item": "Compendium.fallout-companion.fallout-equipment.Item.ZEJaFQZ8yfmsvgOT",
     "name": "Fusion Core",
     "qty": "1"
    }
   ],
   "text": "Mini Nuke or Fusion Core (GM's choice)"
  },
  {
   "item": "Compendium.fallout-companion.fallout-equipment.Item.pV7bicXDAgD9BuYC",
   "name": "Pre-War Valuables",
   "qty": "20d6",
   "text": "Pre-War cache worth 20d6 caps in valuables"
  },
  {
   "gm": "A Rare recipe on a holotape or tucked in a notebook. The GM picks one to teach at the Workbench.",
   "text": "A Rare recipe (see Crafting) on a holotape or tucked in a notebook"
  },
  {
   "gm": "A unique item of the GM's design: a named weapon, an experimental mod, or a lead on something bigger.",
   "text": "A unique item of the GM's design: a named weapon, an experimental mod, or a lead on something bigger"
  }
 ],
 "complications": [
  {
   "text": "Picked clean. Whatever was here is gone. No further searches."
  },
  {
   "text": "Slow going. The search takes half again as long. Roll for wandering trouble if the GM uses encounter draws."
  },
  {
   "text": "Company. The location's inhabitants (or a patrol, or a pack of mongrels) arrive or wake up."
  },
  {
   "text": "Hazard. You set off one of the location's hazards: a rotten floor, a gas leak, a tripwire, a hot spot."
  },
  {
   "text": "Locked away. One of your loot cards (draw it now) is in a locked container or behind a terminal. See Obstacles."
  },
  {
   "text": "Noise. You make a racket. Everything within a few blocks knows someone's here."
  }
 ],
 "tables": {
  "Compendium.fallout-companion.fallout-rollable-tables.RollTable.PfwuY8F3nb7BkrNM": {
   "name": "Winter Wasteland Scavenging Table",
   "formula": "1d20",
   "results": [
    {
     "min": 1,
     "max": 1,
     "text": "Heavy Dog Armor",
     "item": "Compendium.fallout-companion.fallout-armor.Item.Z1YaHOwz9uOWOzDB",
     "name": "Heavy Dog Armor",
     "qty": "1"
    },
    {
     "min": 2,
     "max": 2,
     "text": "10mm Pistol",
     "item": "Compendium.fallout-companion.fallout-weapons.Item.WoHtnxLqImjH9sJH",
     "name": "10mm Pistol",
     "qty": "1",
     "ammo": {
      "item": "Compendium.fallout-companion.fallout-equipment.Item.qzPdDQnqpEGDFfdC",
      "name": "10mm",
      "qty": "2d6"
     }
    },
    {
     "min": 3,
     "max": 3,
     "text": "Addictol",
     "item": "Compendium.fallout-companion.fallout-consumables.Item.5LBbsvlx0olU2eFR",
     "name": "Addictol",
     "qty": "1"
    },
    {
     "min": 4,
     "max": 4,
     "text": "Day Tripper",
     "item": "Compendium.fallout-companion.fallout-consumables.Item.spej9A26jBrQ2PxA",
     "name": "Day Tripper",
     "qty": "1"
    },
    {
     "min": 5,
     "max": 5,
     "text": "Machete",
     "item": "Compendium.fallout-companion.fallout-weapons.Item.rw3sWha000BJ2Mpo",
     "name": "Machete",
     "qty": "1"
    },
    {
     "min": 6,
     "max": 6,
     "text": "Sledgehammer",
     "item": "Compendium.fallout-companion.fallout-weapons.Item.tk2mnfQCjUDwFgZ6",
     "name": "Sledgehammer",
     "qty": "1"
    },
    {
     "min": 7,
     "max": 7,
     "text": "Stimpak",
     "item": "Compendium.fallout-companion.fallout-consumables.Item.h0zXW8hmQ6CXQVzO",
     "name": "Stimpak",
     "qty": "1"
    },
    {
     "min": 8,
     "max": 8,
     "text": ".45 rounds (2d6)",
     "item": "Compendium.fallout-companion.fallout-equipment.Item.nvgUfZmsYTTqSOnh",
     "name": ".45",
     "qty": "2d6"
    },
    {
     "min": 9,
     "max": 9,
     "text": "Uncommon Resources (1d4)",
     "item": "Compendium.fallout-companion.fallout-crafting-materials.Item.VlYSIFDJ7GLLDcNJ",
     "name": "Uncommon Materials",
     "qty": "1d4"
    },
    {
     "min": 10,
     "max": 10,
     "text": "Pork 'n' Beans",
     "item": "Compendium.fallout-companion.fallout-consumables.Item.w2ijCCHS73ap5wtY",
     "name": "Pork 'n' Beans",
     "qty": "1"
    },
    {
     "min": 11,
     "max": 11,
     "text": "Signal Flare",
     "item": "Compendium.fallout-companion.fallout-equipment.Item.Le6qFyEaYWLIwe5j",
     "name": "Signal Flare",
     "qty": "1"
    },
    {
     "min": 12,
     "max": 12,
     "text": "Holotape Player",
     "item": "Compendium.fallout-companion.fallout-equipment.Item.IcX7AiNFUjhmLbor",
     "name": "Holotape Player",
     "qty": "1"
    },
    {
     "min": 13,
     "max": 13,
     "text": "Tomahawk",
     "item": "Compendium.fallout-companion.fallout-weapons.Item.cMJON3KGH7AWd92V",
     "name": "Tomahawk",
     "qty": "1"
    },
    {
     "min": 14,
     "max": 14,
     "text": "Pool Cue",
     "item": "Compendium.fallout-companion.fallout-weapons.Item.U1dXuqGFY30vMj0v",
     "name": "Pool Cue",
     "qty": "1"
    },
    {
     "min": 15,
     "max": 15,
     "text": "Heavy Coat",
     "item": "Compendium.fallout-companion.fallout-armor.Item.kQahKTkMHDmkK3oU",
     "name": "Heavy Coat",
     "qty": "1"
    },
    {
     "min": 16,
     "max": 16,
     "text": "Blanket",
     "item": "Compendium.fallout-companion.fallout-equipment.Item.vE0xPmRcEEpSVAw8",
     "name": "Blanket",
     "qty": "1"
    },
    {
     "min": 17,
     "max": 17,
     "text": "Canned Dog Food",
     "item": "Compendium.fallout-companion.fallout-consumables.Item.xV7uVuAAanGHmhZR",
     "name": "Canned Dog Food",
     "qty": "1"
    },
    {
     "min": 18,
     "max": 18,
     "text": "Moonshine",
     "item": "Compendium.fallout-companion.fallout-consumables.Item.e7XIXdGmI7qgBhpN",
     "name": "Moonshine",
     "qty": "1"
    },
    {
     "min": 19,
     "max": 19,
     "text": "Roughin' It! Bedroll Kit",
     "item": "Compendium.fallout-companion.fallout-equipment.Item.COp4I5jqNKqXHWRK",
     "name": "Bedroll (Roughin' It! Kit)",
     "qty": "1"
    },
    {
     "min": 20,
     "max": 20,
     "text": "Cram (1d3 tins)",
     "item": "Compendium.fallout-companion.fallout-consumables.Item.7icyXB4jRCQ912Kn",
     "name": "Cram",
     "qty": "1d3"
    }
   ]
  }
 },
 "scrounger": {
  "food": [
   {
    "item": "Compendium.fallout-companion.fallout-consumables.Item.D4NsKSPINoKlJcVe",
    "name": "Dirty Water",
    "qty": "1"
   },
   {
    "item": "Compendium.fallout-companion.fallout-consumables.Item.djOxMAG8OmYvIx41",
    "name": "Purified Water",
    "qty": "1"
   },
   {
    "item": "Compendium.fallout-companion.fallout-consumables.Item.xV7uVuAAanGHmhZR",
    "name": "Canned Dog Food",
    "qty": "1"
   },
   {
    "item": "Compendium.fallout-companion.fallout-consumables.Item.w2ijCCHS73ap5wtY",
    "name": "Pork 'n' Beans",
    "qty": "1"
   },
   {
    "item": "Compendium.fallout-companion.fallout-consumables.Item.5WD2XtYdod10SAqb",
    "name": "InstaMash",
    "qty": "1"
   },
   {
    "item": "Compendium.fallout-companion.fallout-consumables.Item.7icyXB4jRCQ912Kn",
    "name": "Cram",
    "qty": "1"
   },
   {
    "item": "Compendium.fallout-companion.fallout-consumables.Item.BF5eK51Y57S3IGl2",
    "name": "Potato Crisps",
    "qty": "1"
   },
   {
    "item": "Compendium.fallout-companion.fallout-consumables.Item.vFHhPC7UCnefmQYH",
    "name": "Sugar Bombs",
    "qty": "1"
   }
  ],
  "chems": [
   {
    "min": 1,
    "max": 1,
    "text": "RadAway (Diluted)",
    "item": "Compendium.fallout-companion.fallout-consumables.Item.zDvCiM2IRb8I7WnW",
    "name": "RadAway",
    "qty": "1"
   },
   {
    "min": 2,
    "max": 2,
    "text": "Rad-X (Diluted)",
    "item": "Compendium.fallout-companion.fallout-consumables.Item.nB9UDBYYmYycGa4A",
    "name": "Rad-X",
    "qty": "1"
   },
   {
    "min": 3,
    "max": 3,
    "text": "Stimpak (Diluted)",
    "item": "Compendium.fallout-companion.fallout-consumables.Item.h0zXW8hmQ6CXQVzO",
    "name": "Stimpak",
    "qty": "1"
   },
   {
    "min": 4,
    "max": 4,
    "text": "Healing Salve or Skeeto Spit (odd/even on a d6)",
    "pick": [
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.pBKutAg7L0d8F9nj",
      "name": "Healing Salve",
      "qty": "1"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.49YDmn0XnfWgHUNq",
      "name": "Skeeto Spit",
      "qty": "1"
     }
    ]
   },
   {
    "min": 5,
    "max": 5,
    "text": "Rad-X",
    "item": "Compendium.fallout-companion.fallout-consumables.Item.nB9UDBYYmYycGa4A",
    "name": "Rad-X",
    "qty": "1"
   },
   {
    "min": 6,
    "max": 6,
    "text": "RadAway",
    "item": "Compendium.fallout-companion.fallout-consumables.Item.zDvCiM2IRb8I7WnW",
    "name": "RadAway",
    "qty": "1"
   },
   {
    "min": 7,
    "max": 7,
    "text": "Stimpak",
    "item": "Compendium.fallout-companion.fallout-consumables.Item.h0zXW8hmQ6CXQVzO",
    "name": "Stimpak",
    "qty": "1"
   },
   {
    "min": 8,
    "max": 8,
    "text": "Jet",
    "item": "Compendium.fallout-companion.fallout-consumables.Item.PcRpj02cHTEZbBSS",
    "name": "Jet",
    "qty": "1"
   },
   {
    "min": 9,
    "max": 9,
    "text": "Jet Fuel",
    "item": "Compendium.fallout-companion.fallout-consumables.Item.FOzfIxO6A3i212Y4",
    "name": "Jet Fuel",
    "qty": "1"
   },
   {
    "min": 10,
    "max": 10,
    "text": "Buffout",
    "item": "Compendium.fallout-companion.fallout-consumables.Item.6VDMIySMmWKKEJmF",
    "name": "Buffout",
    "qty": "1"
   },
   {
    "min": 11,
    "max": 11,
    "text": "Psycho",
    "item": "Compendium.fallout-companion.fallout-consumables.Item.GTl5ub79rij0kryp",
    "name": "Psycho",
    "qty": "1"
   },
   {
    "min": 12,
    "max": 12,
    "text": "Med-X",
    "item": "Compendium.fallout-companion.fallout-consumables.Item.TcmGnJm2TaWeOQ6G",
    "name": "Med-X",
    "qty": "1"
   },
   {
    "min": 13,
    "max": 13,
    "text": "Mentats",
    "item": "Compendium.fallout-companion.fallout-consumables.Item.b4IEDKbgmHVT1gz1",
    "name": "Mentats",
    "qty": "1"
   },
   {
    "min": 14,
    "max": 14,
    "text": "Day Tripper",
    "item": "Compendium.fallout-companion.fallout-consumables.Item.spej9A26jBrQ2PxA",
    "name": "Day Tripper",
    "qty": "1"
   },
   {
    "min": 15,
    "max": 15,
    "text": "Daddy-O",
    "item": "Compendium.fallout-companion.fallout-consumables.Item.d9kT0dwrlkzr1zw8",
    "name": "Daddy-O",
    "qty": "1"
   },
   {
    "min": 16,
    "max": 16,
    "text": "Fury",
    "item": "Compendium.fallout-companion.fallout-consumables.Item.7WyBYLF2TiBpmwIW",
    "name": "Fury",
    "qty": "1"
   },
   {
    "min": 17,
    "max": 17,
    "text": "Berry, Grape, or Orange Mentats (roll 1d3)",
    "pick": [
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.B2BvreCDAJnnVtd0",
      "name": "Berry Mentats",
      "qty": "1"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.UZ4sDmDEEShrJe7a",
      "name": "Grape Mentats",
      "qty": "1"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.ONrWD4s2zjdwCz2H",
      "name": "Orange Mentats",
      "qty": "1"
     }
    ]
   },
   {
    "min": 18,
    "max": 18,
    "text": "Calmex or Overdrive (odd/even on a d6)",
    "pick": [
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.U2Twv167fQX17jRI",
      "name": "Calmex",
      "qty": "1"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.47KjqkoIpi52JaCQ",
      "name": "Overdrive",
      "qty": "1"
     }
    ]
   },
   {
    "min": 19,
    "max": 19,
    "text": "Buffjet, Bufftats, Psycho Jet, Psychobuff, or Psychotats (roll 1d6, reroll 6)",
    "pick": [
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.xCyVPPbAoxZWKXLQ",
      "name": "Buffjet",
      "qty": "1"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.MeF8RcUWiKBiKciD",
      "name": "Bufftats",
      "qty": "1"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.E5drOZZYT4iD0HP5",
      "name": "Psycho Jet",
      "qty": "1"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.NvJyjW3loDUXdOTI",
      "name": "Psychobuff",
      "qty": "1"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.84b4dSLbIIPCi51z",
      "name": "Psychotats",
      "qty": "1"
     }
    ]
   },
   {
    "min": 20,
    "max": 20,
    "text": "1d6: 1–2 Addictol, 3–4 X-Cell, 5 Ultra Jet, 6 Super Stimpak",
    "pick": [
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.5LBbsvlx0olU2eFR",
      "name": "Addictol",
      "qty": "1"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.5LBbsvlx0olU2eFR",
      "name": "Addictol",
      "qty": "1"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.UUEXeiUiCM0uCjdk",
      "name": "X-Cell",
      "qty": "1"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.UUEXeiUiCM0uCjdk",
      "name": "X-Cell",
      "qty": "1"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.xMpljSxwXIT5aqb9",
      "name": "Ultra Jet",
      "qty": "1"
     },
     {
      "item": "Compendium.fallout-companion.fallout-consumables.Item.61w2uJstLJfZXtr5",
      "name": "Super Stimpak",
      "qty": "1"
     }
    ]
   }
  ]
 },
 "junk": "Compendium.fallout-companion.fallout-crafting-materials.Item.skdTq0IpWpxiojEW",
 "tableIds": {
  "Scavenging Complications": "Compendium.fallout-companion.fallout-rollable-tables.RollTable.1QKO24vaWm5brT05",
  "Vault-Tec Bobbleheads": "Compendium.fallout-companion.fallout-rollable-tables.RollTable.lFWYy2unt68Hamtf",
  "Random Chems": "Compendium.fallout-companion.fallout-rollable-tables.RollTable.QPNC145Q9TNzRjBU",
  "Scrounger Extra Find": "Compendium.fallout-companion.fallout-rollable-tables.RollTable.uQTTjvITOPEyS3Rw",
  "Scavenging Loot: Jackpot": "Compendium.fallout-companion.fallout-rollable-tables.RollTable.i5ZGNnx3ktRjwKkc"
 }
};
