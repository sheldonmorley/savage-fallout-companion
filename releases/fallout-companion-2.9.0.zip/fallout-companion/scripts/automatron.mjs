/**
 * Savage Fallout: Automatron parts (from the Savage Fallout: Settlers module).
 *
 * A part is an item with flags[<ns>].part (ns = "savage-fallout-settlers", or this module). Installing it on a robot
 * copies the item onto the robot, marked flags[MOD].robotPart, and applies the part:
 *   set.attributes / set.pace / set.size / set.flying  -> Active Effect "override" changes (removed with the part)
 *   add.toughness / armor / parry / pace / runDie       -> Active Effect "add" changes
 *   add.skills {Skill: steps}                          -> raises (or creates) skill items by die steps; undone on removal
 *   add.modSlots                                       -> raises the robot's Mod Slots flag
 *   grants [uuid]                                      -> copies those items onto the robot
 *   abilities [{name,text}]                            -> creates ability items
 * Slots: one torso, legs, head and armor; two arms; one attachment per arm (it replaces that arm's hand weapon).
 */
const MOD = "fallout-companion";
const NS = ["savage-fallout-settlers", MOD];
const SKILLS_PACK = `${MOD}.fallout-skills`;
const LIMIT = { torso: 1, legs: 1, head: 1, armor: 1, arm: 2 };
const SLOT_LABEL = { torso: "torso", legs: "legs", head: "head", arm: "arm", attachment: "arm attachment", armor: "robot armor" };
const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

export function partData(item) {
  for (const ns of NS) { const p = item?.flags?.[ns]?.part; if (p?.slot) return p; }
  return null;
}
export const isPart = (item) => !!partData(item);
export const installedParts = (robot) => robot.items.filter((i) => i.flags?.[MOD]?.robotPart);
const partsIn = (robot, slot) => installedParts(robot).filter((i) => i.flags[MOD].robotPart.slot === slot);

/** Why this part can't go on this robot right now, or null. */
export function partFitProblem(robot, part) {
  if (!part) return "not an Automatron part";
  const slot = part.slot;
  if (slot === "attachment") {
    const arms = partsIn(robot, "arm");
    if (!arms.length) return "no arm to mount it on";
    const used = new Set(partsIn(robot, "attachment").map((i) => i.flags[MOD].robotPart.arm));
    if (arms.every((a) => used.has(a.id))) return "every arm already has an attachment";
    return null;
  }
  if (slot !== "torso" && !partsIn(robot, "torso").length) return "fit a torso first";
  if (partsIn(robot, slot).length >= (LIMIT[slot] ?? 1)) return `already has ${slot === "arm" ? "two arms" : `a ${SLOT_LABEL[slot]}`}; remove it first`;
  return null;
}

function changesFor(part, robot) {
  const out = [];
  const ov = (key, value) => out.push({ key, value: String(value), type: "override", priority: 50 });
  const add = (key, value) => out.push({ key, value: String(value), type: "add", priority: null });
  const s = part.set ?? {}, a = part.add ?? {};
  for (const [attr, sides] of Object.entries(s.attributes ?? {})) ov(`system.attributes.${attr}.die.sides`, sides);
  if (s.size !== undefined) ov("system.stats.size", s.size);
  if (s.flying) ov("system.pace.base", "fly");
  if (s.pace !== undefined) ov(s.flying ? "system.pace.fly" : "system.pace.ground", s.pace);
  if (a.toughness) add("system.stats.toughness.modifier", a.toughness);
  if (a.parry) add("system.stats.parry.modifier", a.parry);
  if (a.pace) add(robot.system?.pace?.base === "fly" || s.flying ? "system.pace.fly" : "system.pace.ground", a.pace);
  if (a.runDie) add("system.pace.running.die", 2 * a.runDie);
  return out;
}

async function skillItem(name) {
  const pack = game.packs.get(SKILLS_PACK);
  const idx = await pack?.getIndex();
  const hit = idx?.find((e) => e.name === name);
  if (hit) { const d = (await pack.getDocument(hit._id)).toObject(); delete d._id; return d; }
  return { name, type: "skill", img: "systems/swade/assets/icons/skill.svg", system: { die: { sides: 4, modifier: 0 } } };
}

/** Install a part. partData = the item's part flag, itemData = item.toObject(). Returns the created item. */
export async function installPart(robot, itemData, part) {
  const record = { slot: part.slot, created: [], skills: [], modSlots: 0, arm: null, stashed: [], source: itemData };
  // Arm attachment: pick a free arm and stash that arm's hand weapon(s).
  if (part.slot === "attachment") {
    const used = new Set(partsIn(robot, "attachment").map((i) => i.flags[MOD].robotPart.arm));
    const arm = partsIn(robot, "arm").find((a) => !used.has(a.id));
    record.arm = arm.id;
    const hands = arm.flags[MOD].robotPart.created.map((id) => robot.items.get(id)).filter((i) => i && i.type === "weapon");
    record.stashed = hands.map((h) => h.toObject());
    if (hands.length) await robot.deleteEmbeddedDocuments("Item", hands.map((h) => h.id));
  }
  // Skills by die steps.
  for (const [name, steps] of Object.entries(part.add?.skills ?? {})) {
    const have = robot.items.find((i) => i.type === "skill" && i.name === name);
    if (have) {
      const from = Number(have.system.die?.sides) || 4;
      const to = Math.min(12, from + 2 * steps);
      await have.update({ "system.die.sides": to });
      record.skills.push({ id: have.id, name, from, to, created: false });
    } else {
      const d = await skillItem(name);
      d.system.die = { ...(d.system.die ?? {}), sides: Math.min(12, 2 + 2 * steps), modifier: 0 };
      const [c] = await robot.createEmbeddedDocuments("Item", [d]);
      record.skills.push({ id: c.id, name, from: 0, to: d.system.die.sides, created: true });
    }
  }
  // Granted items and abilities.
  const make = [];
  for (const uuid of part.grants ?? []) {
    const doc = await fromUuid(uuid).catch(() => null);
    if (!doc) { console.warn(`Savage Fallout | part grant not found: ${uuid}`); continue; }
    const d = doc.toObject(); delete d._id; delete d.folder;
    if (d.system && "equipStatus" in d.system && d.type === "weapon") d.system.equipStatus = 4;
    make.push(d);
  }
  for (const ab of part.abilities ?? [])
    make.push({ name: ab.name, type: "ability", img: "systems/swade/assets/icons/ability.svg", system: { description: `<p>${esc(ab.text)}</p>` } });
  if (make.length) record.created = (await robot.createEmbeddedDocuments("Item", make)).map((i) => i.id);
  // Armor: raise the robot's built-in "Armor +N" item (same as Armor Plating mods), so SWADE counts it.
  if (part.add?.armor) {
    let armor = robot.items.find((i) => i.type === "armor" && /^armor\s*\+\d+/i.test(i.name));
    if (!armor) { record.armorCreated = true; [armor] = await robot.createEmbeddedDocuments("Item", [{ name: "Armor +0", type: "armor", img: "icons/equipment/chest/breastplate-riveted-steel.webp",
      system: { armor: 0, equipStatus: 3, locations: { head: true, torso: true, arms: true, legs: true } } }]); }
    const next = (Number(armor.system.armor) || 0) + part.add.armor;
    await armor.update({ "system.armor": next, name: `Armor +${next}` });
    record.armorItem = armor.id; record.armorAdded = part.add.armor;
  }
  // Mod Slots.
  if (part.add?.modSlots) {
    record.modSlots = part.add.modSlots;
    await robot.setFlag(MOD, "modSlots", (Number(robot.getFlag(MOD, "modSlots")) || 0) + part.add.modSlots);
  }
  // The part itself, carrying the Active Effect.
  const data = foundry.utils.deepClone(itemData);
  delete data._id; delete data.folder;
  data.system = { ...(data.system ?? {}), quantity: 1, equipStatus: 1 };
  const changes = changesFor(part, robot);
  data.effects = changes.length ? [{ name: data.name, img: data.img || "icons/svg/upgrade.svg", transfer: true, disabled: false, changes,
    description: `Automatron part: ${data.name}.` }] : [];
  data.flags = { ...(data.flags ?? {}), [MOD]: { ...(data.flags?.[MOD] ?? {}), robotPart: record } };
  const [created] = await robot.createEmbeddedDocuments("Item", [data]);
  return created;
}

/** Remove an installed part and undo everything it did. Returns the item data to hand back. */
export async function removePart(robot, item) {
  const rec = item.flags?.[MOD]?.robotPart ?? {};
  if (rec.slot === "arm") {   // an arm takes its attachment with it
    const att = partsIn(robot, "attachment").find((i) => i.flags[MOD].robotPart.arm === item.id);
    if (att) throw new Error(`remove the ${att.name} from this arm first`);
  }
  if (rec.slot === "torso" && installedParts(robot).length > 1) throw new Error("remove the other parts before the torso");
  const kill = (rec.created ?? []).filter((id) => robot.items.get(id));
  for (const s of rec.skills ?? []) {
    const it = robot.items.get(s.id);
    if (!it) continue;
    if (s.created) kill.push(s.id);
    else await it.update({ "system.die.sides": Math.max(4, (Number(it.system.die?.sides) || 4) - (s.to - s.from)) });
  }
  if (kill.length) await robot.deleteEmbeddedDocuments("Item", kill);
  if (rec.stashed?.length) {
    const back = rec.stashed.map((d) => { const c = foundry.utils.deepClone(d); delete c._id; return c; });
    const made = await robot.createEmbeddedDocuments("Item", back);
    const arm = robot.items.get(rec.arm);
    if (arm) {
      const r = arm.flags[MOD].robotPart;
      const keep = r.created.filter((id) => robot.items.get(id));
      await arm.update({ [`flags.${MOD}.robotPart.created`]: [...keep, ...made.map((i) => i.id)] });
    }
  }
  if (rec.armorItem && rec.armorAdded) {
    const armor = robot.items.get(rec.armorItem);
    if (armor) {
      const next = Math.max(0, (Number(armor.system.armor) || 0) - rec.armorAdded);
      if (next === 0 && rec.armorCreated) await armor.delete();
      else await armor.update({ "system.armor": next, name: `Armor +${next}` });
    }
  }
  if (rec.modSlots) await robot.setFlag(MOD, "modSlots", Math.max(0, (Number(robot.getFlag(MOD, "modSlots")) || 0) - rec.modSlots));
  const back = foundry.utils.deepClone(rec.source ?? item.toObject());
  delete back._id; delete back.folder;
  if (back.flags?.[MOD]) delete back.flags[MOD].robotPart;
  back.effects = []; back.system = { ...(back.system ?? {}), quantity: 1 };
  await item.delete();
  return back;
}

/** A bare chassis to build on: every attribute d4, the four basic skills at d4, Pace 0. */
export async function newAutomatron(owner, name = "Automatron") {
  const skills = [];
  for (const n of ["Athletics", "Fighting", "Notice", "Shooting"]) skills.push(await skillItem(n));
  const ownership = { default: 0 };
  if (owner && !game.user.isGM) ownership[game.user.id] = 3;
  for (const u of game.users) if (owner?.testUserPermission?.(u, "OWNER") && !u.isGM) ownership[u.id] = 3;
  const [actor] = await Actor.createDocuments([{
    name, type: "npc", img: "icons/svg/mystery-man.svg", ownership,
    system: { attributes: Object.fromEntries(["agility", "smarts", "spirit", "strength", "vigor"].map((a) => [a, { die: { sides: 4, modifier: 0 } }])),
      pace: { base: "ground", ground: 0, running: { die: 6 } }, details: { biography: { value: `<p>An Automatron built by ${esc(owner?.name ?? "a mechanic")} at a Robot Workbench.</p>` } } },
    prototypeToken: { name, actorLink: true, disposition: 1 },
    flags: { [MOD]: { robot: true, automatron: true, modSlots: 0 } },
    items: skills,
  }]);
  return actor;
}
