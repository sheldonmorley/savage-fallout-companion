/**
 * Savage Fallout: installing mods on robots.
 *
 * A robot is an actor (an NPC robot, a companion, or a Mister Handy hero) with the "Robot" ability.
 * Its Mod Slots come from flags["fallout-companion"].modSlots, or from its model's name (Robots chapter).
 *
 * Installing copies the mod item onto the robot, marked installed. Skill and Pace bonuses ride on an
 * Active Effect on that copy, so they switch off when it's removed. Armor Plating raises the robot's
 * built-in armor item (the "Armor +N" item), and the change is recorded on the copy so removal undoes it.
 */
const MOD = "fallout-companion";

const MODEL_SLOTS = [
  [/eyebot/i, 1], [/protectron/i, 2], [/sentry\s*bot/i, 4],
  [/mister handy|miss nanny|mister gutsy|robobrain|assaultron|handy/i, 3],
];

export function isRobot(actor) {
  if (!actor || actor.flags?.[MOD]?.station) return false;
  return !!actor.flags?.[MOD]?.robot || actor.items.some((i) => i.name === "Robot" && i.type !== "weapon");
}

export function robotSlots(actor) {
  if (actor.flags?.[MOD]?.automatron) return Number(actor.flags[MOD].modSlots) || 0;
  const set = Number(actor.flags?.[MOD]?.modSlots);
  if (set > 0) return set;
  const hit = MODEL_SLOTS.find(([re]) => re.test(actor.name) || re.test(actor.prototypeToken?.name ?? ""));
  return hit ? hit[1] : 3;
}

export const installedOn = (actor) => actor.items.filter((i) => i.flags?.[MOD]?.robotMod);

export function robotFitProblem(robot, mdata) {
  if (mdata.kind !== "robot") return "not a robot mod";
  const cap = robotSlots(robot);
  const mods = installedOn(robot);
  const used = mods.reduce((a, i) => a + (Number(i.flags[MOD].robotMod.size) || 0), 0);
  const size = Number(mdata.size) || 1;
  if (used + size > cap) return `not enough free Mod Slots (${cap - used} of ${cap} free, needs ${size})`;
  if (mods.filter((i) => i.name === mdata.name).length >= (mdata.max ?? 1)) return "already installed";
  return null;
}

/** Robots this character can work on: itself (if it's a robot), robots it owns, and robot tokens on the scene it owns. */
export function robotCandidates(actor) {
  const seen = new Map();
  const add = (a) => { if (a && isRobot(a) && (a.isOwner || game.user.isGM) && !seen.has(a.uuid)) seen.set(a.uuid, a); };
  add(actor);
  for (const t of canvas?.tokens?.placeables ?? []) add(t.actor);
  for (const a of game.actors ?? []) add(a);
  return [...seen.values()];
}

function naturalArmor(robot) {
  return robot.items.find((i) => i.type === "armor" && /^armor\s*\+\d+/i.test(i.name))
    ?? robot.items.find((i) => i.type === "armor" && (i.system?.equipStatus ?? 3) >= 2);
}

function effectFor(mdata, robot, isSecondPlating) {
  const fx = mdata.fx ?? {};
  const changes = [];
  for (const [skill, v] of Object.entries(fx.skills ?? {}))
    changes.push({ key: `@Skill{${skill}}[system.die.modifier]`, value: String(v), type: "add", priority: null });
  const flyer = robot.system?.pace?.base === "fly";
  if (fx.pace) changes.push({ key: flyer ? "system.pace.fly" : "system.pace.ground", value: String(fx.pace), type: "add", priority: null });
  if (fx.runDie) changes.push({ key: "system.pace.running.die", value: String(2 * fx.runDie), type: "add", priority: null });
  if (isSecondPlating) changes.push({ key: robot.system?.pace?.base === "fly" ? "system.pace.fly" : "system.pace.ground", value: "-1", type: "add", priority: null });
  if (!changes.length) return [];
  return [{ name: mdata.name, img: "icons/svg/upgrade.svg", transfer: true, disabled: false, changes,
    description: `Installed robot mod: ${mdata.name}.` }];
}

/** Put a mod on a robot. modData is the mod item's toObject(). Returns the created item. */
export async function installRobotMod(robot, modData, mdata) {
  const second = mdata.name === "Armor Plating" && installedOn(robot).some((i) => i.name === "Armor Plating");
  const data = foundry.utils.deepClone(modData);
  delete data._id; delete data.folder;
  data.system = { ...(data.system ?? {}), quantity: 1, equipStatus: 1 };
  const record = { size: Number(mdata.size) || 1, armorItem: null, armorAdded: 0, source: modData };
  if (mdata.fx?.armor) {
    let armor = naturalArmor(robot);
    if (!armor) {
      [armor] = await robot.createEmbeddedDocuments("Item", [{ name: "Armor +0", type: "armor", img: "icons/equipment/chest/breastplate-riveted-steel.webp",
        system: { armor: 0, equipStatus: 3, locations: { head: true, torso: true, arms: true, legs: true } } }]);
    }
    const now = Number(armor.system.armor) || 0;
    const next = now + mdata.fx.armor;
    await armor.update({ "system.armor": next, name: /^armor\s*\+\d+/i.test(armor.name) ? `Armor +${next}` : armor.name });
    record.armorItem = armor.id; record.armorAdded = mdata.fx.armor;
  }
  data.effects = effectFor(mdata, robot, second);
  data.flags = { ...(data.flags ?? {}), [MOD]: { ...(data.flags?.[MOD] ?? {}), robotMod: record } };
  const [created] = await robot.createEmbeddedDocuments("Item", [data]);
  return created;
}

/** Take an installed mod off a robot. Returns the item data to hand back to the mechanic. */
export async function removeRobotMod(robot, item) {
  const rec = item.flags?.[MOD]?.robotMod ?? {};
  if (rec.armorItem && rec.armorAdded) {
    const armor = robot.items.get(rec.armorItem);
    if (armor) {
      const next = Math.max(0, (Number(armor.system.armor) || 0) - rec.armorAdded);
      await armor.update({ "system.armor": next, name: /^armor\s*\+\d+/i.test(armor.name) ? `Armor +${next}` : armor.name });
    }
  }
  const back = foundry.utils.deepClone(rec.source ?? item.toObject());
  delete back._id; delete back.folder;
  if (back.flags?.[MOD]) delete back.flags[MOD].robotMod;
  back.effects = [];
  back.system = { ...(back.system ?? {}), quantity: 1 };
  const wasPlating = item.name === "Armor Plating";
  await item.delete();
  // Only a second plating costs Pace: if one plating is left, it shouldn't carry the penalty.
  if (wasPlating) {
    const left = installedOn(robot).filter((i) => i.name === "Armor Plating");
    if (left.length === 1) {
      const ids = (left[0].effects?.map?.((e) => e.id) ?? []).filter(Boolean);
      if (ids.length && left[0].deleteEmbeddedDocuments) await left[0].deleteEmbeddedDocuments("ActiveEffect", ids);
      else if (left[0].effects?.length && !left[0].deleteEmbeddedDocuments) left[0].effects.length = 0;
    }
  }
  return back;
}
