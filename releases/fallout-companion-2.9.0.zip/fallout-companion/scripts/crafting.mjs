/**
 * Savage Fallout: weapon and armor mod installation.
 *
 * Each mod item carries machine-readable data in flags["fallout-companion"].mod (see the module's
 * crafting journal). Installing a mod snapshots the item's unmodded stats once (flags.modding.base),
 * records the mod in flags.modding.installed, and recomputes the item from the snapshot. Removing a
 * mod recomputes without it, so stats never drift.
 *
 * Entry points (game.modules.get("fallout-companion").api, also globalThis.SavageFallout):
 *   mastercraftedInstall({actor, componentsToConsume, productData, inventoryActor, kind})
 *       Called by the Mastercrafted recipe macro. Returns {success, consume}.
 *   installModDialog(actor?)   Standalone: pick a mod in the inventory, pick the item, roll, install.
 *   removeModDialog(actor?)    Pick a modded item and one of its mods, roll, strip it intact.
 *   recompute(itemData)        Pure: rebuild an item's data from its snapshot + installed mods.
 */

import { buildName } from "./naming.mjs";

const MOD = "fallout-companion";

/* ------------------------------------------------------------------ */
/*  Pure helpers (no Foundry globals)                                  */
/* ------------------------------------------------------------------ */

export const RANGE_LADDER = ["3/6/12", "5/10/20", "10/20/40", "12/24/48", "15/30/60", "20/40/80", "24/48/96", "30/60/120", "50/100/200"];
const DICE = [4, 6, 8, 10, 12];

const clone = (o) => JSON.parse(JSON.stringify(o ?? null));

export function stepRange(range, steps) {
  const r = String(range ?? "").trim();
  if (!steps || !/^\d+\/\d+\/\d+$/.test(r)) return range;
  let i = RANGE_LADDER.indexOf(r);
  if (i < 0) {
    const s = parseInt(r);
    i = 0;
    RANGE_LADDER.forEach((x, j) => { if (Math.abs(parseInt(x) - s) < Math.abs(parseInt(RANGE_LADDER[i]) - s)) i = j; });
  }
  // Mods can't push a weapon below step 2 or above step 9 (book p. "Range Steps").
  const lo = Math.min(i, 1);
  return RANGE_LADDER[Math.max(lo, Math.min(8, i + steps))];
}

export function addDamage(dmg, n) {
  if (!n || !dmg) return dmg;
  const m = String(dmg).trim().match(/^(.*?)([+-]\d+)?$/);
  const mod = parseInt(m[2] ?? "0") + n;
  return m[1] + (mod > 0 ? `+${mod}` : mod < 0 ? `${mod}` : "");
}

export function stepDie(die, steps) {
  if (!steps || !die) return die;
  const m = String(die).match(/^d(\d+)([+-]\d+)?$/);
  if (!m) return die;
  let idx = DICE.indexOf(parseInt(m[1])) + (parseInt(m[2] ?? "0") > 0 ? parseInt(m[2]) : 0);
  idx = Math.max(0, idx + steps);
  return idx < DICE.length ? `d${DICE[idx]}` : `d12+${idx - DICE.length + 1}`;
}

export function splitNotes(notes) {
  // Split on commas that are not inside parentheses.
  const out = []; let depth = 0, cur = "";
  for (const ch of String(notes ?? "")) {
    if (ch === "(") depth++;
    if (ch === ")") depth = Math.max(0, depth - 1);
    if (ch === "," && depth === 0) { if (cur.trim()) out.push(cur.trim()); cur = ""; continue; }
    cur += ch;
  }
  if (cur.trim()) out.push(cur.trim());
  return out;
}

const hasQ = (list, q) => list.some((x) => x.toLowerCase() === q.toLowerCase() || x.toLowerCase().startsWith(q.toLowerCase() + " ("));
const dropQ = (list, q) => list.filter((x) => !(x.toLowerCase() === q.toLowerCase() || x.toLowerCase().startsWith(q.toLowerCase() + " (")));

/** Raise "Name (N)" in the notes to at least n (plain form only, not "against fire" variants). */
function raiseValueQuality(list, label, n) {
  const re = new RegExp(`^${label} \\((\\d+)\\)$`, "i");
  const idx = list.findIndex((x) => re.test(x));
  if (idx >= 0) {
    const cur = parseInt(list[idx].match(re)[1]);
    if (n > cur) list[idx] = `${label} (${n})`;
    return list;
  }
  return [...list, `${label} (${n})`];
}

/** Apply one mod's fx to a system object in place. Returns lines of situational text. */
export function applyFx(sys, mod, { isTorso = false, isArmor = false } = {}) {
  const fx = mod.fx ?? {};
  const text = [];
  let notes = splitNotes(sys.notes);

  if (fx.dmgSet) sys.damage = fx.dmgSet;
  if (fx.dmg) sys.damage = addDamage(sys.damage, fx.dmg);
  if (fx.apSet !== undefined) sys.ap = fx.apSet;
  if (fx.ap) sys.ap = Math.max(0, (Number(sys.ap) || 0) + fx.ap);
  if (fx.rangeSet) sys.range = fx.rangeSet;
  if (fx.range) sys.range = stepRange(sys.range, fx.range);
  if (fx.cone && sys.templates) sys.templates.cone = true;
  if (fx.rofSet) sys.rof = fx.rofSet;
  if (fx.rof) sys.rof = (Number(sys.rof) || 1) + fx.rof;
  if (fx.shotsSet) sys.shots = fx.shotsSet;
  if (fx.shotsPct && sys.shots) sys.shots = Math.ceil(Number(sys.shots) * (1 + fx.shotsPct / 100));
  if (fx.ammo) sys.ammo = fx.ammo;
  if (fx.bonusDie) sys.bonusDamageDie = Math.max(Number(sys.bonusDamageDie) || 6, fx.bonusDie);
  if (fx.trait) {
    sys.actions ??= {};
    const cur = parseInt(sys.actions.traitMod || "0") || 0;
    const v = cur + fx.trait;
    sys.actions.traitMod = v ? (v > 0 ? `+${v}` : `${v}`) : "";
  }
  if (fx.minStr) sys.minStr = stepDie(sys.minStr, fx.minStr);
  if (fx.parry) sys.parry = (Number(sys.parry) || 0) + fx.parry;
  if (fx.armor) sys.armor = Math.min(fx.armorCap ?? Infinity, (Number(sys.armor) || 0) + fx.armor);
  if (fx.er) notes = raiseValueQuality(notes, "Energy Resistant", fx.er);
  if (fx.erAdd) {
    const re = /^Energy Resistant \((\d+)\)$/i;
    const cur = notes.map((x) => x.match(re)).find(Boolean);
    const v = Math.min(fx.erCap ?? 99, (cur ? parseInt(cur[1]) : 0) + fx.erAdd);
    notes = notes.filter((x) => !re.test(x));
    notes.push(`Energy Resistant (${v})`);
  }
  if (fx.tough) sys.toughness = (Number(sys.toughness) || 0) + fx.tough;
  if (fx.rad) notes = raiseValueQuality(notes, "Rad Shielded", fx.rad);
  if (fx.weight) sys.weight = Math.max(isArmor && Number(sys.weight) >= 1 ? 1 : 0, (Number(sys.weight) || 0) + fx.weight);
  if (fx.weightHalf) sys.weight = Math.max(1, Math.floor((Number(sys.weight) || 0) / 2));
  for (const q of fx.remove ?? []) notes = dropQ(notes, q);
  for (const q of fx.add ?? []) if (!hasQ(notes, q)) notes.push(q);
  if (fx.removeOr) {
    const [q, alt] = fx.removeOr;
    if (hasQ(notes, q)) notes = dropQ(notes, q);
    else if (alt?.startsWith("text:")) text.push(alt.slice(5));
  }
  if (fx.ifOneHanded && !hasQ(notes, "Two Hands")) {
    if (fx.ifOneHanded.minStr) sys.minStr = stepDie(sys.minStr, fx.ifOneHanded.minStr);
    for (const q of fx.ifOneHanded.add ?? []) if (!hasQ(notes, q)) notes.push(q);
  }
  if (fx.text) text.push(fx.text);
  if (fx.textTorso && isTorso) text.push(fx.textTorso);
  sys.notes = notes.join(", ");
  return text;
}

/** Plain-English list of what a mod's fx does, for the item description. */
export function describeFx(fx = {}, { isTorso = false } = {}) {
  const sg = (n) => (n > 0 ? `+${n}` : `${n}`);
  const steps = (n) => `${Math.abs(n)} step${Math.abs(n) === 1 ? "" : "s"}`;
  const out = [];
  if (fx.dmgSet) out.push(`Damage becomes ${fx.dmgSet}`);
  if (fx.dmg) out.push(`Damage ${sg(fx.dmg)}`);
  if (fx.apSet !== undefined) out.push(`AP becomes ${fx.apSet}`);
  if (fx.ap) out.push(`AP ${sg(fx.ap)}`);
  if (fx.rangeSet) out.push(`Range becomes ${fx.rangeSet}`);
  if (fx.range) out.push(`Range ${fx.range > 0 ? "up" : "down"} ${steps(fx.range)}`);
  if (fx.cone) out.push("fires a Cone Template");
  if (fx.rofSet) out.push(`RoF becomes ${fx.rofSet}`);
  if (fx.rof) out.push(`RoF ${sg(fx.rof)}`);
  if (fx.shotsSet) out.push(`Shots become ${fx.shotsSet}`);
  if (fx.shotsPct) out.push(fx.shotsPct === 100 ? "double Shots" : `Shots ${sg(fx.shotsPct)}%`);
  if (fx.ammo) out.push(`uses ${fx.ammo} ammo`);
  if (fx.bonusDie) out.push(`raise damage die d${fx.bonusDie}`);
  if (fx.trait) out.push(`${sg(fx.trait)} to attack rolls`);
  if (fx.minStr) out.push(`Min Str ${fx.minStr < 0 ? "lowered" : "raised"} ${steps(fx.minStr)}`);
  if (fx.parry) out.push(`Parry ${sg(fx.parry)}`);
  if (fx.armor) out.push(`Armor ${sg(fx.armor)}${fx.armorCap ? ` (to a maximum of ${fx.armorCap})` : ""}`);
  if (fx.tough) out.push(`Toughness ${sg(fx.tough)}`);
  if (fx.er) out.push(`Energy Resistant (${fx.er})`);
  if (fx.erAdd) out.push(`Energy Resistant ${sg(fx.erAdd)}${fx.erCap ? ` (to a maximum of ${fx.erCap})` : ""}`);
  if (fx.rad) out.push(`Rad Shielded (${fx.rad})`);
  for (const q of fx.add ?? []) out.push(`gains ${q}`);
  for (const q of fx.remove ?? []) out.push(`loses ${q}`);
  if (fx.removeOr) out.push(`loses ${fx.removeOr[0]}${fx.removeOr[1]?.startsWith("text:") ? ` (if it doesn't have it: ${fx.removeOr[1].slice(5)})` : ""}`);
  if (fx.ifOneHanded) {
    const o = fx.ifOneHanded, bits = [];
    if (o.minStr) bits.push(`Min Str ${o.minStr > 0 ? "raised" : "lowered"} ${steps(o.minStr)}`);
    for (const q of o.add ?? []) bits.push(`gains ${q}`);
    if (bits.length) out.push(`on a one-handed weapon: ${bits.join(", ")}`);
  }
  if (fx.weightHalf) out.push("weight halved");
  if (fx.weight) out.push(`weight ${sg(fx.weight)}`);
  if (fx.text) out.push(fx.text);
  if (fx.textTorso && isTorso) out.push(fx.textTorso);
  return out;
}

export const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

/**
 * Rebuild an item's name/system/description from flags.modding (base snapshot + installed list).
 * `itemData` is a plain object (item.toObject()). Live fields (equipped, quantity, loaded shots) are kept.
 */
export function recompute(itemData) {
  const m = itemData.flags?.[MOD]?.modding;
  if (!m?.base) return itemData;
  const live = itemData.system ?? {};
  const sys = clone(m.base.system);
  const isArmor = itemData.type === "armor";
  const isTorso = !!sys.locations?.torso;
  const lines = [];
  let price = Number(sys.price) || 0;
  for (const mod of m.installed ?? []) {
    applyFx(sys, mod, { isTorso, isArmor });
    const loc = sys.locations ?? {};
    // Chest pieces and Arm/Leg pairs pay double for a mod (a pair is two limbs).
    const chestDouble = isArmor && (loc.torso || loc.arms || loc.legs) && ["Material", "Upgrade", "Plating"].includes(mod.slot) && !m.base.clothing;
    price += (Number(mod.price) || 0) * (chestDouble ? 2 : 1);
    const what = describeFx(mod.fx, { isTorso });
    const slot = mod.size ? `${mod.slot} (${mod.size} slot${mod.size > 1 ? "s" : ""})` : mod.slot;
    lines.push(`<li><strong>${esc(mod.name)}</strong> <em>(${esc(slot)} mod)</em>${what.length ? ": " + esc(what.join("; ")) + "." : ""}</li>`);
  }
  sys.price = price;
  // keep live state
  for (const k of ["equipStatus", "quantity", "favorite", "equipped"]) if (k in live) sys[k] = live[k];
  if ("currentShots" in sys) sys.currentShots = Math.min(Number(live.currentShots ?? sys.shots) || 0, Number(sys.shots) || 0);
  sys.description = (m.base.description ?? "") + (lines.length ? `<h3>Installed Mods</h3><ul>${lines.join("")}</ul>` : "");

  // Name: built by the instance naming rules (naming.mjs). A hand-given name is kept until the
  // item is renamed back to its original name.
  const generated = buildName(m.base.name, m.installed ?? [], itemData.type === "armor" ? "armor" : "weapon");
  const current = itemData.name;
  if (current === m.base.name) m.nameLocked = false;
  else if (m.autoName && current && current !== m.autoName) m.nameLocked = true;
  m.autoName = generated;
  itemData.name = m.nameLocked ? current : generated;
  itemData.system = sys;
  return itemData;
}

/** Does `mod` (flag data) fit `item` (a plain item object or document)? Returns a reason string if not. */
export function fitProblem(item, mod) {
  const wantType = mod.kind === "weapon" ? "weapon" : "armor";
  if (item.type !== wantType) return "wrong item type";
  const modding = item.flags?.[MOD]?.modding;
  const base = modding?.base;
  const name = base?.name ?? item.name;
  const sys = base?.system ?? item.system ?? {};
  const f = mod.fits ?? {};
  // Add-on weapons can refuse generic mods: flags[MOD].ownModsOnly (only mods made for it by name)
  // or flags[MOD].noGenericSlots (slot names that refuse generic mods).
  const wf = item.flags?.[MOD] ?? {};
  const generic = !f.name?.length;
  if (generic && wf.ownModsOnly) return "only takes mods made for it";
  if (generic && wf.noGenericSlots?.includes(mod.slot)) return `no generic ${mod.slot} mods fit`;
  if (f.cat?.length && !f.cat.includes(sys.category)) return `only for ${f.cat.join(" / ")}`;
  if (f.name?.length && !f.name.some((n) => name.toLowerCase().includes(n.toLowerCase()))) return `only for ${f.name.join(", ")}`;
  if (f.notName?.some((n) => name.toLowerCase().includes(n.toLowerCase()))) return "doesn't fit this item";
  if (f.note && !String(sys.notes ?? "").toLowerCase().includes(f.note.toLowerCase())) return `needs ${f.note}`;
  const loc = sys.locations ?? {};
  if (f.loc?.length && !f.loc.some((l) => loc[l])) return `only on ${f.loc.join("/")} pieces`;
  if (f.notLoc?.some((l) => loc[l]) && !(f.loc?.some((l) => loc[l]))) return `not on ${f.notLoc.join("/")} pieces`;
  const installed = modding?.installed ?? [];
  if (mod.size) {
    // Slot-based (power armor): limited Mod slots, per-mod install limit, one mod per group.
    const cap = Number(item.flags?.[MOD]?.modSlots ?? 0);
    const used = installed.reduce((a, x) => a + (Number(x.size) || 0), 0);
    if (used + mod.size > cap) return `not enough free Mod slots (${cap - used} of ${cap} free, needs ${mod.size})`;
    if (mod.name && installed.filter((x) => x.name === mod.name).length >= (mod.max ?? 1)) return "already installed";
    if (mod.group && installed.some((x) => x.group === mod.group)) return `already has a ${mod.group} mod`;
    return null;
  }
  if (installed.some((x) => x.slot === mod.slot)) return `${mod.slot} slot already used`;
  return null;
}

/* ------------------------------------------------------------------ */
/*  Foundry glue                                                       */
/* ------------------------------------------------------------------ */

const modData = (item) => item?.flags?.[MOD]?.mod ?? null;

export function snapshotBase(itemData) {
  const flags = (itemData.flags ??= {});
  const f = (flags[MOD] ??= {});
  if (f.modding?.base) return f.modding;
  const sys = clone(itemData.system);
  const description = sys.description ?? "";
  delete sys.description;
  f.modding = {
    base: { name: itemData.name, system: sys, description, clothing: ["Clothing", "Outfits", "Armored Clothing", "Headgear"].includes(sys.category) },
    installed: [],
  };
  return f.modding;
}

export function isWildCard(actor) {
  return actor.type === "character" || !!actor.system?.wildcard;
}

async function rollInstall(actor, mod, verb, itemName) {
  const skillName = mod.skill ?? "Repair";
  const skill = actor.items.find((i) => i.type === "skill" && i.name.toLowerCase() === skillName.toLowerCase());
  const sides = skill?.system?.die?.sides ?? 4;
  const dieMod = skill ? Number(skill.system?.die?.modifier ?? 0) : -2;
  const wildSides = skill?.system?.["wild-die"]?.sides ?? skill?.system?.wildDie?.sides ?? 6;
  const missing = (mod.edges ?? []).filter((e) => !actor.items.some((i) => i.type === "edge" && i.name.toLowerCase() === e.toLowerCase()));
  const wounds = Math.min(3, Number(actor.system?.wounds?.value ?? 0));
  const fatigue = Number(actor.system?.fatigue?.value ?? 0);
  const parts = [];
  if (dieMod) parts.push([dieMod, skill ? "skill modifier" : "unskilled"]);
  if (missing.length) parts.push([-2, `missing ${missing.join(", ")}`]);
  if (wounds) parts.push([-wounds, "Wounds"]);
  if (fatigue) parts.push([-fatigue, "Fatigue"]);
  const total = parts.reduce((a, [v]) => a + v, 0);
  const t = total ? (total > 0 ? `+${total}` : `${total}`) : "";
  const formula = isWildCard(actor) ? `{1d${sides}x${t}, 1d${wildSides}x${t}}kh` : `1d${sides}x${t}`;
  const roll = await new Roll(formula).evaluate();
  const diceResults = roll.dice.map((d) => d.results[0]?.result);
  const critFail = isWildCard(actor) && diceResults.length >= 2 && diceResults.every((r) => r === 1);
  const success = !critFail && roll.total >= 4;
  const flavor = `<strong>${esc(skillName)}</strong> to ${verb} <em>${esc(itemName)}</em>` +
    (parts.length ? `<br><small>${parts.map(([v, l]) => `${v > 0 ? "+" : ""}${v} ${esc(l)}`).join(", ")}</small>` : "") +
    `<br>${critFail ? "<strong>Critical Failure.</strong>" : success ? (roll.total >= 8 ? "<strong>Success with a raise.</strong>" : "<strong>Success.</strong>") : "<strong>Failure.</strong>"} ` +
    `<small>(Takes ${mod.kind === "armor" && ["System", "Plating", "Reinforced"].includes(mod.slot) ? "an hour at a Power Armor Station" : "30 minutes at the right workbench"}.)</small>`;
  await roll.toMessage({ speaker: ChatMessage.getSpeaker({ actor }), flavor });
  return { success, critFail, roll };
}

async function pick(title, label, options, okLabel = "OK") {
  if (!options.length) return null;
  const opts = options.map((o) => `<option value="${esc(o.value)}" ${o.disabled ? "disabled" : ""}>${esc(o.label)}</option>`).join("");
  const content = `<div class="form-group"><label>${esc(label)}</label><div class="form-fields"><select name="choice" style="width:100%">${opts}</select></div></div>`;
  const result = await foundry.applications.api.DialogV2.wait({
    window: { title },
    content,
    buttons: [
      { action: "ok", label: okLabel, icon: "fas fa-check", default: true, callback: (event, button) => button.form.elements.choice.value },
      { action: "cancel", label: "Cancel", icon: "fas fa-times" },
    ],
    rejectClose: false,
  });
  return result && result !== "cancel" ? result : null;
}

function targetOptions(inv, mod) {
  return inv.items
    .filter((i) => i.type === (mod.kind === "weapon" ? "weapon" : "armor"))
    .map((i) => ({ item: i, why: fitProblem(i.toObject(), mod) }))
    .sort((a, b) => (a.why ? 1 : 0) - (b.why ? 1 : 0) || a.item.name.localeCompare(b.item.name))
    .map(({ item, why }) => ({ value: item.id, label: why ? `${item.name} (${why})` : item.name, disabled: !!why }));
}

export function buildInstalled(itemData, modItem, mod) {
  const modding = snapshotBase(itemData);
  modding.installed = [...(modding.installed ?? []), {
    name: modItem.name, kind: mod.kind, slot: mod.slot, tier: mod.tier, prefix: mod.prefix, fx: mod.fx, tags: mod.tags ?? [],
    skill: mod.skill, edges: mod.edges ?? [], size: mod.size, max: mod.max, group: mod.group,
    price: Number(modItem.system?.price) || 0,
    uuid: modItem._stats?.compendiumSource ?? modItem.flags?.core?.sourceId ?? modItem.uuid ?? null,
    itemData: (() => { const d = JSON.parse(JSON.stringify(modItem)); delete d._id; delete d.folder; delete d._key; if (d.system) d.system.quantity = 1; return d; })(),
    img: modItem.img,
  }];
  return recompute(itemData);
}

export async function chatResult(actor, html) {
  await ChatMessage.create({ speaker: ChatMessage.getSpeaker({ actor }), content: html });
}

export function summary(d) {
  const s = d.system;
  if (d.type === "weapon") return `Damage ${s.damage}, AP ${s.ap ?? 0}, Range ${s.range}, RoF ${s.rof}${s.shots ? `, Shots ${s.shots}` : ""}${s.notes ? ` — ${s.notes}` : ""}`;
  return `Armor ${s.armor}${s.minStr ? `, Min Str ${s.minStr}` : ""}${s.notes ? ` — ${s.notes}` : ""}`;
}

/** Mastercrafted recipe macro entry point. Never throws: Mastercrafted treats a thrown macro as success. */
export async function mastercraftedInstall({ actor, componentsToConsume, productData, inventoryActor, kind } = {}) {
  const FAIL = { success: false, consume: false };
  try {
    const inv = inventoryActor ?? actor;
    if (!actor || !inv) { ui.notifications.warn("Select the crafting actor first."); return FAIL; }
    let modItem = null, mod = null;
    for (const c of componentsToConsume ?? []) {
      const owned = inv.items.find((i) => i.name === c.name && modData(i));
      const item = owned ?? (await c.getItem?.());
      if (modData(item)) { modItem = item; mod = { ...modData(item), name: item.name }; break; }
    }
    if (!mod) { ui.notifications.error("That mod has no install data. Re-import it from the Savage Fallout compendium."); return FAIL; }
    if (kind && mod.kind !== kind) { ui.notifications.error(`${modItem.name} isn't ${kind === "armor" ? "an armor" : "a weapon"} mod.`); return FAIL; }

    const options = targetOptions(inv, mod);
    if (!options.some((o) => !o.disabled)) {
      ui.notifications.warn(`Nothing in ${inv.name}'s inventory can take ${modItem.name}.`);
      return FAIL;
    }
    const targetId = await pick(`Install ${modItem.name}`, `Install ${modItem.name} (${mod.slot}) on:`, options, "Install");
    if (!targetId) return FAIL;
    const target = inv.items.get(targetId);

    const { success, critFail } = await rollInstall(actor, mod, "install it on", target.name);
    if (!success) {
      ui.notifications.info(critFail ? "Critical Failure: nothing installed. Both parts are intact; try again after another 30 minutes." : "Install failed; you keep both parts.");
      return FAIL;
    }
    const newData = buildInstalled(target.toObject(), modItem.toObject(), mod);
    delete newData._id;
    for (const e of newData.effects ?? []) delete e._id;
    if (!Array.isArray(productData)) { ui.notifications.error("Mastercrafted didn't pass product data."); return FAIL; }
    productData[0] = newData;
    productData.length = Math.max(1, productData.length);
    await target.delete();
    await chatResult(actor, `<p><strong>${esc(target.name)}</strong> → <strong>${esc(newData.name)}</strong></p><p><small>${esc(summary(newData))}</small></p>`);
    return { success: true, consume: true };
  } catch (err) {
    console.error("Savage Fallout | mod install failed", err);
    ui.notifications.error("Mod install failed; nothing was changed. See the console (F12).");
    return FAIL;
  }
}

function resolveActor(actor) {
  return actor ?? canvas?.tokens?.controlled?.[0]?.actor ?? game.user.character ?? null;
}

/** Standalone install (no Mastercrafted): choose a mod you carry, then the item, roll, update in place. */
export async function installModDialog(actor) {
  actor = resolveActor(actor);
  if (!actor) return ui.notifications.warn("Select a token or assign a character first.");
  const mods = actor.items.filter((i) => modData(i));
  if (!mods.length) return ui.notifications.warn(`${actor.name} isn't carrying any mods.`);
  const modId = await pick("Install Mod", "Mod to install:", mods.map((m) => ({ value: m.id, label: `${m.name} (${modData(m).slot})` })), "Next");
  if (!modId) return;
  const modItem = actor.items.get(modId);
  const mod = { ...modData(modItem), name: modItem.name };
  const options = targetOptions(actor, mod);
  if (!options.some((o) => !o.disabled)) return ui.notifications.warn(`Nothing ${actor.name} carries can take ${modItem.name}.`);
  const targetId = await pick(`Install ${modItem.name}`, `Install ${modItem.name} (${mod.slot}) on:`, options, "Install");
  if (!targetId) return;
  const target = actor.items.get(targetId);
  const { success } = await rollInstall(actor, mod, "install it on", target.name);
  if (!success) return ui.notifications.info("Install failed; you keep both parts.");
  const newData = buildInstalled(target.toObject(), modItem.toObject(), mod);
  await target.update({ name: newData.name, system: newData.system, [`flags.${MOD}.modding`]: newData.flags[MOD].modding });
  const q = Number(modItem.system?.quantity ?? 1);
  if (q > 1) await modItem.update({ "system.quantity": q - 1 }); else await modItem.delete();
  await chatResult(actor, `<p><strong>${esc(target.name)}</strong> now has ${esc(modItem.name)}.</p><p><small>${esc(summary(newData))}</small></p>`);
}

/** Strip one installed mod intact (same roll as installing). */
export async function removeModDialog(actor) {
  actor = resolveActor(actor);
  if (!actor) return ui.notifications.warn("Select a token or assign a character first.");
  const modded = actor.items.filter((i) => (i.flags?.[MOD]?.modding?.installed ?? []).length);
  if (!modded.length) return ui.notifications.warn(`${actor.name} has no modded gear.`);
  const itemId = await pick("Strip Mod", "Item:", modded.map((i) => ({ value: i.id, label: i.name })), "Next");
  if (!itemId) return;
  const item = actor.items.get(itemId);
  const installed = item.flags[MOD].modding.installed;
  const idx = await pick(`Strip a mod from ${item.name}`, "Mod to remove:", installed.map((m, i) => ({ value: String(i), label: `${m.name} (${m.slot})` })), "Remove");
  if (idx === null) return;
  const entry = installed[Number(idx)];
  const { success } = await rollInstall(actor, entry, "remove it from", item.name);
  if (!success) return ui.notifications.info("Couldn't get it off cleanly; the mod stays installed.");
  const data = item.toObject();
  data.flags[MOD].modding.installed = installed.filter((_, i) => i !== Number(idx));
  recompute(data);
  await item.update({ name: data.name, system: data.system, [`flags.${MOD}.modding`]: data.flags[MOD].modding });
  const src = entry.uuid ? await fromUuid(entry.uuid) : null;
  if (src) {
    const existing = actor.items.find((i) => i.name === src.name);
    if (existing) await existing.update({ "system.quantity": Number(existing.system.quantity ?? 1) + 1 });
    else await actor.createEmbeddedDocuments("Item", [src.toObject()]);
  } else ui.notifications.warn(`Couldn't find ${entry.name} in a compendium to give back; add it to the inventory by hand.`);
  await chatResult(actor, `<p>Removed <strong>${esc(entry.name)}</strong> from <strong>${esc(item.name)}</strong> → <strong>${esc(data.name)}</strong>.</p>`);
}


/* ------------------------------------------------------------------ */
/*  Crafting v3: building items from recipes, teaching recipes          */
/* ------------------------------------------------------------------ */

const LEVELS = () => CONST.DOCUMENT_OWNERSHIP_LEVELS;
export const hasEdge = (actor, e) => actor.items.some((i) => i.type === "edge" && i.name.toLowerCase() === e.toLowerCase());

/** Generic SWADE-style trait roll with listed modifiers. Returns {success, raise, critFail, total}. */
export async function skillRoll(actor, skillName, extra, head, foot = "") {
  const skill = actor.items.find((i) => i.type === "skill" && i.name.toLowerCase() === skillName.toLowerCase());
  const sides = skill?.system?.die?.sides ?? 4;
  const dieMod = skill ? Number(skill.system?.die?.modifier ?? 0) : -2;
  const wildSides = skill?.system?.["wild-die"]?.sides ?? skill?.system?.wildDie?.sides ?? 6;
  const wounds = Math.min(3, Number(actor.system?.wounds?.value ?? 0));
  const fatigue = Number(actor.system?.fatigue?.value ?? 0);
  const parts = [];
  if (dieMod) parts.push([dieMod, skill ? "skill modifier" : "unskilled"]);
  for (const p of extra) if (p[0]) parts.push(p);
  if (wounds) parts.push([-wounds, "Wounds"]);
  if (fatigue) parts.push([-fatigue, "Fatigue"]);
  const total = parts.reduce((a, [v]) => a + v, 0);
  const t = total ? (total > 0 ? `+${total}` : `${total}`) : "";
  const formula = isWildCard(actor) ? `{1d${sides}x${t}, 1d${wildSides}x${t}}kh` : `1d${sides}x${t}`;
  const roll = await new Roll(formula).evaluate();
  const faces = roll.dice.map((d) => d.results[0]?.result);
  const critFail = isWildCard(actor) && faces.length >= 2 && faces.every((r) => r === 1);
  const success = !critFail && roll.total >= 4;
  const raise = success && roll.total >= 8;
  const flavor = `<strong>${esc(skillName)}</strong>: ${head}` +
    (parts.length ? `<br><small>${parts.map(([v, l]) => `${v > 0 ? "+" : ""}${v} ${esc(l)}`).join(", ")}</small>` : "") +
    `<br><strong>${critFail ? "Critical Failure." : raise ? "Success with a raise." : success ? "Success." : "Failure."}</strong>` +
    (foot ? ` <small>${foot}</small>` : "");
  await roll.toMessage({ speaker: ChatMessage.getSpeaker({ actor }), flavor });
  return { success, raise, critFail, total: roll.total };
}

/** Remove part of the components Mastercrafted would have consumed (used for a successful salvage roll). */
async function consumeFraction(inv, components, keepHalf) {
  const qPath = "system.quantity";
  const merged = {};
  for (const c of components ?? []) merged[c.name] = (merged[c.name] ?? 0) + Number(c.quantity ?? 1);
  const updates = [], deletes = [];
  for (const [name, qty] of Object.entries(merged)) {
    const lose = keepHalf ? qty - Math.floor(qty / 2) : qty;
    let left = lose;
    for (const item of inv.items.filter((i) => i.name === name)) {
      if (left <= 0) break;
      const have = Number(foundry.utils.getProperty(item, qPath) ?? 1);
      if (have > left) { updates.push({ _id: item.id, [qPath]: have - left }); left = 0; }
      else { deletes.push(item.id); left -= have; }
    }
  }
  if (updates.length) await inv.updateEmbeddedDocuments("Item", updates);
  if (deletes.length) await inv.deleteEmbeddedDocuments("Item", deletes);
}

export async function drawMishap() {
  const pack = game.packs.get(`${MOD}.fallout-rollable-tables`);
  const entry = pack?.index.find((e) => e.name === "Crafting Mishap");
  if (!entry) return;
  const table = await pack.getDocument(entry._id);
  await table.draw();
}

/**
 * Mastercrafted build-recipe macro entry point. spec comes from the recipe:
 * {name, edges, anyEdges, skill, complexity, mod, bonusEdges, time, station, camp}
 */
export async function mastercraftedCraft({ actor, componentsToConsume, productData, inventoryActor, spec } = {}) {
  const FAIL = { success: false, consume: false };
  try {
    const inv = inventoryActor ?? actor;
    if (!actor) { ui.notifications.warn("Select the crafting character first."); return FAIL; }
    const missing = (spec.edges ?? []).filter((e) => !hasEdge(actor, e));
    if (missing.length) {
      ui.notifications.warn(`${actor.name} needs ${missing.join(" and ")} to craft ${spec.name}.`);
      return FAIL;
    }
    if ((spec.anyEdges ?? []).length && !spec.anyEdges.some((e) => hasEdge(actor, e))) {
      ui.notifications.warn(`${actor.name} needs ${spec.anyEdges.join(" or ")} to craft ${spec.name}.`);
      return FAIL;
    }
    const extra = [[spec.mod ?? 0, `${spec.complexity}`]];
    const governing = (spec.bonusEdges ?? []).find((e) => hasEdge(actor, e) || hasEdge(actor, `Improved ${e}`));
    const fixIt = (spec.skill ?? "Repair") === "Repair" && hasEdge(actor, "Mr. Fix It");
    if (governing && !fixIt) extra.push([2, governing]);
    const head = `crafting <em>${esc(spec.name)}</em>`;
    const foot = `(${esc(spec.station || "station")}; base time ${esc(spec.time ?? "1 hour")}.)`;
    const r = await skillRoll(actor, spec.skill ?? "Repair", extra, head, foot);
    if (r.success) {
      let timeNote = spec.time ?? "";
      if (r.raise) timeNote = `${governing ? "a quarter" : "half"} of ${spec.time} (raise)`;
      if (r.raise && spec.camp && Array.isArray(productData) && productData[0]?.system) {
        productData[0].system.quantity = Number(productData[0].system.quantity ?? 1) * 2;
        timeNote += "; the raise makes a second serving";
      }
      await chatResult(actor, `<p><strong>${esc(actor.name)}</strong> crafted <strong>${esc(spec.name)}</strong>${timeNote ? ` <small>(${esc(timeNote)})</small>` : ""}.</p>`);
      return { success: true, consume: true };
    }
    if (r.critFail) {
      await chatResult(actor, `<p><strong>Critical Failure:</strong> all Resources and ingredients for ${esc(spec.name)} are lost. Rolling on the Crafting Mishap table.</p>`);
      await drawMishap();
      return { success: false, consume: true };
    }
    const salvage = await skillRoll(actor, spec.skill ?? "Repair", [...extra, [-2, "salvage"]], `salvage roll for <em>${esc(spec.name)}</em>`);
    if (salvage.success) {
      await consumeFraction(inv, componentsToConsume, true);
      await chatResult(actor, `<p>${esc(spec.name)} wasn't made, but ${esc(actor.name)} salvaged half the materials (rounded down).</p>`);
      return FAIL;
    }
    await chatResult(actor, `<p>${esc(spec.name)} wasn't made, and the materials are lost.</p>`);
    return { success: false, consume: true };
  } catch (err) {
    console.error("Savage Fallout | crafting failed", err);
    ui.notifications.error("Crafting failed; nothing was spent. See the console (F12).");
    return FAIL;
  }
}

/** GM: import or update the Savage Fallout recipe books into the world's Mastercrafted folder. Keeps what players have learned. */
export async function setupCraftingBooks() {
  if (!game.user.isGM) return ui.notifications.warn("Only the GM can set up the recipe books.");
  const L = LEVELS();
  const pack = game.packs.get(`${MOD}.fallout-recipes`);
  if (!pack) return ui.notifications.error("Recipe compendium not found.");
  let mcName = "";
  try { mcName = game.settings.get("mastercrafted", "mainFolderName") ?? ""; } catch (e) { /* Mastercrafted not active */ }
  let root = game.folders.find((f) => f.type === "JournalEntry" && !f.folder && (mcName ? f.name === mcName : f.flags?.mastercrafted?.mainMastercraftedFolder))
    ?? game.folders.find((f) => f.type === "JournalEntry" && !f.folder && f.name === "Mastercrafted");
  if (!root) root = await Folder.create({ name: mcName || "Mastercrafted", type: "JournalEntry", flags: { mastercrafted: { mainMastercraftedFolder: true } } });
  try { if (!mcName) await game.settings.set("mastercrafted", "mainFolderName", root.name); } catch (e) { /* ignore */ }

  const map = {};
  const folders = [...pack.folders.contents].sort((a, b) => a.depth - b.depth);
  for (const pf of folders) {
    const parent = pf.folder ? map[pf.folder.id] : root.id;
    let wf = game.folders.find((f) => f.type === "JournalEntry" && f.name === pf.name && (f.folder?.id ?? null) === parent);
    if (!wf) wf = await Folder.create({ name: pf.name, type: "JournalEntry", folder: parent, sorting: "m", sort: pf.sort });
    map[pf.id] = wf.id;
  }
  let created = 0, updated = 0;
  for (const doc of await pack.getDocuments()) {
    const vis = doc.flags?.[MOD]?.visibility ?? "learned";
    const folder = map[doc.folder?.id] ?? root.id;
    const existing = game.journal.get(doc.id);
    if (!existing) {
      const data = game.journal.fromCompendium(doc, { keepId: true, clearOwnership: true });
      data.folder = folder;
      data.ownership = { default: vis === "everyone" ? L.OBSERVER : L.NONE, [game.user.id]: L.OWNER };
      for (const p of data.pages ?? []) p.ownership = { default: L.INHERIT };
      await JournalEntry.create(data, { keepId: true });
      created++;
    } else {
      await existing.update({ name: doc.name, folder, flags: doc.toObject().flags });
      const ups = [], adds = [];
      for (const p of doc.pages) {
        const pd = p.toObject();
        if (existing.pages.get(p.id)) ups.push({ _id: p.id, name: pd.name, text: pd.text, flags: pd.flags, sort: pd.sort });
        else { pd.ownership = { default: L.INHERIT }; adds.push(pd); }
      }
      if (ups.length) await existing.updateEmbeddedDocuments("JournalEntryPage", ups);
      if (adds.length) await existing.createEmbeddedDocuments("JournalEntryPage", adds, { keepId: true });
      updated++;
    }
  }
  ui.notifications.info(`Savage Fallout recipe books: ${created} imported, ${updated} updated. Learned recipes were kept.`);
}

/** GM: tick the recipes a character knows in one book (unticking forgets). */
export async function teachRecipeDialog(actor) {
  if (!game.user.isGM) return ui.notifications.warn("Only the GM can teach recipes.");
  const L = LEVELS();
  actor = actor ?? canvas?.tokens?.controlled?.[0]?.actor ?? null;
  if (!actor) {
    const pcs = game.actors.filter((a) => a.hasPlayerOwner).sort((a, b) => a.name.localeCompare(b.name));
    const id = await pick("Teach Recipes", "Character:", pcs.map((a) => ({ value: a.id, label: a.name })), "Next");
    if (!id) return;
    actor = game.actors.get(id);
  }
  const users = game.users.filter((u) => !u.isGM && actor.testUserPermission(u, "OWNER"));
  if (!users.length) return ui.notifications.warn(`${actor.name} has no player owner to teach.`);
  const books = game.journal.filter((j) => j.flags?.[MOD]?.visibility === "learned").sort((a, b) => a.name.localeCompare(b.name));
  if (!books.length) return ui.notifications.warn("No hidden recipe books found. Run Set Up Crafting Books first.");
  const knownIn = (b) => b.pages.filter((p) => users.every((u) => p.testUserPermission(u, "OBSERVER"))).length;
  const bookId = await pick(`Teach ${actor.name}`, "Recipe book:", books.map((b) => ({ value: b.id, label: `${b.name} (${knownIn(b)}/${b.pages.size} known)` })), "Next");
  if (!bookId) return;
  const book = game.journal.get(bookId);
  const pages = [...book.pages.contents].sort((a, b) => a.sort - b.sort);
  const rows = pages.map((p) => {
    const known = users.every((u) => p.testUserPermission(u, "OBSERVER"));
    return `<label style="display:flex;gap:.5em;align-items:center"><input type="checkbox" name="r" value="${p.id}" ${known ? "checked" : ""}> ${esc(p.name)}</label>`;
  }).join("");
  const content = `<p>Tick what <strong>${esc(actor.name)}</strong> knows from <em>${esc(book.name)}</em>. Unticking forgets a recipe.</p>
    <p><label><input type="checkbox" name="all"> <em>All recipes in this book</em></label></p>
    <div style="max-height:420px;overflow:auto;columns:2">${rows}</div>`;
  const chosen = await foundry.applications.api.DialogV2.wait({
    window: { title: `Teach ${actor.name}: ${book.name}` }, content, position: { width: 560 },
    render: (event, dialog) => {
      const root = dialog.element ?? event?.target?.element;
      const all = root?.querySelector("input[name=all]");
      all?.addEventListener("change", () => root.querySelectorAll("input[name=r]").forEach((c) => { c.checked = all.checked; }));
    },
    buttons: [
      { action: "ok", label: "Save", icon: "fas fa-book", default: true, callback: (ev, btn) => [...btn.form.querySelectorAll("input[name=r]")].filter((c) => c.checked).map((c) => c.value) },
      { action: "cancel", label: "Cancel", icon: "fas fa-times" }],
    rejectClose: false,
  });
  if (!Array.isArray(chosen)) return;
  const learned = [], forgotten = [], ups = [];
  for (const p of pages) {
    const was = users.every((u) => p.testUserPermission(u, "OBSERVER"));
    const now = chosen.includes(p.id);
    if (was === now) continue;
    const upd = { _id: p.id };
    for (const u of users) upd[`ownership.${u.id}`] = now ? L.OBSERVER : L.NONE;
    ups.push(upd);
    (now ? learned : forgotten).push(p.name);
  }
  if (ups.length) await book.updateEmbeddedDocuments("JournalEntryPage", ups);
  const bookUpd = {};
  for (const u of users) bookUpd[`ownership.${u.id}`] = chosen.length ? Math.max(L.LIMITED, book.ownership[u.id] ?? 0) : L.NONE;
  await book.update(bookUpd);
  if (learned.length || forgotten.length) {
    const msg = (learned.length ? `<p><strong>${esc(actor.name)}</strong> learned: ${learned.map(esc).join(", ")}.</p>` : "") +
      (forgotten.length ? `<p><strong>${esc(actor.name)}</strong> no longer has: ${forgotten.map(esc).join(", ")}.</p>` : "");
    await ChatMessage.create({ content: msg, whisper: [game.user.id, ...users.map((u) => u.id)] });
  }
}

const api = { mastercraftedCraft, setupCraftingBooks, teachRecipeDialog, mastercraftedInstall, installModDialog, removeModDialog, recompute, fitProblem, applyFx, stepRange, addDamage, stepDie };

if (typeof Hooks !== "undefined") {
  Hooks.once("init", () => {
    const m = game.modules.get(MOD);
    if (m) m.api = api;
    globalThis.SavageFallout = api;
  });
}

export default api;
