/**
 * Savage Fallout: consumables that do their job when used.
 *
 * Chems and food with simple bonuses already carry Active Effects that SWADE applies on use. This file
 * handles the ones a bonus can't express: healing, removing Rad Fatigue, Addictol, and the Jet family.
 * Items are matched by name, so copies already in a world work too.
 *
 * Trigger: SWADE's consume step (patched on ready), with a fallback that notices a charge or quantity
 * going down on the user's own update. Each use is handled once.
 */
const MOD = "fallout-companion";
const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

/* ------------------------------------------------------------------ actor helpers */

async function say(actor, html) {
  await ChatMessage.create({ speaker: ChatMessage.getSpeaker({ actor }), content: html });
}
function isShaken(actor) {
  return !!(actor.statuses?.has?.("shaken") || actor.system?.status?.isShaken);
}
async function unshake(actor) {
  if (!isShaken(actor)) return false;
  try { await actor.toggleStatusEffect("shaken", { active: false }); }
  catch (e) { await actor.update({ "system.status.isShaken": false }); }
  return true;
}
async function heal(actor, n) {
  const w = Number(actor.system?.wounds?.value) || 0;
  const healed = Math.min(w, n);
  if (healed) await actor.update({ "system.wounds.value": w - healed });
  return healed;
}
async function fatigue(actor, delta) {
  const f = Number(actor.system?.fatigue?.value) || 0;
  const max = Number(actor.system?.fatigue?.max) || 2;
  const next = Math.max(0, Math.min(max, f + delta));
  if (next !== f) await actor.update({ "system.fatigue.value": next });
  return next - f;
}
async function vigor(actor, why) {
  const r = await actor.rollAttribute?.("vigor", { flavour: why, title: `Vigor: ${why}` });
  const roll = Array.isArray(r) ? r[0] : r;
  if (!roll) return null;
  const tn = Number(roll.targetNumber ?? 4) || 4;
  const crit = typeof roll.isCritfail === "function" ? roll.isCritfail() : !!roll.isCritfail;
  return !crit && Number(roll.total) >= tn;
}
async function reminder(actor, item, label, duration) {
  await actor.createEmbeddedDocuments("ActiveEffect", [{
    name: label, img: item.img, disabled: false, transfer: false,
    duration: duration ?? {}, description: `From ${item.name}.`,
    flags: { [MOD]: { reminder: true } },
  }]);
}

/* ------------------------------------------------------------------ what each item does */

const USES = {
  "Stimpak": async (actor) => {
    const s = await unshake(actor);
    const h = await heal(actor, 1);
    return `${s ? "No longer Shaken. " : ""}${h ? "Heals 1 Wound" : "No Wounds to heal"}. Also stabilizes a hero who's Bleeding Out. <em>Only Wounds from the last hour (the Golden Hour) can be healed; the GM can undo this if the Wound is older.</em>`;
  },
  "Stimpak (Diluted)": async (actor) => {
    const s = await unshake(actor);
    if (!(Number(actor.system?.wounds?.value) > 0)) return `${s ? "No longer Shaken. " : ""}No Wounds to heal. Also stabilizes a hero who's Bleeding Out.`;
    const ok = await vigor(actor, "Diluted Stimpak");
    if (ok === null) return `${s ? "No longer Shaken. " : ""}Vigor roll skipped; no Wound healed.`;
    const h = ok ? await heal(actor, 1) : 0;
    return `${s ? "No longer Shaken. " : ""}${h ? "Vigor succeeded: heals 1 Wound." : "Vigor failed: the Wound stays."} <em>Golden Hour Wounds only.</em>`;
  },
  "Super Stimpak": async (actor, item) => {
    const s = await unshake(actor);
    const h = await heal(actor, 2);
    const f = await fatigue(actor, 1);
    await reminder(actor, item, "Super Stimpak crash: Fatigued (remove the Fatigue when this ends)", { seconds: 3600 });
    return `${s ? "No longer Shaken. " : ""}Heals ${h} Wound${h === 1 ? "" : "s"}${f ? "; Fatigued for an hour" : ""}. <em>Two Golden Hour Wounds, or one Wound of any age: the GM can adjust.</em>`;
  },
  "Healing Salve": async (actor) => {
    const s = await unshake(actor);
    return s ? "No longer Shaken." : "Not Shaken. (In a Healing roll, a salve counts as medical supplies for +1.)";
  },
  "RadAway": async (actor) => {
    const f = await fatigue(actor, -1);
    return f ? "Removes 1 level of Rad Fatigue. <em>Takes 10 minutes; not in combat.</em>" : "No Fatigue to remove.";
  },
  "RadAway (Diluted)": async (actor) => {
    if (!(Number(actor.system?.fatigue?.value) > 0)) return "No Fatigue to remove.";
    const ok = await vigor(actor, "Diluted RadAway");
    if (!ok) return ok === null ? "Vigor roll skipped." : "Vigor failed: the Rad Fatigue stays.";
    await fatigue(actor, -1);
    return "Vigor succeeded: removes 1 level of Rad Fatigue.";
  },
  "Addictol": async (actor, item) => {
    const habits = actor.items.filter((i) => i.type === "hindrance" && /habit|addict/i.test(i.name) && !/ultra jet/i.test(i.name));
    let removed = [];
    if (habits.length) {
      const rows = habits.map((h) => `<label style="display:block"><input type="checkbox" name="h" value="${h.id}" checked> ${esc(h.name)}</label>`).join("");
      const ids = await foundry.applications.api.DialogV2.wait({
        window: { title: "Addictol" }, rejectClose: false,
        content: `<p>Remove which addictions gained in play? (Habits taken at character creation, and Ultra Jet, don't go.)</p>${rows}`,
        buttons: [{ action: "ok", label: "Remove", default: true, callback: (ev, btn) => [...btn.form.querySelectorAll("input[name=h]:checked")].map((x) => x.value) },
                  { action: "cancel", label: "Cancel" }],
      });
      if (Array.isArray(ids) && ids.length) { removed = habits.filter((h) => ids.includes(h.id)).map((h) => h.name); await actor.deleteEmbeddedDocuments("Item", ids); }
    }
    await fatigue(actor, 1);
    await reminder(actor, item, "Addictol nausea: Fatigued (remove the Fatigue when this ends)", { seconds: 3600 });
    return `${removed.length ? `Removed: ${removed.map(esc).join(", ")}. ` : "No addictions removed. "}Fatigued (nausea) for the hour it takes to work.`;
  },
  "Jet": async (actor, item) => { await reminder(actor, item, "Jet: ignore 2 points of Multi-Action penalties", { rounds: 1 }); return "Ignore 2 points of Multi-Action penalties this round."; },
  "Jet Fuel": async (actor, item) => { await reminder(actor, item, "Jet Fuel: ignore 1 point of Multi-Action penalties (this scene)", {}); return "Ignore 1 point of Multi-Action penalties for the scene. <em>Remove the reminder when the scene ends.</em>"; },
  "Ultra Jet": async (actor, item) => { await reminder(actor, item, "Ultra Jet: ignore 4 points of Multi-Action penalties", { rounds: 1 }); return "Ignore 4 points of Multi-Action penalties this round."; },
};

/* ------------------------------------------------------------------ dispatch */

const recent = new Map();   // item id -> time handled, so one use runs once
async function handleUse(item) {
  const fn = USES[item?.name];
  const actor = item?.actor ?? item?.parent;
  if (!fn || !actor || !actor.isOwner) return;
  const now = Date.now();
  if (now - (recent.get(item.id) ?? 0) < 1500) return;
  recent.set(item.id, now);
  try {
    const text = await fn(actor, item);
    if (text) await say(actor, `<p><strong>${esc(actor.name)}</strong> uses <strong>${esc(item.name)}</strong>.</p><p>${text}</p>`);
  } catch (err) {
    console.error("Savage Fallout | consumable failed", err);
    ui.notifications.error(`${item.name}: ${err.message}`);
  }
}
export { USES, handleUse };

const total = (data) => {
  const ch = data?.system?.charges?.charges;
  const c = Array.isArray(ch) ? ch.reduce((a, x) => a + (Number(x.value) || 0), 0) : 0;
  return { q: Number(data?.system?.quantity ?? 1) || 0, c };
};

Hooks.once("ready", () => {
  // 1. SWADE's own consume step, if the item class has one.
  const cls = CONFIG.Item.documentClass;
  for (const name of ["consume", "consumeCharges"]) {
    const orig = cls?.prototype?.[name];
    if (typeof orig !== "function" || orig.__sfWrapped) continue;
    const wrapped = async function (...args) {
      const snapshot = { name: this.name, id: this.id, actor: this.actor, img: this.img };
      const out = await orig.apply(this, args);
      if (USES[snapshot.name]) handleUse(this.actor ? this : { ...snapshot, parent: snapshot.actor });
      return out;
    };
    wrapped.__sfWrapped = true;
    cls.prototype[name] = wrapped;
  }
});

// 2. SWADE's consume hook, if it fires.
Hooks.on("swadeConsumeItem", (item) => { if (USES[item?.name]) handleUse(item); });

// 3. Fallback: the user's own update that spends a charge.
Hooks.on("preUpdateItem", (item, changes, options) => {
  if (USES[item.name]) options.sfBefore = total(item);
});
Hooks.on("updateItem", (item, changes, options, userId) => {
  if (!USES[item.name] || userId !== game.user.id || !options.sfBefore) return;
  const after = total(item);
  // Only a charge going down counts; editing the quantity by hand (selling, dropping) doesn't.
  if (after.c < options.sfBefore.c) handleUse(item);
});
