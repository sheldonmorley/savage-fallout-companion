/**
 * Savage Fallout: instance naming rules for modded gear (after Fallout 4's INNR).
 *
 * HOW IT WORKS
 * Each item kind (weapon, armor) has an ordered list of RULESETS, read left to right, and the
 * name is built in that order. Everything before the `{ base: true }` ruleset is a prefix;
 * everything after it is a suffix.
 *
 * Inside a ruleset, the RULES are tried top to bottom and the FIRST ONE THAT MATCHES WINS; the
 * ruleset then contributes its text and the engine moves on. Put specific combinations first and
 * generic fallbacks last.
 *
 * A rule is one of:
 *   { when: {...}, text: "Recon Scoped" }   literal text when the condition matches
 *   { fromSlot: "Muzzle" }                  the prefix of the mod installed in that slot
 *   { fromSlot: "Power Armor", limit: 2 }   ...up to N mods from a multi-mod slot, newest first
 * A ruleset may instead be { unclaimed: true }: every installed mod no earlier ruleset used,
 * newest first. It's a safety net so a new slot never vanishes from the name.
 *
 * CONDITIONS (`when`, optional on fromSlot rules) test the item's TAGS:
 *   all:  every tag must be present        any:  at least one must be present
 *   none: none may be present
 * Tags are built from the installed mods, lower-case with spaces as hyphens:
 *   slot:muzzle   mod:large-magazine   prefix:calibrated
 *   plus any extra tags a mod lists in flags["fallout-companion"].mod.tags (e.g. "legendary:two-shot").
 *
 * Text rules "use up" the mods named in their condition, so the unclaimed ruleset won't repeat them.
 *
 * PERFORMANCE: the rules are compiled once (tag lists become Sets). Naming an item builds one Set of
 * its tags and makes one pass over the rulesets, so cost grows with the number of rulesets, not
 * with how many mods exist in the game.
 *
 * MANUAL NAMES: if someone renames a modded item by hand, the generator stops touching its name.
 * Renaming it back to the item's original name hands control back to the generator.
 */

export const NAMING_RULES = {
  weapon: [
    // 0. Legendary effects (no legendary mods yet; tag a mod "legendary:two-shot" to use this).
    { id: "legendary", rules: [
      { when: { all: ["legendary:two-shot"] }, text: "Two Shot" },
    ] },
    // 1. Muzzle: "Suppressed", "Compensated", "Bayoneted"...
    { id: "muzzle", rules: [{ fromSlot: "Muzzle" }] },
    // 2. Magazine: "Large", "Quick"...
    { id: "magazine", rules: [{ fromSlot: "Magazine" }] },
    // 3. Receiver: "Calibrated", "Automatic", caliber conversions...
    { id: "receiver", rules: [{ fromSlot: "Receiver" }] },
    // 4. Energy capacitor: "Boosted", "Agitated", "Six-Crank"...
    { id: "capacitor", rules: [{ fromSlot: "Capacitor" }] },
    // 5. Barrel: "Long", "Ported", "Sawed-Off"...
    { id: "barrel", rules: [{ fromSlot: "Barrel" }] },
    // 6. Sights: "Scoped", "Recon", "Night"...
    { id: "sights", rules: [{ fromSlot: "Sights" }] },
    // 7. Grip or stock: "Comfortable", "Marksman's"...
    { id: "grip", rules: [{ fromSlot: "Grip/Stock" }] },
    // 8. Melee upgrades: "Serrated", "Heated"...
    { id: "melee", rules: [{ fromSlot: "Melee" }] },
    // Safety net for any slot not named above.
    { id: "other", unclaimed: true },
    // The anchor: the weapon's own name ("10mm Pistol", "Laser Rifle").
    { id: "base", base: true },
    // Suffixes go here. Example (disabled): a long barrel plus a long scope adds "Sniper".
    // { id: "class", rules: [ { when: { all: ["prefix:long", "slot:sights"], any: ["prefix:long-scoped"] }, text: "Sniper" } ] },
  ],

  armor: [
    { id: "legendary", rules: [] },
    // Power armor suits take up to two mod names, newest first ("Jetpack Targeting X-01").
    { id: "powerArmor", rules: [{ fromSlot: "Power Armor", limit: 2 }] },
    { id: "weave", rules: [{ fromSlot: "Weave" }] },
    { id: "upgrade", rules: [{ fromSlot: "Upgrade" }] },
    { id: "lining", rules: [{ fromSlot: "Lining" }] },
    { id: "material", rules: [{ fromSlot: "Material" }] },
    { id: "other", unclaimed: true },
    { id: "base", base: true },
  ],
};

/* ------------------------------------------------------------------ engine */

export const tag = (s) => String(s ?? "").trim().toLowerCase().replace(/\s+/g, "-");
const tagged = (prefix, s) => `${prefix}:${tag(s)}`;

function compileWhen(w) {
  if (!w) return null;
  return {
    all: new Set((w.all ?? []).map(tag)),
    any: new Set((w.any ?? []).map(tag)),
    none: new Set((w.none ?? []).map(tag)),
  };
}

function compile(rulesets) {
  return rulesets.map((rs) => ({
    id: rs.id,
    base: !!rs.base,
    unclaimed: !!rs.unclaimed,
    rules: (rs.rules ?? []).map((r) => ({
      text: r.text ?? null,
      fromSlot: r.fromSlot != null ? tag(r.fromSlot) : null,
      limit: r.limit ?? 1,
      when: compileWhen(r.when),
    })),
  }));
}

const COMPILED = new Map();
function compiledFor(kind) {
  if (!COMPILED.has(kind)) COMPILED.set(kind, compile(NAMING_RULES[kind] ?? NAMING_RULES.weapon));
  return COMPILED.get(kind);
}
/** Call after editing NAMING_RULES at runtime (e.g. from a world script) to rebuild the cache. */
export function resetNamingCache() { COMPILED.clear(); }

function matches(when, tags) {
  if (!when) return true;
  for (const t of when.all) if (!tags.has(t)) return false;
  if (when.any.size && ![...when.any].some((t) => tags.has(t))) return false;
  for (const t of when.none) if (tags.has(t)) return false;
  return true;
}

function modTags(m) {
  const t = [tagged("slot", m.slot), tagged("mod", m.name)];
  if (m.prefix) t.push(tagged("prefix", m.prefix));
  for (const x of m.tags ?? []) t.push(tag(x));
  return t;
}

/**
 * Build a name from the base name and the installed-mod list (oldest first, as stored).
 * kind: "weapon" | "armor".
 */
export function buildName(baseName, installed = [], kind = "weapon") {
  const newestFirst = [...installed].reverse();
  const tagsOf = new Map(newestFirst.map((m) => [m, modTags(m)]));
  const tags = new Set([...tagsOf.values()].flat());
  const used = new Set();
  const prefix = [], suffix = [];
  let pastBase = false;

  for (const rs of compiledFor(kind)) {
    if (rs.base) { pastBase = true; continue; }
    let out = [];
    if (rs.unclaimed) {
      for (const m of newestFirst) if (!used.has(m) && m.prefix) { used.add(m); out.push(m.prefix); }
    } else {
      for (const r of rs.rules) {
        if (!matches(r.when, tags)) continue;
        if (r.fromSlot) {
          const inSlot = newestFirst.filter((m) => tag(m.slot) === r.fromSlot);
          const named = inSlot.filter((m) => m.prefix).slice(0, r.limit);
          if (!named.length) continue;                 // nothing named here: try the next rule
          inSlot.forEach((m) => used.add(m));          // the whole slot is accounted for
          out = named.map((m) => m.prefix);
        } else {
          if (r.when) {
            const named = new Set([...r.when.all, ...r.when.any]);
            for (const [m, t] of tagsOf) if (t.some((x) => named.has(x))) used.add(m);
          }
          out = r.text ? [r.text] : [];
        }
        break;                                          // first match wins
      }
    }
    (pastBase ? suffix : prefix).push(...out);
  }

  // Tidy: drop repeats and anything the base name already starts with.
  const seen = new Set();
  const lowBase = baseName.toLowerCase();
  const keep = (w) => {
    const k = w.toLowerCase();
    if (!k || seen.has(k)) return false;
    seen.add(k);
    return true;
  };
  const pre = prefix.filter(keep).filter((w) => !lowBase.startsWith(w.toLowerCase() + " "));
  const suf = suffix.filter(keep);
  return [...pre, baseName, ...suf].join(" ").replace(/\s+/g, " ").trim();
}
