/**
 * Savage Fallout: world setup and sheet theme.
 *
 * 1. Skills: the first time a GM loads the module in a world, SWADE's core skill settings are pointed at the
 *    Fallout Skills compendium, so new characters start with the Fallout versions of the five core skills
 *    (Athletics, Common Knowledge, Notice, Persuasion, Stealth). It runs once; the GM can change it after.
 * 2. Theme: character and NPC sheets get the "sf-fallout" class, which styles/sheet.css themes in Vault-Tec
 *    blue (#0066b1) and yellow (#fff773). A world setting turns it off.
 */
const MOD = "fallout-companion";
const SKILLS_PACK = `${MOD}.fallout-skills`;
const CORE = ["Athletics", "Common Knowledge", "Notice", "Persuasion", "Stealth"];

Hooks.once("init", () => {
  game.settings.register(MOD, "sheetTheme", {
    name: "Fallout sheet theme",
    hint: "Give character and NPC sheets the Vault-Tec blue and yellow accents.",
    scope: "world", config: true, type: Boolean, default: true,
    onChange: () => Object.values(ui.windows ?? {}).forEach((w) => w.actor && w.render?.(false)),
  });
  game.settings.register(MOD, "coreSkillsApplied", { scope: "world", config: false, type: Boolean, default: false });
});

Hooks.once("ready", async () => {
  if (!game.user.isGM || game.settings.get(MOD, "coreSkillsApplied")) return;
  try {
    const has = (k) => game.settings.settings.has(`swade.${k}`);
    if (!has("coreSkills") || !has("coreSkillsCompendium") || !game.packs.get(SKILLS_PACK)) return;
    await game.settings.set("swade", "coreSkillsCompendium", SKILLS_PACK);
    await game.settings.set("swade", "coreSkills", CORE.join(", "));
    await game.settings.set(MOD, "coreSkillsApplied", true);
    ui.notifications.info("Savage Fallout: new characters will start with the Fallout core skills. You can change this in SWADE's Setting Rules.");
  } catch (err) {
    console.error("Savage Fallout | core skill setup failed", err);
  }
});

/* ------------------------------------------------------------------ sheet theme */

function themeSheet(app, html) {
  const actor = app?.actor ?? app?.document;
  if (!actor || actor.documentName !== "Actor") return;
  if (actor.flags?.[MOD]?.station) return;   // workbench stations keep their own window
  const el = app.element instanceof HTMLElement ? app.element : (app.element?.[0] ?? html?.[0] ?? html);
  if (!(el instanceof HTMLElement)) return;
  el.classList.toggle("sf-fallout", !!game.settings.get(MOD, "sheetTheme"));
}
Hooks.on("renderActorSheet", themeSheet);     // v1 sheets
Hooks.on("renderActorSheetV2", themeSheet);   // ApplicationV2 sheets
