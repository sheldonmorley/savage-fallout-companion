/**
 * Savage Fallout: automated scavenging (Scavenging and Crafting chapter).
 *
 * One entry point, SavageFallout.scavenge({...}), used by every way of placing a search:
 *  - Scavenge Node tokens (compendium actors you drop on a map; double-click to search, GM double-click to configure)
 *  - Monk's Active Tiles or Region "Execute Script" behaviours: SavageFallout.scavenge({ preset: "footlocker", node: tile })
 *  - Journal buttons: @Scavenge[ruined-house id=farmhouse]{Search the farmhouse}
 *
 * The searcher's own client makes the Notice/Survival roll in SWADE's roll dialog. The result then goes to the
 * active GM's client (Foundry's query API), which draws the loot cards, adds the items and caps to the searcher,
 * updates the node's searched state and posts the chat card. Players never need permission on tiles or journals.
 *
 * Loot data comes from scavenge-loot.mjs, generated from the Companion's own Scavenging Loot tables.
 */
import { LOOT } from "./scavenge-loot.mjs";
import { esc, hasEdge } from "./crafting.mjs";
import { swadeRoll, chooseActor } from "./workbench.mjs";

const MOD = "fallout-companion";
const QUERY = `${MOD}.scavenge`;
const STATE = "scavState";

/* ------------------------------------------------------------------ rules tables */

export const SCALES = {
  tiny: { label: "Tiny", time: "1 minute", max: 1 },
  small: { label: "Small", time: "10 minutes", max: 1 },
  average: { label: "Average", time: "1 hour", max: 2 },
  large: { label: "Large", time: "4 hours", max: 3 },
};
export const DEGREES = {
  untouched: { label: "Untouched", mod: 2 },
  light: { label: "Lightly Searched", mod: 0 },
  picked: { label: "Picked Over", mod: -2 },
  stripped: { label: "Stripped", mod: -4 },
};
export const TIERS = {
  poor: { label: "Poor", mod: -2 },
  standard: { label: "Standard", mod: 0 },
  rich: { label: "Rich", mod: 2 },
  legendary: { label: "Legendary", mod: 4 },
};
const SUITS = {
  clubs: { sym: "♣", label: "Clubs", red: false },
  diamonds: { sym: "♦", label: "Diamonds", red: true },
  hearts: { sym: "♥", label: "Hearts", red: true },
  spades: { sym: "♠", label: "Spades", red: false },
};
const RANKS = { 11: "Jack", 12: "Queen", 13: "King", 14: "Ace" };
const FACE = { 11: "J", 12: "Q", 13: "K", 14: "A" };
const WINTER = "Compendium.fallout-companion.fallout-rollable-tables.RollTable.PfwuY8F3nb7BkrNM";

/** Stock locations. Any field can be overridden per node; add-on modules can add more (see loadAddonPresets). */
export const PRESETS = {
  "footlocker":       { name: "Footlocker", scale: "tiny", degree: "light", tier: "standard", img: "icons/svg/chest.svg" },
  "car-trunk":        { name: "Car Trunk", scale: "tiny", degree: "picked", tier: "standard", img: "icons/svg/chest.svg" },
  "ammo-box":         { name: "Ammo Box", scale: "tiny", degree: "light", tier: "standard", readAs: ["clubs"], img: "icons/svg/chest.svg" },
  "first-aid-box":    { name: "First Aid Box", scale: "tiny", degree: "light", tier: "standard", readAs: ["hearts"], img: "icons/svg/heal.svg" },
  "vending-machine":  { name: "Vending Machine", scale: "tiny", degree: "picked", tier: "poor", readAs: ["hearts"], img: "icons/svg/coins.svg" },
  "desk":             { name: "Desk or Filing Cabinet", scale: "tiny", degree: "light", tier: "poor", readAs: ["diamonds"], img: "icons/svg/book.svg" },
  "wall-safe":        { name: "Wall Safe", scale: "tiny", degree: "untouched", tier: "rich", readAs: ["diamonds"], lock: { skill: "Thievery", mod: -2, tool: "Bobby Pin" }, img: "icons/svg/padlock.svg" },
  "body":             { name: "Body", scale: "tiny", degree: "light", tier: "standard", readAs: ["hearts", "diamonds"], salvage: { dice: "1d6", as: "caps" }, maxCards: 1, edges: false, once: true, img: "icons/svg/skull.svg" },
  "shack":            { name: "Shack or Single Room", scale: "small", degree: "picked", tier: "poor", img: "icons/svg/house.svg" },
  "vertibird":        { name: "Wrecked Vertibird", scale: "small", degree: "light", tier: "rich", skill: "Survival", img: "icons/svg/wing.svg" },
  "raider-stash":     { name: "Raider Stash", scale: "small", degree: "untouched", tier: "rich", img: "icons/svg/chest.svg" },
  "police-armory":    { name: "Police Armory", scale: "small", degree: "untouched", tier: "rich", readAs: ["clubs", "spades"], lock: { skill: "Hacking", mod: -2 }, img: "icons/svg/shield.svg" },
  "ruined-house":     { name: "Ruined House", scale: "average", degree: "picked", tier: "standard", img: "icons/svg/house.svg" },
  "gas-station":      { name: "Gas Station", scale: "average", degree: "picked", tier: "standard", img: "icons/svg/fire.svg" },
  "shop":             { name: "Shop or Store", scale: "average", degree: "light", tier: "standard", img: "icons/svg/item-bag.svg" },
  "clinic":           { name: "Clinic", scale: "average", degree: "light", tier: "standard", readAs: ["hearts", "diamonds"], img: "icons/svg/heal.svg" },
  "crash-site":       { name: "Crash Site or Overpass", scale: "average", degree: "light", tier: "standard", skill: "Survival", img: "icons/svg/ruins.svg" },
  "vault-room":       { name: "Vault Room", scale: "average", degree: "untouched", tier: "legendary", img: "icons/svg/door-steel.svg" },
  "factory-floor":    { name: "Factory Floor", scale: "large", degree: "picked", tier: "rich", img: "icons/svg/windmill.svg" },
  "military-depot":   { name: "Military Depot", scale: "large", degree: "untouched", tier: "legendary", lock: { skill: "Hacking", mod: -4 }, img: "icons/svg/castle.svg" },
};
export const WINTER_TABLE = WINTER;

/* ------------------------------------------------------------------ helpers */

const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
async function roll(formula) {
  const f = String(formula ?? "0").trim();
  if (/^\d+$/.test(f)) return Number(f);
  return (await new Roll(f).evaluate()).total;
}
const signed = (v) => (v > 0 ? `+${v}` : `−${Math.abs(v)}`);
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

function asDoc(node) {
  if (!node) return null;
  if (typeof node === "string") return fromUuidSync(node);
  return node.document ?? node;   // placeable -> document
}

/** Which document stores a node's state (a token's own document, not its actor). */
function stateDoc(doc) {
  if (!doc) return null;
  if (doc.documentName === "Actor" && doc.token) return doc.token;
  return doc;
}

function readState(doc, key) {
  const d = stateDoc(doc);
  const all = d?.flags?.[MOD]?.[STATE];
  const s = key ? all?.[key] : all;
  return { searches: 0, clean: false, unlocked: false, ...(s ?? {}) };
}

async function writeState(doc, key, state) {
  const d = stateDoc(doc);
  if (!d) return;
  if (d.pack) return console.warn("Savage Fallout | can't save scavenging state on a compendium document", d.uuid);
  await d.update({ [`flags.${MOD}.${STATE}${key ? `.${key}` : ""}`]: state });
}

/** The node's saved profile: a Scavenge Node actor's flags, or a tile/region/note's own flags. */
function storedProfile(doc) {
  if (!doc) return {};
  const actor = doc.documentName === "Token" ? doc.actor : doc.documentName === "Actor" ? doc : null;
  return foundry.utils.deepClone((actor ?? doc).flags?.[MOD]?.scavenge ?? {});
}

let ADDON_PRESETS = {};
export function allPresets() { return { ...PRESETS, ...ADDON_PRESETS }; }

export function resolveProfile(opts = {}) {
  const presets = allPresets();
  const base = presets[opts.preset] ?? {};
  const p = foundry.utils.mergeObject({
    name: "Search", scale: "average", degree: "light", tier: "standard", skill: "Notice",
    readAs: [], lock: null, table: null, salvage: { dice: "2d6", as: "junk" }, maxCards: null, edges: true, once: false, img: null,
  }, foundry.utils.deepClone(base), { inplace: false });
  for (const [k, v] of Object.entries(opts)) {
    if (v === undefined || v === null || v === "" || ["preset", "node", "actor", "key"].includes(k)) continue;
    p[k] = foundry.utils.deepClone(v);
  }
  if (p.table === "winter") p.table = WINTER;
  if (p.lock && !p.lock.skill) p.lock = null;
  if (typeof p.readAs === "string") p.readAs = p.readAs.split(/[\s,]+/).filter(Boolean);
  if (!SCALES[p.scale]) p.scale = "average";
  if (!DEGREES[p.degree]) p.degree = "light";
  if (!TIERS[p.tier]) p.tier = "standard";
  p.readAs = (p.readAs ?? []).filter((s) => SUITS[s]);
  p.preset = opts.preset ?? null;
  return p;
}

function searchMods(actor, p, state) {
  const lines = [];
  const deg = DEGREES[p.degree];
  if (deg.mod) lines.push([deg.mod, deg.label]);
  if (state.searches) lines.push([-2 * state.searches, `searched ${state.searches} time${state.searches > 1 ? "s" : ""} before`]);
  if (p.edges !== false) {
    if (hasEdge(actor, "Scavenger")) lines.push([2, "Scavenger"]);
    else if (p.skill === "Notice" && hasEdge(actor, "Investigator")) lines.push([2, "Investigator"]);
  }
  return lines;
}

function activeGM() { return game.users.activeGM ?? game.users.find((u) => u.isGM && u.active); }

async function gmCall(data) {
  if (game.user.isGM) return handleQuery(data);
  const gm = activeGM();
  if (!gm) { ui.notifications.warn("Scavenging needs a GM logged in."); return null; }
  try { return await gm.query(QUERY, data, { timeout: 60000 }); }
  catch (err) { console.error("Savage Fallout | scavenging query failed", err); ui.notifications.error("The GM's client didn't answer the search. Try again."); return null; }
}

async function postNote(actor, html, whisper = null) {
  const data = { speaker: ChatMessage.getSpeaker({ actor }), content: `<div class="sf-scav">${html}</div>` };
  if (whisper) data.whisper = whisper;
  return ChatMessage.create(data);
}

/* ------------------------------------------------------------------ client entry point */

/**
 * Search a location.
 * @param {object} opts
 * @param {Actor} [opts.actor]  who searches (default: the selected token / last crafter / the player's character)
 * @param {Document|PlaceableObject|string} [opts.node]  where the state is kept: a tile, region, token, journal page or UUID
 * @param {string} [opts.key]   for journal pages and other shared documents: which node on that document
 * @param {string} [opts.preset]  a key from PRESETS (or an add-on preset)
 * Any profile field (name, scale, degree, tier, skill, readAs, table, lock, salvage, maxCards) overrides the preset.
 */
export async function scavenge(opts = {}) {
  const { actor: given = null, node = null, key = null, ...rest } = opts;
  const doc = asDoc(node);
  const profile = resolveProfile({ ...storedProfile(doc), ...rest });
  const actor = given ?? (await chooseActor());
  if (!actor) return null;
  if (!game.user.isGM && !activeGM()) { ui.notifications.warn("Scavenging needs a GM logged in."); return null; }
  const ref = doc ? stateDoc(doc).uuid : null;
  const state = readState(doc, key);
  if (state.clean) {
    await postNote(actor, `<h3><i class="fas fa-magnifying-glass"></i> ${esc(profile.name)}</h3><p>${esc(actor.name)} turns the place over again. There's nothing left here.</p>`);
    return null;
  }

  // Obstacle first: a lock or terminal must be beaten before the search (Inhabitants, Obstacles, and Hazards).
  if (profile.lock && !state.unlocked) {
    const ok = await beatLock(actor, profile.lock, profile.name);
    if (!ok) return null;
    await gmCall({ op: "unlock", node: ref, key, userId: game.user.id });
  }

  const mods = searchMods(actor, profile, state);
  const r = await swadeRoll(actor, profile.skill, mods, `Scavenging: ${profile.name}`);
  if (!r) return null;
  const tn = Number(r.tn ?? 4) || 4;
  const raises = r.success ? Math.max(0, Math.floor((r.total - tn) / 4)) : 0;
  return gmCall({
    op: "search", node: ref, key, userId: game.user.id, actorUuid: actor.uuid, profile,
    roll: { success: r.success, critFail: r.critFail, total: r.total, tn, raises, mods },
  });
}

/** Thievery (or Hacking) against a lock. Returns true when it's open. */
async function beatLock(actor, lock, where) {
  const mods = [];
  if (lock.mod) mods.push([lock.mod, lock.skill === "Hacking" ? "terminal" : "lock"]);
  if (lock.tool && !actor.items.some((i) => i.name === lock.tool)) mods.push([-2, `no ${lock.tool}s`]);
  const r = await swadeRoll(actor, lock.skill ?? "Thievery", mods, `${lock.skill === "Hacking" ? "Hacking" : "Lock"}: ${where}`);
  if (!r) return false;
  if (!r.success) {
    await postNote(actor, `<p><i class="fas fa-lock"></i> <strong>${esc(where)}</strong> stays locked.${r.critFail ? " Something breaks or jams; the GM decides what." : ""} ${esc(actor.name)} can try again.</p>`);
    return false;
  }
  return true;
}

/* ------------------------------------------------------------------ GM side */

async function handleQuery(data) {
  try {
    if (data.op === "search") return await gmSearch(data);
    if (data.op === "unlock") { const doc = data.node ? fromUuidSync(data.node) : null; if (doc) await writeState(doc, data.key, { ...readState(doc, data.key), unlocked: true }); return true; }
    if (data.op === "open") return await gmOpen(data);
  } catch (err) {
    console.error("Savage Fallout | scavenging failed", err);
    ui.notifications.error(`Scavenging failed: ${err.message}`);
  }
  return null;
}

function checkOwner(actor, userId) {
  const user = game.users.get(userId);
  return actor && user && (user.isGM || actor.testUserPermission(user, "OWNER"));
}

function newDeck() {
  const deck = [];
  for (const s of Object.keys(SUITS)) for (let v = 2; v <= 14; v++) deck.push({ suit: s, value: v });
  deck.push({ joker: true, color: "red" }, { joker: true, color: "black" });
  for (let i = deck.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [deck[i], deck[j]] = [deck[j], deck[i]]; }
  return deck;
}

/** Collected results of one search: what to add to the searcher, and the lines for the chat card. */
class Haul {
  constructor() { this.caps = 0; this.items = []; this.rows = []; this.gm = []; this.locked = []; this.benny = false; }
  addItem(uuid, name, qty) { if (qty > 0) this.items.push({ uuid, name, qty }); }
}

async function resolveOption(opt, haul) {
  const got = [];
  if (opt.caps) { const n = await roll(opt.caps); haul.caps += n; got.push(`${n} caps`); }
  else if (opt.junk) { const n = await roll(opt.junk); haul.addItem(LOOT.junk, "Junk", n); got.push(`Junk ×${n}${opt.label ? ` (${opt.label})` : ""}`); }
  else if (opt.item) {
    const n = await roll(opt.qty ?? 1); haul.addItem(opt.item, opt.name, n); got.push(n > 1 ? `${opt.name} ×${n}` : opt.name);
    if (opt.ammo) { const a = await roll(opt.ammo.qty); haul.addItem(opt.ammo.item, opt.ammo.name, a); got.push(`${opt.ammo.name} ×${a}`); }
  }
  else if (opt.armor) {
    const d = Math.ceil(Math.random() * 6);
    const loc = d <= 2 ? "torso" : d === 3 ? "arms" : d === 4 ? "legs" : null;
    const choices = Object.entries(opt.pieces).filter(([, v]) => v);
    const [where, piece] = loc && opt.pieces[loc] ? [loc, opt.pieces[loc]] : pick(choices);
    haul.addItem(piece.item, piece.name, 1);
    got.push(piece.name);
    return { got, note: `armor location d6: ${d} (${where})` };
  }
  else if (opt.pick) return resolveOption(pick(opt.pick), haul);
  else if (opt.gm) { haul.gm.push(opt.gm); got.push(opt.gm.split(":")[0]); }
  return { got };
}

/** Read one loot card (or a roll on the node's own table) and add its result to the haul. */
async function readCard(card, p, haul, deck, depth = 0) {
  if (card.joker) {
    haul.benny = true;
    const d = Math.ceil(Math.random() * 6);
    const j = LOOT.jackpot[d - 1];
    const row = { card, title: "Joker! Jackpot", sub: `Jackpot d6: ${d}. ${j.text}`, got: [] };
    haul.rows.push(row);
    if (j.draw && depth < 2) { row.got.push(`${j.draw} more cards`); for (let i = 0; i < j.draw && deck.length; i++) await readCard(deck.shift(), p, haul, deck, depth + 1); }
    else if (j.table) {
      const res = await drawTableText(LOOT.tableIds["Vault-Tec Bobbleheads"]);
      if (res) { row.got.push(res.replace(/<[^>]+>/g, "").split(".")[0]); haul.gm.push(`Vault-Tec Bobblehead: ${res.replace(/<[^>]+>/g, "")}`); }
    }
    else { const r = await resolveOption(j, haul); row.got.push(...r.got); }
    return;
  }
  if (p.table) return readTable(card, p, haul);
  const suit = p.readAs.length && !p.readAs.includes(card.suit) ? pick(p.readAs) : card.suit;
  const tierMod = TIERS[p.tier].mod;
  const value = clamp(card.value + tierMod, 2, 14);
  const rows = LOOT.suits[suit];
  const tableRow = rows.find((r) => value >= r.min && value <= r.max);
  const d = Math.ceil(Math.random() * 6);
  const opt = tableRow.options[d - 1];
  if (opt.locked) {
    haul.locked.push({ cards: opt.locked, tier: p.tier, readAs: p.readAs, table: p.table, opened: false });
    haul.rows.push({ card, suitShown: suit, title: "Locked container", sub: cardLine(card, suit, value, tierMod) + `. ${SUITS[suit].label} ${rangeLabel(tableRow)}, d6: ${d}`, got: [] });
    return;
  }
  const r = await resolveOption(opt, haul);
  haul.rows.push({ card, suitShown: suit, title: r.got.join(" + ") || opt.text, sub: cardLine(card, suit, value, tierMod) + `. ${SUITS[suit].label} ${rangeLabel(tableRow)}, d6: ${d}${r.note ? `; ${r.note}` : ""}`, got: [] });
}

const rangeLabel = (r) => (r.min === r.max ? `${r.min}` : `${r.min}–${r.max}`);
function cardLine(card, suit, value, tierMod) {
  const name = `${RANKS[card.value] ?? card.value} of ${SUITS[card.suit].label}`;
  const as = suit !== card.suit ? `, read as ${SUITS[suit].label}` : "";
  return `${name} (${card.value}${tierMod ? ` ${signed(tierMod)} tier = ${value}` : ""}${as})`;
}

/** A roll on the node's own table replaces the card (Regional Tables). */
async function readTable(card, p, haul) {
  const pre = LOOT.tables[p.table];
  if (pre) {
    const n = await roll(pre.formula);
    const res = pre.results.find((r) => n >= r.min && n <= r.max);
    const r = await resolveOption(res, haul);
    haul.rows.push({ icon: "fas fa-table-list", title: r.got.join(" + ") || res.text, sub: `${pre.name} ${pre.formula.replace(/^1/, "")}: ${n}`, got: [] });
    return;
  }
  const table = await fromUuid(p.table);
  if (!table) { haul.gm.push(`Couldn't find the node's table (${p.table}).`); return; }
  const draw = await table.roll();
  for (const result of draw.results) {
    const docUuid = result.documentUuid ?? (result.documentCollection && result.documentId ? `${result.documentCollection}.${result.documentId}` : null);
    const text = (result.description ?? result.text ?? result.name ?? "").replace(/<[^>]+>/g, "").trim();
    let got = null;
    if (docUuid) { const it = await fromUuid(docUuid); if (it?.documentName === "Item") { haul.addItem(it.uuid, it.name, 1); got = it.name; } }
    if (!got && text) got = await resolveText(text, haul);
    haul.rows.push({ icon: "fas fa-table-list", title: got ?? text, sub: `${table.name}: ${draw.roll.total}`, got: [] });
  }
}

/** "Cram (1d3 tins)" / ".45 rounds (2d6)" / "Heavy Coat": find the item by name; otherwise hand it to the GM. */
let NAME_INDEX = null;
async function nameIndex() {
  if (NAME_INDEX) return NAME_INDEX;
  NAME_INDEX = new Map();
  for (const pack of game.packs.filter((p) => p.documentName === "Item" && p.metadata.packageName === MOD)) {
    for (const e of await pack.getIndex()) if (!NAME_INDEX.has(e.name.toLowerCase())) NAME_INDEX.set(e.name.toLowerCase(), { uuid: e.uuid, name: e.name });
  }
  for (const it of game.items) NAME_INDEX.set(it.name.toLowerCase(), { uuid: it.uuid, name: it.name });
  return NAME_INDEX;
}
async function resolveText(text, haul) {
  const idx = await nameIndex();
  const m = text.match(/^(.+?)(?:\s+rounds)?\s*\((\d*d\d+|\d+)(?:\s+\w+)?\)$/i);
  const name = (m ? m[1] : text).trim();
  const alias = { "common resources": "common materials", "uncommon resources": "uncommon materials", "rare resources": "rare materials" };
  const hit = idx.get(name.toLowerCase()) ?? idx.get(alias[name.toLowerCase()]) ?? idx.get(name.toLowerCase().replace(/s$/, ""));
  if (!hit) { haul.gm.push(text); return null; }
  const n = m ? await roll(m[2]) : 1;
  haul.addItem(hit.uuid, hit.name, n);
  return n > 1 ? `${hit.name} ×${n}` : hit.name;
}

async function drawTableText(uuid) {
  const table = await fromUuid(uuid);
  if (!table) return null;
  const draw = await table.roll();
  return draw.results.map((r) => r.description ?? r.text ?? r.name ?? "").join(" ");
}

async function scroungerFind(actor, haul) {
  const d = Math.ceil(Math.random() * 6);
  if (d <= 3) {
    const guns = actor.items.filter((i) => i.type === "weapon" && (i.system?.ammo ?? "").trim());
    const party = game.actors.filter((a) => a.type === "character" && a.hasPlayerOwner && a.id !== actor.id).flatMap((a) => a.items.filter((i) => i.type === "weapon" && (i.system?.ammo ?? "").trim()));
    const gun = pick(guns.length ? guns : party.length ? party : [null]);
    if (!gun) return { title: "Scrounger: no guns in the party to find ammo for", sub: `Scrounger d6: ${d}` };
    const ammo = LOOT.ammo[gun.system.ammo.trim().toLowerCase()];
    const n = await roll("2d6");
    if (ammo) { haul.addItem(ammo.item, ammo.name, n); return { title: `${ammo.name} ×${n}`, sub: `Scrounger d6: ${d}, ammo for ${gun.name}` }; }
    haul.gm.push(`Scrounger: ${n} rounds of ${gun.system.ammo} for ${gun.name}.`);
    return { title: `${n} rounds of ${gun.system.ammo}`, sub: `Scrounger d6: ${d}` };
  }
  if (d <= 5) {
    const n = Math.ceil(Math.random() * 20);
    const row = LOOT.scrounger.chems.find((r) => n >= r.min && n <= r.max);
    const r = await resolveOption(row, haul);
    return { title: r.got.join(" + "), sub: `Scrounger d6: ${d}; Random Chems d20: ${n}` };
  }
  const r = await resolveOption(pick(LOOT.scrounger.food), haul);
  return { title: r.got.join(" + "), sub: `Scrounger d6: ${d}, food or water` };
}

async function addToActor(actor, haul) {
  if (haul.caps) {
    const cur = Number(foundry.utils.getProperty(actor, "system.details.currency")) || 0;
    await actor.update({ "system.details.currency": cur + haul.caps });
  }
  const merged = new Map();
  for (const it of haul.items) merged.set(it.uuid, { ...it, qty: (merged.get(it.uuid)?.qty ?? 0) + it.qty });
  for (const it of merged.values()) {
    const src = await fromUuid(it.uuid);
    if (!src) { haul.gm.push(`Missing item: ${it.name}`); continue; }
    const stackable = !["weapon", "armor", "shield"].includes(src.type);
    const existing = stackable ? actor.items.find((i) => i.name === src.name && !i.flags?.[MOD]?.modding) : null;
    if (existing) { await existing.update({ "system.quantity": (Number(existing.system?.quantity) || 1) + it.qty }); continue; }
    const data = src.toObject();
    delete data._id; delete data.folder;
    data.system.quantity = stackable ? it.qty : 1;
    data._stats = { ...(data._stats ?? {}), compendiumSource: it.uuid };
    await actor.createEmbeddedDocuments("Item", Array.from({ length: stackable ? 1 : it.qty }, () => foundry.utils.deepClone(data)));
  }
}

function chips(p) {
  const s = SCALES[p.scale], d = DEGREES[p.degree], t = TIERS[p.tier];
  const out = [`${s.label} · ${s.time}`, `${d.label}${d.mod ? ` ${signed(d.mod)}` : ""}`, `${t.label} tier${t.mod ? ` ${signed(t.mod)}` : ""}`];
  if (p.readAs.length) out.push(`Read as ${p.readAs.map((s) => SUITS[s].sym).join(" or ")}`);
  if (p.table) out.push(LOOT.tables[p.table]?.name ?? "Custom table");
  return out.map((c) => `<span class="sf-chip">${esc(c)}</span>`).join("");
}

function cardFace(card, suitShown) {
  if (!card) return `<span class="sf-card sf-blank"></span>`;
  if (card.joker) return `<span class="sf-card sf-joker">★</span>`;
  const red = SUITS[card.suit].red;
  return `<span class="sf-card${red ? " red" : ""}"><small>${SUITS[card.suit].sym}</small>${FACE[card.value] ?? card.value}</span>`;
}

function render(actor, p, r, haul, extra) {
  const mods = (r.mods ?? []).map(([v, l]) => `${signed(v)} ${esc(l)}`).join(", ");
  const verdict = r.critFail ? `<span class="sf-bad">Critical Failure</span>` : !r.success ? `<span class="sf-bad">Failure</span>`
    : `<span class="sf-good">Success${r.raises ? `, ${r.raises} raise${r.raises > 1 ? "s" : ""}` : ""}</span>`;
  const rows = haul.rows.map((row) => `<li>${row.icon ? `<span class="sf-card sf-blank"><i class="${row.icon}"></i></span>` : cardFace(row.card, row.suitShown)}<div><b>${esc(row.title)}</b>${row.got?.length ? ` <span>${esc(row.got.join(", "))}</span>` : ""}<small>${esc(row.sub ?? "")}</small></div></li>`).join("");
  const locked = haul.locked.map((l, i) => `<div class="sf-locked" data-idx="${i}"><i class="fas fa-lock"></i> <b>Locked container</b>: Thievery −2 (Hacking for a terminal-linked safe). ${l.cards === 2 ? "Two cards" : "One card"} inside.<button type="button" data-action="sfScavOpen" data-idx="${i}">Pick the lock</button></div>`).join("");
  const gm = haul.gm.length || haul.benny ? `<div class="sf-gmnote">${haul.benny ? "<p>Joker: every hero gets a Benny.</p>" : ""}${haul.gm.map((g) => `<p>${esc(g)}</p>`).join("")}</div>` : "";
  return `<div class="sf-scav">
    <h3><i class="fas fa-magnifying-glass"></i> ${esc(p.name)}</h3>
    <div class="sf-chips">${chips(p)}</div>
    <div class="sf-roll">${esc(p.skill)} <b>${r.total}</b>${mods ? ` (${mods})` : ""} → ${verdict}</div>
    ${rows ? `<ul class="sf-haul">${rows}</ul>` : ""}${locked}${gm}
    ${extra ? `<p class="sf-foot">${extra}</p>` : ""}</div>`;
}

async function gmSearch(data) {
  const actor = await fromUuid(data.actorUuid);
  if (!checkOwner(actor, data.userId)) throw new Error("that user doesn't own the searcher");
  const doc = data.node ? fromUuidSync(data.node) : null;
  const state = readState(doc, data.key);
  const p = data.profile, r = data.roll;
  if (state.clean) { await postNote(actor, `<p>${esc(actor.name)} finds nothing left at ${esc(p.name)}.</p>`); return { clean: true }; }

  const haul = new Haul();
  const deck = newDeck();
  const scale = SCALES[p.scale];
  const max = p.maxCards ?? scale.max;
  const scav = p.edges !== false && hasEdge(actor, "Scavenger");
  const scr = p.edges !== false && hasEdge(actor, "Scrounger");
  let clean = false, foot = [];

  if (r.critFail) {
    const d = Math.ceil(Math.random() * 6);
    const c = LOOT.complications[d - 1];
    haul.rows.push({ icon: "fas fa-triangle-exclamation", title: c.text.split(".")[0] + ".", sub: `${c.text.split(".").slice(1).join(".").trim()} (Complication d6: ${d})` });
    if (d === 5) {   // Locked away: one loot card, drawn now, sits in a locked container
      haul.locked.push({ cards: 1, tier: p.tier, readAs: p.readAs, table: p.table, opened: false });
    }
    clean = true;
    foot.push("Nothing found, and this location has nothing left until something meaningful changes. The GM can reset it.");
  } else if (!r.success) {
    foot.push(`Nothing worth carrying. Searching again takes ${scale.time} and is at ${signed(-2 * (state.searches + 1))} on top of the location's Degree.`);
  } else {
    let n = await roll(p.salvage?.dice ?? "2d6");
    const base = n;
    if (scav) n *= 2;
    if ((p.salvage?.as ?? "junk") === "caps") haul.caps += n; else haul.addItem(LOOT.junk, "Junk", n);
    haul.rows.push({ icon: (p.salvage?.as === "caps") ? "fas fa-coins" : "fas fa-gears", title: p.salvage?.as === "caps" ? `${n} caps` : `Junk ×${n}`, sub: `Salvage: ${p.salvage?.dice ?? "2d6"} (${base})${scav ? ", doubled by Scavenger" : ""}` });
    if (scr) { const s = await scroungerFind(actor, haul); haul.rows.push({ icon: "fas fa-star", ...s }); }
    const normal = Math.min(r.raises, max);
    const cards = normal + (scav && normal ? 1 : 0);   // Scavenger: one extra draw on a raise, past the maximum if need be
    for (let i = 0; i < cards && deck.length; i++) await readCard(deck.shift(), p, haul, deck);
    if (r.raises > max) foot.push(`${r.raises} raises, but ${scale.label === "Average" ? "an" : "a"} ${scale.label} location gives at most ${max} card${max > 1 ? "s" : ""}.`);
    if (scav && cards) foot.push(`Scavenger adds one extra card${r.raises >= max ? ", past the location's maximum" : ""}.`);
  }

  await addToActor(actor, haul);
  const next = { ...state, searches: state.searches + 1, clean: clean || !!p.once };
  if (doc) await writeState(doc, data.key, next);
  if (doc && !clean && !p.once && r.success) foot.push(`Searched ${next.searches === 1 ? "once" : `${next.searches} times`}; another search here is at ${signed(-2 * next.searches)} on top of the location's Degree.`);
  if (haul.items.length || haul.caps) foot.unshift(`Added to ${esc(actor.name)}'s inventory.`);

  const whisper = game.settings.get(MOD, "scavengeWhisper") ? [game.users.get(data.userId)?.id, ...game.users.filter((u) => u.isGM).map((u) => u.id)].filter(Boolean) : null;
  const msg = await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor }),
    content: render(actor, p, r, haul, foot.join(" ")),
    whisper: whisper ?? undefined,
    flags: { [MOD]: { scav: { actorUuid: actor.uuid, name: p.name, locked: haul.locked } } },
  });
  return { messageId: msg?.id, items: haul.items, caps: haul.caps, clean: next.clean };
}

/** Pick the lock on a container from a chat card; the GM's client draws what's inside. */
async function gmOpen(data) {
  const msg = game.messages.get(data.messageId);
  const actor = await fromUuid(data.actorUuid);
  if (!msg || !checkOwner(actor, data.userId)) throw new Error("can't open that container");
  const info = foundry.utils.deepClone(msg.flags?.[MOD]?.scav);
  const box = info?.locked?.[data.idx];
  if (!box || box.opened) return null;
  const haul = new Haul();
  const deck = newDeck();
  const p = resolveProfile({ tier: box.tier, readAs: box.readAs, table: box.table, name: "Locked container" });
  for (let i = 0; i < box.cards; i++) await readCard(deck.shift(), p, haul, deck);
  await addToActor(actor, haul);
  box.opened = true; box.by = actor.name;
  await msg.update({ [`flags.${MOD}.scav.locked`]: info.locked });
  await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor }),
    content: render(actor, { ...p, name: `${info.name}: locked container` }, { success: true, total: "—", raises: 0, mods: [] }, haul, `Opened by ${esc(actor.name)}. Added to their inventory.`)
      .replace(/<div class="sf-roll">.*?<\/div>/s, "").replace(/<div class="sf-chips">.*?<\/div>/s, ""),
  });
  return true;
}

/* ------------------------------------------------------------------ chat card buttons */

Hooks.on("renderChatMessageHTML", (message, html) => {
  const info = message.flags?.[MOD]?.scav;
  if (!info) return;
  html.querySelectorAll("[data-action=sfScavOpen]").forEach((btn) => {
    const box = info.locked?.[Number(btn.dataset.idx)];
    if (box?.opened) { btn.replaceWith(Object.assign(document.createElement("em"), { textContent: `Opened by ${box.by}.` })); return; }
    btn.addEventListener("click", async (ev) => {
      ev.preventDefault();
      const speaker = fromUuidSync(info.actorUuid);
      const actor = speaker?.isOwner ? speaker : await chooseActor();
      if (!actor) return;
      btn.disabled = true;
      const ok = await beatLock(actor, { skill: "Thievery", mod: -2, tool: "Bobby Pin" }, "Locked container");
      if (ok) await gmCall({ op: "open", messageId: message.id, idx: Number(btn.dataset.idx), actorUuid: actor.uuid, userId: game.user.id });
      btn.disabled = false;
    });
  });
});

/* ------------------------------------------------------------------ reset */

/** Restock one node (or every node on a document when key is omitted for a journal page). */
export async function resetScavenge(node, key = null) {
  const doc = stateDoc(asDoc(node));
  if (!doc) return;
  if (!game.user.isGM) return ui.notifications.warn("Only the GM can restock scavenging spots.");
  if (key) await doc.update({ [`flags.${MOD}.${STATE}.${key}`]: null });
  else await doc.unsetFlag(MOD, STATE);
}

/** Restock every scavenging spot on a scene: tokens, tiles, regions, notes. */
export async function resetScavengeScene(scene = canvas?.scene) {
  if (!game.user.isGM || !scene) return 0;
  let n = 0;
  for (const coll of [scene.tokens, scene.tiles, scene.regions, scene.notes, scene.drawings]) {
    for (const d of coll ?? []) if (d.flags?.[MOD]?.[STATE]) { await d.unsetFlag(MOD, STATE); n++; }
  }
  ui.notifications.info(n ? `Restocked ${n} scavenging spot${n > 1 ? "s" : ""}.` : "Nothing on this scene needed restocking.");
  return n;
}

/* ------------------------------------------------------------------ Scavenge Node actors (map tokens) */

class ScavengeNodeSheet extends foundry.applications.api.DocumentSheetV2 {
  async render(options = {}) {
    const actor = this.document;
    const node = actor.token ?? actor;
    if (game.user.isGM) configureNode(actor);
    else scavenge({ node });
    return this;
  }
}

async function configureNode(actor) {
  const node = actor.token ?? actor;
  const cur = resolveProfile(storedProfile(node));
  const state = readState(node);
  const opt = (obj, sel) => Object.entries(obj).map(([k, v]) => `<option value="${k}"${k === sel ? " selected" : ""}>${esc(v.label ?? v.name)}</option>`).join("");
  const presets = allPresets();
  const suitBoxes = Object.entries(SUITS).map(([k, v]) => `<label><input type="checkbox" name="readAs_${k}"${cur.readAs.includes(k) ? " checked" : ""}> ${v.sym}</label>`).join(" ");
  const content = `<div class="sf-scav-config">
    <p class="hint">${state.clean ? "<b>Picked clean.</b> " : ""}Searched ${state.searches} time${state.searches === 1 ? "" : "s"}${state.unlocked ? ", unlocked" : ""}. Changes apply to this token only.</p>
    <div class="form-group"><label>Preset</label><select name="preset"><option value="">(none)</option>${opt(presets, cur.preset)}</select></div>
    <div class="form-group"><label>Name</label><input type="text" name="name" value="${esc(cur.name)}"></div>
    <div class="form-group"><label>Scale</label><select name="scale">${opt(SCALES, cur.scale)}</select></div>
    <div class="form-group"><label>Degree</label><select name="degree">${opt(DEGREES, cur.degree)}</select></div>
    <div class="form-group"><label>Tier</label><select name="tier">${opt(TIERS, cur.tier)}</select></div>
    <div class="form-group"><label>Skill</label><select name="skill"><option${cur.skill === "Notice" ? " selected" : ""}>Notice</option><option${cur.skill === "Survival" ? " selected" : ""}>Survival</option></select></div>
    <div class="form-group"><label>Read cards as</label><div class="form-fields">${suitBoxes}</div></div>
    <div class="form-group"><label>Roll table instead</label><input type="text" name="table" placeholder="RollTable UUID, or winter" value="${esc(cur.table ?? "")}"></div>
    <div class="form-group"><label>Lock</label><div class="form-fields"><select name="lockSkill"><option value="">None</option><option${cur.lock?.skill === "Thievery" ? " selected" : ""}>Thievery</option><option${cur.lock?.skill === "Hacking" ? " selected" : ""}>Hacking</option></select><input type="number" name="lockMod" value="${cur.lock?.mod ?? -2}" style="max-width:4em"></div></div>
  </div>`;
  const res = await foundry.applications.api.DialogV2.wait({
    window: { title: `Scavenging: ${actor.name}` }, content, rejectClose: false,
    buttons: [
      { action: "save", label: "Save", icon: "fas fa-save", default: true, callback: (ev, btn) => new foundry.applications.ux.FormDataExtended(btn.form).object },
      { action: "search", label: "Search as…", icon: "fas fa-magnifying-glass" },
      { action: "reset", label: "Restock", icon: "fas fa-rotate" },
    ],
  });
  if (!res) return;
  if (res === "search") return scavenge({ node });
  if (res === "reset") { await resetScavenge(node); return ui.notifications.info(`${actor.name} restocked.`); }
  // Every key is written (null = "use the preset"), so an update never leaves stale fields behind.
  const f = res;
  const preset = f.preset || null;
  const base = resolveProfile({ preset });
  const data = { preset, name: null, scale: null, degree: null, tier: null, skill: null, readAs: null, table: null, lock: null };
  for (const k of ["name", "scale", "degree", "tier", "skill"]) if (!preset || f[k] !== base[k]) data[k] = f[k];
  const readAs = Object.keys(SUITS).filter((k) => f[`readAs_${k}`]);
  if (!preset || readAs.join() !== base.readAs.join()) data.readAs = readAs;
  if (f.table) data.table = f.table;
  const lock = f.lockSkill ? { skill: f.lockSkill, mod: Number(f.lockMod) || 0, tool: f.lockSkill === "Thievery" ? "Bobby Pin" : null } : null;
  if (JSON.stringify(lock) !== JSON.stringify(base.lock ? { skill: base.lock.skill, mod: base.lock.mod, tool: base.lock.tool ?? null } : null)) data.lock = lock ?? { skill: null };
  await actor.update({ [`flags.${MOD}.scavenge`]: data, name: f.name || base.name || actor.name });
}

/* ------------------------------------------------------------------ journal buttons: @Scavenge[preset key=value]{label} */

function parseArgs(str) {
  const out = {};
  const re = /(\w+)=("([^"]*)"|'([^']*)'|\S+)|("([^"]*)"|\S+)/g;
  let m;
  while ((m = re.exec(str))) {
    if (m[1]) out[m[1]] = m[3] ?? m[4] ?? m[2];
    else if (!out.preset) out.preset = m[6] ?? m[5];
  }
  for (const k of ["maxCards"]) if (out[k] !== undefined) out[k] = Number(out[k]);
  if (out.lock) { const [skill, mod] = out.lock.split(":"); out.lock = { skill, mod: Number(mod ?? -2), tool: skill === "Thievery" ? "Bobby Pin" : undefined }; }
  return out;
}

function enrichScavenge(match, options) {
  const args = parseArgs(match[1]);
  const id = (args.id ?? match[1]).replace(/[^A-Za-z0-9_-]+/g, "-").slice(0, 60);
  delete args.id;
  const page = options?.relativeTo;
  const p = resolveProfile(args);
  const state = page ? readState(page, id) : { searches: 0, clean: false };
  const a = document.createElement("a");
  a.classList.add("sf-scavenge-link");
  if (state.clean) a.classList.add("clean"); else if (state.searches) a.classList.add("searched");
  a.dataset.args = JSON.stringify(args);
  a.dataset.key = id;
  if (page?.uuid) a.dataset.node = page.uuid;
  a.title = `${p.name}: ${SCALES[p.scale].label}, ${DEGREES[p.degree].label}, ${TIERS[p.tier].label}${state.clean ? " (picked clean)" : state.searches ? ` (searched ${state.searches}×)` : ""}`;
  a.innerHTML = `<i class="fas fa-magnifying-glass"></i> ${esc(match[2] ?? `Search: ${p.name}`)}`;
  return a;
}

document.addEventListener("click", (ev) => {
  const a = ev.target?.closest?.("a.sf-scavenge-link");
  if (!a) return;
  ev.preventDefault(); ev.stopPropagation();
  const args = JSON.parse(a.dataset.args || "{}");
  scavenge({ ...args, node: a.dataset.node || null, key: a.dataset.key });
});

/* ------------------------------------------------------------------ add-on presets */

/** Add-on modules list presets in module.json: flags["fallout-companion"].scavengePresets = "path/to/presets.json". */
async function loadAddonPresets() {
  ADDON_PRESETS = {};
  for (const m of game.modules) {
    const path = m.active && m.id !== MOD && m.flags?.[MOD]?.scavengePresets;
    if (!path) continue;
    try {
      const res = await fetch(`modules/${m.id}/${path}`);
      const json = await res.json();
      for (const [k, v] of Object.entries(json)) ADDON_PRESETS[k] = { ...v, source: m.id };
    } catch (err) { console.warn(`Savage Fallout | couldn't load scavenging presets from ${m.id}`, err); }
  }
}

/* ------------------------------------------------------------------ wiring */

Hooks.once("init", () => {
  game.settings.register(MOD, "scavengeWhisper", {
    name: "Whisper scavenging results",
    hint: "Show scavenging results only to the GM and the player who searched.",
    scope: "world", config: true, type: Boolean, default: false,
  });
  CONFIG.queries ??= {};
  CONFIG.queries[QUERY] = (data) => handleQuery(data);
  CONFIG.TextEditor.enrichers.push({ id: "sfScavenge", pattern: /@Scavenge\[([^\]]+)\](?:\{([^}]+)\})?/g, enricher: enrichScavenge });
  const DSC = foundry.applications.apps?.DocumentSheetConfig ?? globalThis.DocumentSheetConfig;
  DSC.registerSheet(Actor, MOD, ScavengeNodeSheet, { types: ["npc"], makeDefault: false, label: "Savage Fallout Scavenge Node" });
});

Hooks.once("ready", async () => {
  await loadAddonPresets();
  const api = { scavenge, resetScavenge, resetScavengeScene, presets: allPresets, SCALES, DEGREES, TIERS };
  const m = game.modules.get(MOD);
  if (m?.api) Object.assign(m.api, api);
  globalThis.SavageFallout = { ...(globalThis.SavageFallout ?? {}), ...api };
});

// Scavenge Node actors are visible (Limited) to everyone, so players can double-click the token.
Hooks.on("preCreateActor", (actor, data) => {
  if (!data.flags?.[MOD]?.scavenge) return;
  actor.updateSource({ "ownership.default": CONST.DOCUMENT_OWNERSHIP_LEVELS.LIMITED, "flags.core.sheetClass": `${MOD}.ScavengeNodeSheet` });
});

// Re-render journal buttons when their state changes, so "searched" / "picked clean" shows.
Hooks.on("updateJournalEntryPage", (page, changes) => {
  if (!changes.flags?.[MOD]) return;
  for (const app of foundry.applications.instances?.values?.() ?? []) if (app.document?.uuid === page.parent?.uuid) app.render();
});

