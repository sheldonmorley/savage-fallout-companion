/**
 * Savage Fallout: Break Down Junk (Scavenging and Crafting: Breaking Down Junk).
 *
 * 30 minutes per 10 caps of Junk (or part of it), with a workbench of any kind, a Toolkit or a Multi-Tool. No roll.
 * Every 10 caps gives 5 Common and 1 Uncommon; a last part of 10 caps gives its share, rounded down.
 * Scrapper: 1 extra Uncommon per 10 caps, in half the time. Improved Scrapper: also 1 Rare per 20 caps.
 * Scrapping gear: weapons, armor and gear count as Junk worth half their price. No consumables, ammo or fusion cores.
 *
 * Runs on the client of whoever owns the character: it only changes that character's own items.
 * Open it from the Workbench (Break Down Junk button), the Break Down Junk macro, or SavageFallout.breakDownJunk().
 */
import { esc, hasEdge } from "./crafting.mjs";
import { chooseActor } from "./workbench.mjs";

const MOD = "fallout-companion";
const PACK = `Compendium.${MOD}.fallout-crafting-materials.Item.`;
export const MATERIALS = {
  common: { name: "Common Materials", uuid: `${PACK}F1XcosU81qNg1dBW` },
  uncommon: { name: "Uncommon Materials", uuid: `${PACK}VlYSIFDJ7GLLDcNJ` },
  rare: { name: "Rare Materials", uuid: `${PACK}lKjtqStdqyPuOjrm` },
};
const TOOLS = ["Toolkit", "Multi-Tool", "Deluxe Toolkit"];
const NEVER = new Set(["Junk", "Fusion Core", "Locket", "Silver Pocketwatch", "Pre-War Money", "Pre-War Valuables"]);

/** Resources per `unit` caps of Junk: everyone, then what each Edge adds. */
export const YIELD = { common: [5, 10], uncommon: [1, 10] };
export const SCRAPPER = { uncommon: [1, 10] };
export const IMPROVED_SCRAPPER = { rare: [1, 20] };

const qtyOf = (i) => Number(i.system?.quantity ?? 1) || 0;
const priceOf = (i) => Number(i.system?.price ?? 0) || 0;
const equipped = (i) => !!i.system?.equipped || Number(i.system?.equipStatus ?? 0) > 1;
const fromPack = (i, pack) => String(i._stats?.compendiumSource ?? i.flags?.core?.sourceId ?? "").includes(pack);

/** Items that can be scrapped: weapons, armor, shields and gear with a price, not worn or wielded. */
export function scrapCandidates(actor) {
  return actor.items.filter((i) => ["weapon", "armor", "shield", "gear"].includes(i.type)
    && !NEVER.has(i.name) && !/ Materials$/.test(i.name)
    && !i.flags?.[MOD]?.fullValue && !i.system?.isAmmo
    && !fromPack(i, "fallout-crafting-materials") && !fromPack(i, "fallout-consumables")
    && !equipped(i) && Math.floor(priceOf(i) / 2) > 0);
}

export const junkOf = (actor) => actor.items.filter((i) => i.name === "Junk").reduce((a, i) => a + qtyOf(i), 0);
export const hasTools = (actor) => TOOLS.some((n) => actor.items.some((i) => i.name === n));

export const scrapperLevel = (actor) => (hasEdge(actor, "Improved Scrapper") ? 2 : hasEdge(actor, "Scrapper") ? 1 : 0);

/** Resources from `value` caps of Junk; a last part of a lot gives its share, rounded down. */
export function yieldFor(value, level = 0) {
  // Add up the rates first (a Scrapper reads "2 Uncommon per 10 caps"), then take the share, rounded down.
  const rate = { common: 0, uncommon: 0, rare: 0 };
  const add = (t) => { for (const [k, [per, unit]] of Object.entries(t)) rate[k] += per / unit; };
  add(YIELD);
  if (level >= 1) add(SCRAPPER);
  if (level >= 2) add(IMPROVED_SCRAPPER);
  return Object.fromEntries(Object.entries(rate).map(([k, r]) => [k, Math.floor(value * r + 1e-9)]));
}

export const minutesFor = (value, level = 0) => (Math.ceil(value / 10) * 30) / (level >= 1 ? 2 : 1);
const listGot = (g) => [g.common && `${g.common} Common`, g.uncommon && `${g.uncommon} Uncommon`, g.rare && `${g.rare} Rare`].filter(Boolean).join(", ") || "nothing";
const timeText = (min) => {
  const h = Math.floor(min / 60), m = min % 60;
  return [h ? `${h} hour${h === 1 ? "" : "s"}` : "", m ? `${m} minutes` : ""].filter(Boolean).join(" ");
};

/* ------------------------------------------------------------------ the dialog */

async function askPlan(actor, station) {
  const level = scrapperLevel(actor);
  const junk = junkOf(actor);
  const scrap = scrapCandidates(actor);
  const tools = hasTools(actor);
  const rows = scrap.map((i) => {
    const q = qtyOf(i), each = Math.floor(priceOf(i) / 2);
    return `<tr><td>${esc(i.name)}</td><td class="num">${each}</td>
      <td class="num"><input type="number" name="scrap_${i.id}" value="0" min="0" max="${q}" step="1" data-each="${each}"> / ${q}</td></tr>`;
  }).join("");
  const bench = station
    ? `<p class="sf-ok"><i class="fas fa-check"></i> At a workbench.</p><input type="hidden" name="bench" value="1">`
    : tools ? `<p class="sf-ok"><i class="fas fa-toolbox"></i> Carrying tools: you can do this anywhere.</p><input type="hidden" name="bench" value="1">`
      : `<p class="sf-warn"><i class="fas fa-triangle-exclamation"></i> Needs a workbench, a Toolkit or a Multi-Tool.</p>
         <label class="sf-check"><input type="checkbox" name="bench"> I'm at a workbench (one on the map counts)</label>`;
  const edge = level ? `<p class="sf-ok"><i class="fas fa-recycle"></i> ${level === 2 ? "Improved Scrapper" : "Scrapper"}: extra Resources${level === 2 ? " and Rares" : ""}, in half the time.</p>` : "";
  const content = `<div class="sf-salvage">
    <p>Every 10 caps of Junk gives 5 Common and 1 Uncommon Resources and takes 30 minutes. No roll needed.</p>
    <div class="form-group"><label>Junk to break down</label><div class="form-fields">
      <input type="number" name="junk" value="${junk}" min="0" max="${junk}" step="1"> <span>of ${junk}</span></div></div>
    ${scrap.length ? `<details ${junk ? "" : "open"}><summary>Scrap gear too (counts as Junk worth half its price)</summary>
      <table class="sf-scrap"><thead><tr><th>Item</th><th>Junk each</th><th>Scrap</th></tr></thead><tbody>${rows}</tbody></table>
      <p class="sf-sub">Worn and wielded gear isn't listed. Consumables, ammo and fusion cores can't be scrapped.</p></details>` : ""}
    ${bench}${edge}
    <p class="sf-total" data-total></p></div>`;

  const update = (form) => {
    let v = Math.max(0, Math.min(junk, Math.floor(Number(form.elements.junk.value) || 0)));
    for (const el of form.querySelectorAll("input[name^=scrap_]")) v += Math.max(0, Math.min(Number(el.max), Math.floor(Number(el.value) || 0))) * Number(el.dataset.each);
    const out = form.querySelector("[data-total]");
    if (out) out.innerHTML = v ? `<strong>${v} caps of Junk</strong> gives ${listGot(yieldFor(v, level))} and takes ${timeText(minutesFor(v, level))}.` : "Choose some Junk or gear to break down.";
  };

  const plan = await foundry.applications.api.DialogV2.wait({
    window: { title: `Break Down Junk: ${actor.name}`, icon: "fas fa-recycle" },
    position: { width: 520 },
    rejectClose: false,
    content,
    render: (event, dialog) => {
      const form = (dialog?.element ?? event?.target?.element)?.querySelector("form") ?? dialog?.form;
      if (!form) return;
      form.addEventListener("input", () => update(form));
      update(form);
    },
    buttons: [
      { action: "ok", label: "Break It Down", icon: "fas fa-recycle", default: true, callback: (ev, btn) => {
        const f = btn.form.elements;
        const scrapList = [];
        for (const i of scrap) {
          const n = Math.max(0, Math.min(qtyOf(i), Math.floor(Number(f[`scrap_${i.id}`]?.value) || 0)));
          if (n) scrapList.push({ id: i.id, name: i.name, qty: n, value: n * Math.floor(priceOf(i) / 2) });
        }
        return {
          junk: Math.max(0, Math.min(junk, Math.floor(Number(f.junk.value) || 0))),
          scrap: scrapList,
          bench: f.bench.type === "hidden" ? true : !!f.bench.checked,
        };
      } },
      { action: "cancel", label: "Cancel" },
    ],
  });
  return plan && typeof plan === "object" ? plan : null;
}

/* ------------------------------------------------------------------ inventory */

async function spendJunk(actor, amount) {
  for (const i of actor.items.filter((x) => x.name === "Junk")) {
    if (amount <= 0) break;
    const q = qtyOf(i), take = Math.min(q, amount);
    amount -= take;
    if (take >= q) await i.delete(); else await i.update({ "system.quantity": q - take });
  }
}

async function spendScrap(actor, list) {
  for (const s of list) {
    const i = actor.items.get(s.id);
    if (!i) continue;
    const q = qtyOf(i);
    if (s.qty >= q) await i.delete(); else await i.update({ "system.quantity": q - s.qty });
  }
}

async function addMaterials(actor, got) {
  for (const key of ["common", "uncommon", "rare"]) {
    const n = got[key];
    if (!n) continue;
    const m = MATERIALS[key];
    const have = actor.items.find((i) => i.name === m.name);
    if (have) { await have.update({ "system.quantity": qtyOf(have) + n }); continue; }
    const src = await fromUuid(m.uuid);
    if (!src) { ui.notifications.warn(`Savage Fallout: couldn't find ${m.name} in the compendium.`); continue; }
    const data = src.toObject();
    delete data._id; delete data.folder;
    data.system.quantity = n;
    data._stats = { ...(data._stats ?? {}), compendiumSource: m.uuid };
    await actor.createEmbeddedDocuments("Item", [data]);
  }
}

/* ------------------------------------------------------------------ the action */

/**
 * Break down Junk (and optionally scrap gear) into Common, Uncommon and Rare Materials.
 * @param {object} [opts]
 * @param {Actor} [opts.actor]       who's working; asks if not given
 * @param {string|null} [opts.station]  a Workbench station key when used at a bench (no −2)
 */
export async function breakDownJunk({ actor = null, station = null } = {}) {
  actor = actor ?? (await chooseActor());
  if (!actor) return null;
  if (!actor.isOwner) return ui.notifications.warn(`You don't own ${actor.name}.`);
  if (!junkOf(actor) && !scrapCandidates(actor).length) return ui.notifications.info(`${actor.name} has no Junk or gear to break down.`);

  const plan = await askPlan(actor, station);
  if (!plan) return null;
  const value = plan.junk + plan.scrap.reduce((a, s) => a + s.value, 0);
  if (value <= 0) return ui.notifications.info("Nothing chosen to break down.");

  if (!plan.bench && !station && !hasTools(actor)) return ui.notifications.warn("Breaking down Junk needs a workbench, a Toolkit or a Multi-Tool.");

  const level = scrapperLevel(actor);
  const got = yieldFor(value, level);
  const minutes = minutesFor(value, level);
  await spendJunk(actor, plan.junk);
  await spendScrap(actor, plan.scrap);
  await addMaterials(actor, got);

  const used = [plan.junk ? `Junk ×${plan.junk}` : "", ...plan.scrap.map((s) => `${esc(s.name)}${s.qty > 1 ? ` ×${s.qty}` : ""} (${s.value} caps)`)].filter(Boolean).join(", ");
  const content = `<div class="sf-salvage-card">
    <h3><i class="fas fa-recycle"></i> ${esc(actor.name)} breaks down Junk</h3>
    <p><strong>Used:</strong> ${used} = ${value} caps of Junk</p>
    <p class="sf-got"><strong>Got:</strong> ${listGot(got)} Resources${level ? ` (${level === 2 ? "Improved Scrapper" : "Scrapper"})` : ""}</p>
    <p class="sf-sub"><i class="far fa-clock"></i> Takes ${timeText(minutes)}.</p></div>`;
  await ChatMessage.create({ speaker: ChatMessage.getSpeaker({ actor }), content });
  return { value, got, minutes };
}

Hooks.once("ready", () => {
  const api = game.modules.get(MOD)?.api;
  if (api) api.breakDownJunk = breakDownJunk;
  globalThis.SavageFallout = { ...(globalThis.SavageFallout ?? {}), breakDownJunk };
});
