/**
 * Savage Fallout: The Stockpile shop module, when it's installed.
 *
 * 1. Caps: SWADE keeps money in system.details.currency. If the world hasn't told The Stockpile where the wallet
 *    is, it lets everyone buy for free, so the GM's client fills in the wallet field and the currency name once.
 * 2. Junk and trade goods sell for their listed value (Scavenging and Crafting: Selling Salvage). The Stockpile
 *    pays one trade-in rate per shop for everything, so for items flagged fullValue we hand it a price that
 *    comes back out at full value once the shop's rate is applied. Which shop a trade-in is going to is read
 *    from the trade request itself as it arrives (players), or from the shop the GM last opened (GM's own sales).
 */
const MOD = "fallout-companion";
const SP = "the-stockpile";
const FULL_VALUE = new Set(["Junk", "Locket", "Silver Pocketwatch", "Pre-War Money", "Pre-War Valuables"]);

const isFullValue = (item) => !!(item?.flags?.[MOD]?.fullValue || FULL_VALUE.has(item?.name));
const pending = new Map();   // traded item id -> shop id, from trade requests in flight
let lastShopId = null;

Hooks.once("ready", async () => {
  const sp = game.modules.get(SP);
  if (!sp?.active || game.system.id !== "swade") return;

  // 1. Wallet and currency name (GM, once, only when unset).
  if (game.user.isGM && game.users.activeGM?.id === game.user.id) {
    try {
      const set = [];
      if (!String(game.settings.get(SP, "genericCurrencyPath") || "").trim()) { await game.settings.set(SP, "genericCurrencyPath", "system.details.currency"); set.push("wallet"); }
      if (!String(game.settings.get(SP, "genericCurrencyLabel") || "").trim()) { await game.settings.set(SP, "genericCurrencyLabel", "caps"); set.push("currency name"); }
      if (set.length) ui.notifications.info(`Savage Fallout: The Stockpile now uses each character's caps (set its ${set.join(" and ")}).`);
    } catch (err) { console.warn("Savage Fallout | couldn't set The Stockpile's currency", err); }
  }

  // 2. Full-value trade-ins.
  try {
    const route = (p) => foundry.utils.getRoute(`modules/${SP}/scripts/${p}`);
    const { getAdapter, SystemAdapter } = await import(route("systems/adapter.js"));
    const store = sp.api?.ShopStore;
    const adapter = getAdapter();
    if (!adapter || !store) return;
    const rawPrice = (item) => SystemAdapter.prototype.priceOfItem.call(adapter, item);

    // Remember which shop each traded item is going to, from the request itself.
    game.socket.on(`module.${SP}`, (data) => {
      if (data?.action !== "request") return;
      const p = data.payload ?? {};
      for (const t of [...(p.tradeIns ?? []), ...(p.items ?? [])]) if (t?.itemId && p.shopId) {
        pending.set(t.itemId, p.shopId);
        setTimeout(() => { if (pending.get(t.itemId) === p.shopId) pending.delete(t.itemId); }, 60000);
      }
    });
    const get = store.get.bind(store);
    store.get = (id, ...rest) => { const r = get(id, ...rest); if (r) lastShopId = id; return r; };

    const openShopId = () => {
      for (const app of foundry.applications.instances?.values?.() ?? []) if (app.rendered && app.shopId) return app.shopId;
      return null;
    };
    const rateFor = (item) => {
      const id = pending.get(item?.id) ?? openShopId() ?? lastShopId;
      const r = Number(id ? get(id)?.shop?.economy?.sellRate : NaN);
      return r > 0 ? r : 1;
    };

    const priceOfItem = adapter.priceOfItem.bind(adapter);
    adapter.priceOfItem = (item) => (isFullValue(item) ? rawPrice(item) / rateFor(item) : priceOfItem(item));
    const appraise = adapter.appraiseItem.bind(adapter);
    adapter.appraiseItem = async (item) => {
      if (!isFullValue(item)) return appraise(item);
      const src = await adapter._compendiumSource?.(item);
      // Same spoof guard as The Stockpile: a sourceless item's own price is capped.
      return (src ? rawPrice(src) : Math.min(rawPrice(item), 1000)) / rateFor(item);
    };
    console.log("Savage Fallout | The Stockpile: Junk and trade goods sell at full value");
  } catch (err) {
    console.warn("Savage Fallout | couldn't connect to The Stockpile's trade-ins", err);
  }
});
