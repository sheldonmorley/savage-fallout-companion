/**
 * Savage Fallout Workbench: crafting and mod installation in one window.
 *
 * Open it from: the Token Controls toolbar or a character sheet's menu (no station: browse, cook, and Deluxe Toolkit installs),
 * or by double-clicking a Workbench Station token on a map (that station's full recipes).
 *
 * Access rules (Sheldon, 2026-10-06):
 *  - Recipes needing no Edge are known by everyone.
 *  - Taking an Edge teaches that Edge's standard recipes. Rare recipes must be taught by the GM.
 *  - Crafting and installing are Edge-gated: no Edge, no craft, even if the recipe was taught.
 *  - What a character knows is stored on the character (flags["fallout-companion"].recipes).
 */
import { isRobot, robotCandidates, robotFitProblem, installedOn, installRobotMod, removeRobotMod } from "./robots.mjs";
import { partData, partFitProblem, installedParts, installPart, removePart, newAutomatron } from "./automatron.mjs";
import { esc, hasEdge, skillRoll, chatResult, drawMishap, buildInstalled, recompute, fitProblem, summary } from "./crafting.mjs";

const MOD = "fallout-companion";
const STATIONS = [
  { key: "weapons", label: "Weapons Workbench", icon: "fa-gun", install: "weapon" },
  { key: "armor", label: "Armor Workbench", icon: "fa-shirt", install: "armor" },
  { key: "powerArmor", label: "Power Armor Station", icon: "fa-robot", install: "powerArmor" },
  { key: "chemistry", label: "Chemistry Station", icon: "fa-flask" },
  { key: "cooking", label: "Cooking Station", icon: "fa-fire-burner" },
  { key: "robot", label: "Robot Workbench", icon: "fa-screwdriver-wrench", install: "robot" },
];
const EDGE_ORDER = ["Gun Nut", "Improved Gun Nut", "Blacksmith", "Improved Blacksmith", "Armorer", "Improved Armorer", "Science!", "Chemist", "Robotics Expert"];
const CPLX_ORDER = ["Simple", "Basic", "Advanced", "Complex", "Masterwork"];
const PORTABLE_BENCH = ["Deluxe Toolkit"];

let RECIPES = null;
async function recipes() {
  if (RECIPES) return RECIPES;
  RECIPES = await (await fetch(`modules/${MOD}/scripts/recipes.json`)).json();
  // Add-on modules (e.g. Savage Fallout: Settlers) can add recipes: module.json flags["fallout-companion"].recipes = "path/to/recipes.json".
  for (const m of game.modules) {
    const path = m.active && m.id !== MOD && m.flags?.[MOD]?.recipes;
    if (!path) continue;
    try {
      const extra = await (await fetch(`modules/${m.id}/${path}`)).json();
      const have = new Set(RECIPES.map((r) => r.id));
      RECIPES.push(...extra.filter((r) => !have.has(r.id)));
    } catch (err) { console.warn(`Savage Fallout | couldn't load recipes from ${m.id}`, err); }
  }
  return RECIPES;
}

/* ------------------------------------------------------------------ rules helpers */

const taughtList = (actor) => actor.flags?.[MOD]?.recipes ?? [];
const qtyOf = (item) => Number(item.system?.quantity ?? 1) || 0;
const countItem = (actor, name) => actor.items.filter((i) => i.name === name).reduce((a, i) => a + qtyOf(i), 0);
const hasAny = (actor, names) => names.some((n) => actor.items.some((i) => i.name === n));

/** How the character knows a recipe: "common" | "edge" | "taught" | null (unknown). */
function knowledge(actor, r) {
  if (taughtList(actor).includes(r.id)) return "taught";
  if (r.rare) return null;
  if (!r.edges.length && !r.anyEdges.length) return "common";
  if (r.edges.length && r.edges.every((e) => hasEdge(actor, e))) return "edge";
  if (r.anyEdges.length && r.anyEdges.some((e) => hasEdge(actor, e))) return "edge";
  return null;
}
function missingEdges(actor, r) {
  const miss = r.edges.filter((e) => !hasEdge(actor, e));
  if (r.anyEdges.length && !r.anyEdges.some((e) => hasEdge(actor, e))) miss.push(r.anyEdges.join(" or "));
  return miss;
}
function materials(actor, r) {
  const picks = [], missing = [];
  for (const slot of r.ingredients) {
    const alt = slot.find((a) => countItem(actor, a.name) >= a.qty);
    if (alt) picks.push(alt);
    else missing.push(slot.map((a) => `${a.name} ×${a.qty} (have ${countItem(actor, a.name)})`).join(" or "));
  }
  return { ok: !missing.length, picks, missing };
}
/** Station access (2d20 rule): every recipe needs its station, except cooking, which works anywhere. */
function stationAccess(actor, r, station) {
  if (r.station === "cooking" || station === r.station) return { ok: true, mod: 0 };
  const label = STATIONS.find((s) => s.key === r.station)?.label ?? "station";
  return { ok: false, reason: `needs a ${label}` };
}
/** Where a mod is installed, and what installing it here costs: 0 at the bench, −2 with a Deluxe Toolkit, null if impossible. */
function modBench(mod) { return mod.slot === "Power Armor" ? "powerArmor" : mod.kind === "weapon" ? "weapons" : "armor"; }
function benchPenalty(actor, mod, station) {
  if (station === modBench(mod)) return 0;
  if (hasAny(actor, PORTABLE_BENCH)) return -2;
  return game.user.isGM ? 0 : null;
}

function edgeGroup(r) {
  if (r.edges.length) return r.edges.join(" + ");
  if (r.anyEdges.length) return r.anyEdges.join(" or ");
  return "No Edge";
}
function groupOrder(label) {
  if (label === "No Edge") return -1;
  const i = EDGE_ORDER.findIndex((e) => label.startsWith(e));
  return i < 0 ? 99 : i + (label.includes("+") ? 0.5 : 0);
}
function governingBonus(actor, bonusEdges, skill) {
  const gov = (bonusEdges ?? []).find((e) => hasEdge(actor, e) || hasEdge(actor, `Improved ${e}`));
  if (!gov) return null;
  if (skill === "Repair" && hasEdge(actor, "Mr. Fix It")) return null; // its +2 is already on the skill; bonuses don't stack
  return gov;
}

/* ------------------------------------------------------------------ inventory changes */

async function removeMaterials(actor, picks, fraction = 1) {
  const updates = [], deletes = [];
  for (const p of picks) {
    let left = fraction === 1 ? p.qty : p.qty - Math.floor(p.qty / 2);
    for (const item of actor.items.filter((i) => i.name === p.name)) {
      if (left <= 0) break;
      const have = qtyOf(item);
      if (have > left) { updates.push({ _id: item.id, "system.quantity": have - left }); left = 0; }
      else { deletes.push(item.id); left -= have; }
    }
  }
  if (updates.length) await actor.updateEmbeddedDocuments("Item", updates);
  if (deletes.length) await actor.deleteEmbeddedDocuments("Item", deletes);
}
async function addProduct(actor, product, qty) {
  const src = await fromUuid(product.uuid);
  if (!src) throw new Error(`Product not found: ${product.uuid}`);
  const stackable = !["weapon", "armor", "shield"].includes(src.type);
  const existing = stackable ? actor.items.find((i) => i.name === src.name && !i.flags?.[MOD]?.modding) : null;
  if (existing) return existing.update({ "system.quantity": qtyOf(existing) + qty });
  const data = src.toObject();
  delete data._id; delete data.folder;
  data.system.quantity = stackable ? qty : 1;
  data._stats = { ...(data._stats ?? {}), compendiumSource: product.uuid };
  const docs = [];
  for (let n = 0; n < (stackable ? 1 : qty); n++) docs.push(foundry.utils.deepClone(data));
  return actor.createEmbeddedDocuments("Item", docs);
}

/* ------------------------------------------------------------------ rolls */

/**
 * Roll a skill through the SWADE system's own roll dialog (same window as clicking the skill on the sheet),
 * with our modifiers pre-filled. Returns {success, raise, critFail, total}, or null if the dialog was closed.
 */
export async function swadeRoll(actor, skillName, lines, flavour) {
  const additionalMods = lines.filter(([v]) => v).map(([v, l]) => ({ label: l, value: v > 0 ? `+${v}` : `${v}` }));
  if (typeof actor.rollSkill !== "function") return skillRoll(actor, skillName, lines, esc(flavour));
  const skill = actor.items.find((i) => i.type === "skill" && i.name.toLowerCase() === skillName.toLowerCase());
  const opts = { additionalMods, flavour, title: `${skillName}: ${flavour}` };
  let roll;
  if (skill) roll = await actor.rollSkill(skill.id, opts);
  else if (typeof actor.makeUnskilledAttempt === "function") roll = await actor.makeUnskilledAttempt(opts);
  else roll = await actor.rollSkill(null, opts);
  if (Array.isArray(roll)) roll = roll[0];
  if (!roll) return null;
  const tn = Number(roll.targetNumber ?? roll.options?.targetNumber ?? 4) || 4;
  const total = Number(roll.total ?? 0);
  const critFail = !!(typeof roll.isCritfail === "function" ? roll.isCritfail() : roll.isCritfail);
  const success = !critFail && total >= tn;
  return { success, raise: success && total >= tn + 4, critFail, total, tn };
}

/* ------------------------------------------------------------------ the window */

export class Workbench extends foundry.applications.api.ApplicationV2 {
  static DEFAULT_OPTIONS = {
    id: "sf-workbench-{id}",
    classes: ["sf-workbench"],
    tag: "div",
    window: { title: "Workbench", icon: "fas fa-hammer", resizable: true },
    position: { width: 940, height: 720 },
    actions: {
      sfTab: Workbench.#onTab, craft: Workbench.#onCraft, teach: Workbench.#onTeach,
      install: Workbench.#onInstall, strip: Workbench.#onStrip, stripRobot: Workbench.#onStripRobot, newAutomatron: Workbench.#onNewAutomatron, toggleCraftable: Workbench.#onToggleCraftable, sfFold: Workbench.#onFold, breakDown: Workbench.#onBreakDown,
    },
  };

  static instances = new Map();

  constructor({ actor, station = null, stationName = null } = {}, options = {}) {
    super(options);
    this._actor = actor;
    this.actorUuid = actor.uuid;
    this.station = station;                 // null = no station
    this.stationName = stationName;
    this.tab = station ?? "weapons";
    this.filter = "";
    this.onlyCraftable = false;
    this.modId = null;
  }

  /** Always resolve the live actor (token actors can be rebuilt while the window is open). */
  get actor() {
    let a = null;
    try { a = fromUuidSync(this.actorUuid); } catch (e) { /* fall back */ }
    if (a) this._actor = a;
    return this._actor;
  }

  get title() {
    const where = this.station ? (this.stationName || STATIONS.find((s) => s.key === this.station)?.label) : "no station";
    return `Workbench: ${this.actor.name} (${where})`;
  }

  async _prepareContext() {
    const all = await recipes();
    return { all };
  }

  async _renderHTML({ all }) {
    const actor = this.actor, gm = game.user.isGM;
    const junkHere = countItem(actor, "Junk");
    const tabs = STATIONS.map((s) => `<a class="sf-tab ${this.tab === s.key ? "active" : ""}" data-action="sfTab" data-station="${s.key}">
      <i class="fas ${s.icon}"></i> ${esc(s.label)}${this.station === s.key ? ' <i class="fas fa-location-dot" title="You are here"></i>' : ""}</a>`).join("");
    const st = STATIONS.find((s) => s.key === this.tab);
    const banner = this.station === this.tab || this.tab === "cooking"
      ? `<div class="sf-banner ok"><i class="fas fa-check"></i> ${this.tab === "cooking" ? "Cooking works anywhere you can light a fire." : `At the ${esc(st.label)}: every recipe you know is available.`}</div>`
      : `<div class="sf-banner"><i class="fas fa-triangle-exclamation"></i> Not at a ${esc(st.label)}: you can browse these recipes, but crafting them needs the station. Find one on the map.${st.install ? " A Deluxe Toolkit lets you install and remove mods here at −2." : ""}</div>`;

    // ---- recipes
    const list = all.filter((r) => r.station === this.tab).map((r) => {
      const know = knowledge(actor, r);
      const miss = missingEdges(actor, r);
      const mat = materials(actor, r);
      const acc = stationAccess(actor, r, this.station);
      const can = know && !miss.length && mat.ok && acc.ok;
      return { r, know, miss, mat, acc, can };
    }).filter((x) => gm || x.know)
      .filter((x) => !this.onlyCraftable || x.can)
      .filter((x) => !this.filter || x.r.name.toLowerCase().includes(this.filter.toLowerCase()));
    // Sections by item type (collapsible), then sub-groups by required Edge.
    const folded = new Set(game.user.getFlag(MOD, "wbFolded") ?? []);
    const types = {};
    for (const x of list) (types[x.r.type] ??= []).push(x);
    const typeOrder = (t) => (/mod/i.test(t) ? 1 : 0);
    const row = (x) => {
      const r = x.r;
      const ing = r.ingredients.map((slot) => slot.map((a) => {
        const have = countItem(actor, a.name);
        return `<span class="${have >= a.qty ? "have" : "need"}">${esc(a.name.replace(" Materials", ""))} ${a.qty}</span>`;
      }).join(" <em>or</em> ")).join(", ") || "<span class='have'>no materials</span>";
      const why = !x.know ? (x.miss.length ? `needs ${x.miss.join(", ")}` : "not learned yet") : x.miss.length ? `needs ${x.miss.join(", ")}` : !x.acc.ok ? x.acc.reason : !x.mat.ok ? "missing materials" : "";
      const tag = x.know === "taught" ? '<span class="sf-pill">learned</span>' : !x.know ? '<span class="sf-pill unknown">not known</span>' : "";
      const rare = r.rare ? '<span class="sf-pill rare" title="Rare recipe: must be found in play">rare</span>' : "";
      let teach = "";
      if (gm) {
        if (x.know === "taught") teach = `<button type="button" class="sf-mini" data-action="teach" data-id="${r.id}" title="Forget this recipe"><i class="fas fa-book-skull"></i></button>`;
        else if (r.rare && !x.miss.length) teach = `<button type="button" class="sf-mini teach" data-action="teach" data-id="${r.id}" title="Teach this rare recipe"><i class="fas fa-book-medical"></i></button>`;
        else if (r.rare) teach = `<button type="button" class="sf-mini" disabled title="Needs ${esc(x.miss.join(" and "))} before it can be learned"><i class="fas fa-book-medical"></i></button>`;
        else teach = `<span class="sf-mini-gap" title="${x.know === "common" ? "Everyone knows this recipe" : x.know ? "Known through the Edge" : `Learned by taking ${esc(x.miss.join(" and "))}`}"></span>`;
      }
      return `<li class="sf-recipe ${x.can ? "" : "sf-unavailable"}">
        <img src="${esc(r.product.img || "icons/svg/item-bag.svg")}" alt="">
        <div class="sf-main"><div class="sf-name">${esc(r.name)}${r.product.qty > 1 ? ` ×${r.product.qty}` : ""} ${tag}${rare}</div>
          <div class="sf-sub">${esc(r.complexity)} (${r.mod >= 0 ? "+" : ""}${r.mod}) · ${esc(r.skill)} · ${ing}${why ? ` · <span class="sf-why">${esc(why)}</span>` : ""}</div></div>
        ${teach}<button type="button" class="sf-craft" data-action="craft" data-id="${r.id}" ${x.can ? "" : "disabled"}><i class="fas fa-hammer"></i> Craft</button></li>`;
    };
    const groupHtml = Object.keys(types).sort((a, b) => typeOrder(a) - typeOrder(b) || a.localeCompare(b)).map((t) => {
      const key = `${this.tab}|${t}`;
      const open = !folded.has(key) || !!this.filter;
      const items = types[t];
      const ready = items.filter((x) => x.can).length;
      const groups = {};
      for (const x of items) (groups[edgeGroup(x.r)] ??= []).push(x);
      const inner = Object.keys(groups).sort((a, b) => groupOrder(a) - groupOrder(b) || a.localeCompare(b)).map((g) =>
        `<h4>${esc(g)}</h4><ul>${groups[g].sort((a, b) => CPLX_ORDER.indexOf(a.r.complexity) - CPLX_ORDER.indexOf(b.r.complexity) || a.r.name.localeCompare(b.r.name)).map(row).join("")}</ul>`).join("");
      const isMod = /mod/i.test(t);
      return `<section class="sf-type ${isMod ? "mods" : "items"} ${open ? "open" : ""}">
        <h3 data-action="sfFold" data-key="${esc(key)}"><i class="fas ${open ? "fa-caret-down" : "fa-caret-right"}"></i>
          <i class="fas ${isMod ? "fa-puzzle-piece" : "fa-box"}"></i> ${esc(t.replace(/^Cooking: /, ""))}
          <span class="sf-count">${items.length} recipe${items.length === 1 ? "" : "s"} · ${ready} ready</span></h3>
        ${open ? `<div class="sf-type-body">${inner}</div>` : ""}</section>`;
    }).join("") || `<p class="sf-empty">${gm ? "No recipes match." : "No recipes you know for this station yet."}</p>`;

    // ---- install mods
    let installHtml = "";
    if (st.install === "robot") {
      installHtml = this.#robotPanel(actor, gm);
    } else if (st.install) {
      const kindOk = (m) => (st.install === "weapon" ? m.kind === "weapon" : st.install === "armor" ? m.kind === "armor" && m.slot !== "Power Armor" : m.slot === "Power Armor");
      const atBench = this.station === this.tab;
      const benchOk = atBench || hasAny(actor, PORTABLE_BENCH) || gm;
      const mods = actor.items.filter((i) => i.flags?.[MOD]?.mod && kindOk(i.flags[MOD].mod));
      if (!this.modId || !mods.some((m) => m.id === this.modId)) this.modId = mods[0]?.id ?? null;
      const modItem = actor.items.get(this.modId);
      const mdata = modItem ? { ...modItem.flags[MOD].mod, name: modItem.name } : null;
      const missE = mdata ? mdata.edges.filter((e) => !hasEdge(actor, e)) : [];
      const targets = mdata ? actor.items.filter((i) => ["weapon", "armor"].includes(i.type)).map((i) => ({ i, why: fitProblem(i.toObject(), mdata) })) : [];
      const modOpts = mods.map((m) => `<option value="${m.id}" ${m.id === this.modId ? "selected" : ""}>${esc(m.name)}${qtyOf(m) > 1 ? ` (×${qtyOf(m)})` : ""}</option>`).join("");
      const tgtOpts = targets.sort((a, b) => (a.why ? 1 : 0) - (b.why ? 1 : 0)).map(({ i, why }) => `<option value="${i.id}" ${why ? "disabled" : ""}>${esc(i.name)}${why ? ` (${esc(why)})` : ""}</option>`).join("");
      const canInstall = mdata && benchOk && !missE.length && targets.some((t) => !t.why);
      const note = !mods.length ? "You aren't carrying any mods for this bench."
        : missE.length ? `Needs ${missE.join(" and ")} to install.`
        : !benchOk ? "Installing needs this workbench (or a Deluxe Toolkit)."
        : !targets.some((t) => !t.why) ? "Nothing you carry can take this mod."
        : !atBench && hasAny(actor, PORTABLE_BENCH) ? "No workbench here: using your Deluxe Toolkit, at −2." : "";
      const modded = actor.items.filter((i) => (i.flags?.[MOD]?.modding?.installed ?? []).length && (st.install === "weapon" ? i.type === "weapon" : i.type === "armor"));
      const stripRows = modded.map((i) => `<li><strong>${esc(i.name)}</strong>: ${i.flags[MOD].modding.installed.map((m, k) =>
        `<span class="sf-mod">${esc(m.name)} <a data-action="strip" data-item="${i.id}" data-index="${k}" title="Remove intact (same roll)"><i class="fas fa-xmark"></i></a></span>`).join(" ")}</li>`).join("");
      installHtml = `<section class="sf-install"><h3><i class="fas fa-screwdriver-wrench"></i> Install a Mod</h3>
        <div class="sf-row"><label>Mod <select name="mod">${modOpts || "<option>(none)</option>"}</select></label>
        <label>Onto <select name="target">${tgtOpts || "<option>(nothing fits)</option>"}</select></label>
        <button type="button" data-action="install" ${canInstall ? "" : "disabled"}><i class="fas fa-wrench"></i> Install</button></div>
        ${note ? `<p class="sf-why">${esc(note)}</p>` : ""}
        ${stripRows ? `<p class="sf-sub">Installed mods (click × to remove one intact):</p><ul class="sf-modded">${stripRows}</ul>` : ""}</section>`;
    }

    return `<nav class="sf-tabs">${tabs}</nav>${banner}${installHtml}
      <div class="sf-tools"><input type="search" name="filter" placeholder="Search recipes" value="${esc(this.filter)}">
      <label><input type="checkbox" data-action="toggleCraftable" ${this.onlyCraftable ? "checked" : ""}> Only what I can craft</label>
      <button type="button" class="sf-breakdown" data-action="breakDown" title="Turn Junk and unwanted gear into crafting Resources (30 minutes per 10 caps, no roll)"><i class="fas fa-recycle"></i> Break Down Junk${junkHere ? ` (${junkHere})` : ""}</button>
      ${gm ? `<span class="sf-gm">GM view: recipes ${esc(actor.name)} doesn't know are shown too. Only rare recipes are taught: <i class="fas fa-book-medical"></i> teaches one, <i class="fas fa-book-skull"></i> takes it back.</span>` : ""}</div>
      <div class="sf-list">${groupHtml}</div>`;
  }

  _replaceHTML(result, content) {
    const scroll = content.querySelector(".sf-list")?.scrollTop ?? 0;
    content.innerHTML = result;
    const list = content.querySelector(".sf-list");
    if (list) list.scrollTop = scroll;
    const f = content.querySelector("input[name=filter]");
    f?.addEventListener("input", foundry.utils.debounce((ev) => { this.filter = ev.target.value; this._refocus = true; this.render(); }, 250));
    if (this._refocus && f) { f.focus(); f.setSelectionRange(f.value.length, f.value.length); }
    this._refocus = false;
    content.querySelector("select[name=mod]")?.addEventListener("change", (ev) => { this.modId = ev.target.value; this.render(); });
  }

  /* ---------------- actions */

  static #onTab(event, target) { this.tab = target.dataset.station; this.render(); }
  static #onToggleCraftable(event, target) { this.onlyCraftable = target.checked; this.render(); }
  static async #onBreakDown() {
    const fn = globalThis.SavageFallout?.breakDownJunk;
    if (!fn) return ui.notifications.warn("Break Down Junk isn't loaded.");
    const r = await fn({ actor: this.actor, station: this.station });
    if (r) this.render();
  }
  #robotPanel(actor, gm) {
    const atBench = this.station === "robot";
    const benchOk = atBench || hasAny(actor, PORTABLE_BENCH) || gm;
    const mods = actor.items.filter((i) => (i.flags?.[MOD]?.mod?.kind === "robot" && !i.flags?.[MOD]?.robotMod) || (partData(i) && !i.flags?.[MOD]?.robotPart));
    if (!this.modId || !mods.some((m) => m.id === this.modId)) this.modId = mods[0]?.id ?? null;
    const modItem = actor.items.get(this.modId);
    const part = modItem ? partData(modItem) : null;
    const mdata = modItem && !part ? { ...modItem.flags[MOD].mod, name: modItem.name } : null;
    const robots = robotCandidates(actor);
    const fit = (r) => part ? partFitProblem(r, part) : robotFitProblem(r, mdata);
    const targets = modItem ? robots.map((r) => ({ r, why: fit(r) })) : [];
    const opt = (m) => `<option value="${m.id}" ${m.id === this.modId ? "selected" : ""}>${esc(m.name)}${qtyOf(m) > 1 ? ` (×${qtyOf(m)})` : ""}</option>`;
    const rm = mods.filter((m) => !partData(m)), pp = mods.filter((m) => partData(m));
    const modOpts = (rm.length ? `<optgroup label="Robot mods">${rm.map(opt).join("")}</optgroup>` : "")
      + (pp.length ? `<optgroup label="Automatron parts">${pp.map((m) => opt(m)).join("")}</optgroup>` : "");
    const tgtOpts = targets.sort((a, b) => (a.why ? 1 : 0) - (b.why ? 1 : 0)).map(({ r, why }) =>
      `<option value="${r.uuid}" ${why ? "disabled" : ""}>${esc(r.name)}${r === actor ? " (yourself)" : ""}${why ? ` (${esc(why)})` : ""}</option>`).join("");
    const canInstall = modItem && benchOk && targets.some((t) => !t.why);
    const note = !mods.length ? "You aren't carrying any robot mods or Automatron parts."
      : !robots.length ? "No robot here that you can work on. Start a new Automatron, or bring a robot you own."
      : !benchOk ? "Installing needs a Robot Workbench (or a Deluxe Toolkit)."
      : !targets.some((t) => !t.why) ? (part ? "None of your robots can take this part right now." : "None of your robots has room for this mod.")
      : !atBench && hasAny(actor, PORTABLE_BENCH) ? "No workbench here: using your Deluxe Toolkit, at −2." : "";
    const chip = (r, i, kind) => `<span class="sf-mod">${esc(i.name)} <a data-action="stripRobot" data-robot="${r.uuid}" data-item="${i.id}" data-kind="${kind}" title="Remove intact (same roll)"><i class="fas fa-xmark"></i></a></span>`;
    const rows = robots.filter((r) => installedOn(r).length || installedParts(r).length).map((r) => `<li><strong>${esc(r.name)}</strong>: ${
      installedParts(r).map((i) => chip(r, i, "part")).join(" ")} ${installedOn(r).map((i) => chip(r, i, "mod")).join(" ")}</li>`).join("");
    const newBtn = (atBench || gm) ? `<button type="button" data-action="newAutomatron" title="A bare chassis to install parts on"><i class="fas fa-plus"></i> New Automatron</button>` : "";
    return `<section class="sf-install"><h3><i class="fas fa-robot"></i> Install Robot Mods and Automatron Parts</h3>
      <div class="sf-row"><label>Install <select name="mod">${modOpts || "<option>(none)</option>"}</select></label>
      <label>Onto <select name="target">${tgtOpts || "<option>(no robot)</option>"}</select></label>
      <button type="button" data-action="install" ${canInstall ? "" : "disabled"}><i class="fas fa-wrench"></i> Install</button> ${newBtn}</div>
      ${part ? `<p class="sf-sub">${esc(modItem.name)}: ${esc(part.slot)} part${part.frame && part.frame !== "Any" ? ` (${esc(part.frame)})` : ""}. Parts go on in order: torso first, then legs, head, arms, attachments and armor.</p>` : ""}
      ${note ? `<p class="sf-why">${esc(note)}</p>` : ""}
      ${rows ? `<p class="sf-sub">Installed (click × to remove one intact):</p><ul class="sf-modded">${rows}</ul>` : ""}</section>`;
  }

  static async #onNewAutomatron(event, target) {
    const actor = this.actor;
    const name = `${actor.name}'s Automatron`;
    try {
      const bot = await newAutomatron(actor, name);
      await chatResult(actor, `<p>${esc(actor.name)} starts a new Automatron: <strong>${esc(bot.name)}</strong>. Fit a torso first.</p>`);
    } catch (err) {
      console.error("Savage Fallout | new Automatron failed", err);
      ui.notifications.error(`Couldn't create the Automatron: ${err.message}`);
    }
    this.render();
  }

  async #installPart(actor, item, robot) {
    const part = partData(item);
    const why = partFitProblem(robot, part);
    if (why) return ui.notifications.warn(`${item.name} can't go on ${robot.name}: ${why}.`);
    const pen = await this.#robotPenalty(actor);
    if (pen === null) return ui.notifications.warn("Building an Automatron needs a Robot Workbench or a Deluxe Toolkit.");
    const lines = pen ? [[pen, "Deluxe Toolkit, no workbench"]] : [];
    if (this.station === "robot") lines.push([1, "Robot Workbench"]);
    const cx = { Advanced: -1, Complex: -2 }[part.craft?.complexity];
    if (cx) lines.push([cx, `${part.craft.complexity} part`]);
    const gov = governingBonus(actor, ["Robotics Expert"], "Repair");
    if (gov) lines.push([2, gov]);
    const res = await swadeRoll(actor, "Repair", lines, `Fitting ${item.name} to ${robot.name}`);
    if (!res) return;
    if (!res.success) {
      await chatResult(actor, `<p>The ${esc(item.name)} won't seat properly. ${esc(actor.name)} keeps the part and can try again.</p>`);
      return this.render();
    }
    try {
      await installPart(robot, item.toObject(), part);
      const q = qtyOf(item);
      if (q > 1) await item.update({ "system.quantity": q - 1 }); else await item.delete();
      await chatResult(actor, `<p>Fitted <strong>${esc(item.name)}</strong> to <strong>${esc(robot.name)}</strong>.</p>`);
    } catch (err) {
      console.error("Savage Fallout | part install failed", err);
      ui.notifications.error(`Couldn't fit the part: ${err.message}`);
    }
    this.render();
  }

  async #robotPenalty(actor) {
    if (this.station === "robot") return 0;
    if (hasAny(actor, PORTABLE_BENCH)) return -2;
    return game.user.isGM ? 0 : null;
  }

  async #installRobot(actor) {
    const root = this.element;
    const modItem = actor.items.get(root.querySelector("select[name=mod]")?.value);
    const robot = await fromUuid(root.querySelector("select[name=target]")?.value ?? "");
    if (!modItem || !robot) return;
    if (partData(modItem)) return this.#installPart(actor, modItem, robot);
    const mdata = { ...modItem.flags[MOD].mod, name: modItem.name };
    const why = robotFitProblem(robot, mdata);
    if (why) return ui.notifications.warn(`${modItem.name} can't go on ${robot.name}: ${why}.`);
    const pen = await this.#robotPenalty(actor);
    if (pen === null) return ui.notifications.warn("Installing a robot mod needs a Robot Workbench or a Deluxe Toolkit.");
    const lines = pen ? [[pen, "Deluxe Toolkit, no workbench"]] : [];
    const gov = governingBonus(actor, ["Robotics Expert"], "Repair");
    if (gov) lines.push([2, gov]);
    const res = await swadeRoll(actor, "Repair", lines, `Installing ${modItem.name} on ${robot.name} (an hour)`);
    if (!res) return;
    if (!res.success) {
      await chatResult(actor, `<p>The ${esc(modItem.name)} won't take. ${esc(actor.name)} keeps the mod and can try again.</p>`);
      return this.render();
    }
    try {
      await installRobotMod(robot, modItem.toObject(), mdata);
      const q = qtyOf(modItem);
      if (q > 1) await modItem.update({ "system.quantity": q - 1 }); else await modItem.delete();
      await chatResult(actor, `<p>Installed <strong>${esc(modItem.name)}</strong> on <strong>${esc(robot.name)}</strong>.</p><p><small>${esc(mdata.fx?.text ?? "")}</small></p>`);
    } catch (err) {
      console.error("Savage Fallout | robot mod install failed", err);
      ui.notifications.error(`Couldn't install the mod: ${err.message}`);
    }
    this.render();
  }

  static async #onStripRobot(event, target) {
    const actor = this.actor;
    const robot = await fromUuid(target.dataset.robot);
    const item = robot?.items.get(target.dataset.item);
    if (!item) return;
    const pen = await this.#robotPenalty(actor);
    if (pen === null) return ui.notifications.warn("Removing a robot mod needs a Robot Workbench or a Deluxe Toolkit.");
    const res = await swadeRoll(actor, "Repair", pen ? [[pen, "Deluxe Toolkit, no workbench"]] : [], `Removing ${item.name} from ${robot.name}`);
    if (!res) return;
    if (!res.success) { await chatResult(actor, `<p>${esc(item.name)} won't come out cleanly; it stays in.</p>`); return this.render(); }
    try {
      const name = item.name;
      const isP = !!item.flags?.[MOD]?.robotPart;
      const back = isP ? await removePart(robot, item) : await removeRobotMod(robot, item);
      const same = actor.items.find((i) => i.name === name && (isP ? partData(i) && !i.flags?.[MOD]?.robotPart : i.flags?.[MOD]?.mod && !i.flags?.[MOD]?.robotMod));
      if (same) await same.update({ "system.quantity": qtyOf(same) + 1 });
      else await actor.createEmbeddedDocuments("Item", [back]);
      await chatResult(actor, `<p>Removed <strong>${esc(name)}</strong> from <strong>${esc(robot.name)}</strong>.</p>`);
    } catch (err) {
      console.error("Savage Fallout | robot mod removal failed", err);
      ui.notifications.error(`Couldn't remove the mod: ${err.message}`);
    }
    this.render();
  }

  static async #onFold(event, target) {
    const key = target.dataset.key;
    const folded = new Set(game.user.getFlag(MOD, "wbFolded") ?? []);
    folded.has(key) ? folded.delete(key) : folded.add(key);
    await game.user.setFlag(MOD, "wbFolded", [...folded]);
    this.render();
  }

  static async #onTeach(event, target) {
    if (!game.user.isGM) return;
    const actor = this.actor;
    const id = target.dataset.id;
    try {
      const cur = actor.getFlag(MOD, "recipes");
      const list = new Set(Array.isArray(cur) ? cur : Object.values(cur ?? {}).filter((v) => typeof v === "string"));
      const r = (await recipes()).find((x) => x.id === id);
      const learning = !list.has(id);
      learning ? list.add(id) : list.delete(id);
      await actor.setFlag(MOD, "recipes", [...list]);
      if (!new Set(actor.getFlag(MOD, "recipes") ?? []).has(id) === learning) throw new Error(`the change didn't stick on ${actor.name} (${actor.uuid})`);
      const owners = game.users.filter((u) => !u.isGM && actor.testUserPermission(u, "OWNER")).map((u) => u.id);
      await ChatMessage.create({ content: `<p><strong>${esc(actor.name)}</strong> ${learning ? "learned the recipe" : "no longer knows the recipe"} <strong>${esc(r?.name ?? id)}</strong>.</p>`,
        whisper: [game.user.id, ...owners] });
    } catch (err) {
      console.error("Savage Fallout | teach failed", err);
      ui.notifications.error(`Couldn't teach the recipe: ${err.message}`);
    }
    this.render();
  }

  static async #onCraft(event, target) {
    const actor = this.actor;
    const r = (await recipes()).find((x) => x.id === target.dataset.id);
    if (!r) return;
    const know = knowledge(actor, r), miss = missingEdges(actor, r), mat = materials(actor, r), acc = stationAccess(actor, r, this.station);
    if (!know && !game.user.isGM) return ui.notifications.warn("You don't know that recipe.");
    if (miss.length) return ui.notifications.warn(`${actor.name} needs ${miss.join(" and ")} to craft ${r.name}.`);
    if (!acc.ok) return ui.notifications.warn(`${r.name} ${acc.reason}.`);
    if (!mat.ok) return ui.notifications.warn(`Missing: ${mat.missing.join("; ")}`);
    const lines = [[r.mod, `${r.complexity} recipe`]];
    if (acc.mod) lines.push([acc.mod, acc.note]);
    const gov = governingBonus(actor, r.bonusEdges, r.skill);
    if (gov) lines.push([2, gov]);
    const res = await swadeRoll(actor, r.skill, lines, `Crafting ${r.name} (${r.time})`);
    if (!res) return;
    try {
      if (res.success) {
        let qty = r.product.qty;
        let time = r.time;
        if (res.raise) time = `${gov ? "a quarter" : "half"} of ${r.time}`;
        if (res.raise && r.camp) qty *= 2;
        await removeMaterials(actor, mat.picks);
        await addProduct(actor, r.product, qty);
        await chatResult(actor, `<p><strong>${esc(actor.name)}</strong> crafted <strong>${esc(r.product.name)}</strong>${qty > 1 ? ` ×${qty}` : ""} <small>(${esc(time)}${res.raise && r.camp ? "; the raise makes a second serving" : ""})</small>.</p>`);
      } else if (res.critFail) {
        await removeMaterials(actor, mat.picks);
        await chatResult(actor, `<p><strong>Critical Failure:</strong> the materials for ${esc(r.name)} are lost. Rolling on the Crafting Mishap table.</p>`);
        await drawMishap();
      } else {
        await chatResult(actor, `<p>${esc(r.name)} wasn't made. ${esc(actor.name)} can try to salvage half the materials (roll at −2).</p>`);
        const salvage = await swadeRoll(actor, r.skill, [...lines, [-2, "Salvage"]], `Salvaging materials from ${r.name}`);
        if (salvage?.success) {
          await removeMaterials(actor, mat.picks, 0.5);
          await chatResult(actor, `<p>${esc(r.name)} wasn't made, but ${esc(actor.name)} saved half the materials (rounded down).</p>`);
        } else {
          await removeMaterials(actor, mat.picks);
          await chatResult(actor, `<p>${esc(r.name)} wasn't made, and the materials are lost.</p>`);
        }
      }
    } catch (err) {
      console.error("Savage Fallout | craft failed", err);
      ui.notifications.error("Crafting hit an error; check the console (F12).");
    }
    this.render();
  }

  static async #onInstall(event, target) {
    const actor = this.actor;
    if (this.tab === "robot") return this.#installRobot(actor);
    const root = this.element;
    const modItem = actor.items.get(root.querySelector("select[name=mod]")?.value);
    const tgt = actor.items.get(root.querySelector("select[name=target]")?.value);
    if (!modItem || !tgt) return;
    const mdata = { ...modItem.flags[MOD].mod, name: modItem.name };
    const why = fitProblem(tgt.toObject(), mdata);
    if (why) return ui.notifications.warn(`${modItem.name} can't go on ${tgt.name}: ${why}.`);
    const missE = mdata.edges.filter((e) => !hasEdge(actor, e));
    if (missE.length) return ui.notifications.warn(`${actor.name} needs ${missE.join(" and ")} to install ${modItem.name}.`);
    const r = (await recipes()).find((x) => x.product.name === modItem.name);
    const pen = benchPenalty(actor, mdata, this.station);
    if (pen === null) return ui.notifications.warn(`Installing ${modItem.name} needs a ${STATIONS.find((s) => s.key === modBench(mdata))?.label} or a Deluxe Toolkit.`);
    const lines = [];
    if (pen) lines.push([pen, "Deluxe Toolkit, no workbench"]);
    const gov = governingBonus(actor, r?.bonusEdges ?? [], mdata.skill ?? "Repair");
    if (gov) lines.push([2, gov]);
    const time = mdata.slot === "Power Armor" ? "an hour" : "30 minutes";
    const res = await swadeRoll(actor, mdata.skill ?? "Repair", lines, `Installing ${modItem.name} on ${tgt.name} (${time})`);
    if (!res) return;
    if (!res.success) {
      await chatResult(actor, `<p>The ${esc(modItem.name)} won't seat properly. ${esc(actor.name)} keeps both parts and can try again.</p>`);
      return this.render();
    }
    const oldName = tgt.name;
    const newData = buildInstalled(tgt.toObject(), modItem.toObject(), mdata);
    await tgt.update({ name: newData.name, system: newData.system, [`flags.${MOD}.modding`]: newData.flags[MOD].modding });
    const q = qtyOf(modItem);
    if (q > 1) await modItem.update({ "system.quantity": q - 1 }); else await modItem.delete();
    await chatResult(actor, `<p><strong>${esc(oldName)}</strong> → <strong>${esc(newData.name)}</strong></p><p><small>${esc(summary(newData))}</small></p>`);
    this.render();
  }

  static async #onStrip(event, target) {
    const actor = this.actor;
    const item = actor.items.get(target.dataset.item);
    const idx = Number(target.dataset.index);
    const entry = item?.flags?.[MOD]?.modding?.installed?.[idx];
    if (!entry) return;
    const missE = (entry.edges ?? []).filter((e) => !hasEdge(actor, e));
    if (missE.length) return ui.notifications.warn(`${actor.name} needs ${missE.join(" and ")} to remove ${entry.name} intact.`);
    const pen = benchPenalty(actor, entry, this.station);
    if (pen === null) return ui.notifications.warn(`Removing ${entry.name} needs a ${STATIONS.find((s) => s.key === modBench(entry))?.label} or a Deluxe Toolkit.`);
    const res = await swadeRoll(actor, entry.skill ?? "Repair", pen ? [[pen, "Deluxe Toolkit, no workbench"]] : [], `Removing ${entry.name} from ${item.name}`);
    if (!res) return;
    if (!res.success) { await chatResult(actor, `<p>${esc(entry.name)} won't come off cleanly; it stays installed.</p>`); return this.render(); }
    const stripName = item.name;
    const data = item.toObject();
    data.flags[MOD].modding.installed = data.flags[MOD].modding.installed.filter((_, k) => k !== idx);
    recompute(data);
    await item.update({ name: data.name, system: data.system, [`flags.${MOD}.modding`]: data.flags[MOD].modding });
    const oldName = stripName;
    if (entry.itemData) {
      const same = actor.items.find((i) => i.name === entry.name && i.flags?.[MOD]?.mod);
      if (same) await same.update({ "system.quantity": qtyOf(same) + 1 });
      else await actor.createEmbeddedDocuments("Item", [foundry.utils.deepClone(entry.itemData)]);
    } else {
      const src = entry.uuid ? await fromUuid(entry.uuid) : null;
      if (src) await addProduct(actor, { uuid: entry.uuid }, 1);
      else ui.notifications.warn(`Couldn't find ${entry.name} to give back; add it by hand.`);
    }
    await chatResult(actor, `<p>Removed <strong>${esc(entry.name)}</strong> from <strong>${esc(oldName)}</strong>.</p>`);
    this.render();
  }

  async close(options) {
    Workbench.instances.delete(this.actorUuid);
    return super.close(options);
  }
}

/* ------------------------------------------------------------------ opening */

// Clicking a station token selects it and drops the hero's token, so remember the last crafter token selected.
let lastCrafterUuid = null;
/** Map fixtures (workbench stations, scavenge nodes) are never the one crafting or searching. */
export const isFixture = (a) => !!(a?.flags?.[MOD]?.station || a?.flags?.[MOD]?.scavenge);
Hooks.on("controlToken", (token, controlled) => {
  const a = token?.actor;
  if (controlled && a?.isOwner && !isFixture(a) && ["character", "npc"].includes(a.type)) lastCrafterUuid = a.uuid;
});

export async function chooseActor() {
  const controlled = canvas?.tokens?.controlled?.map((t) => t.actor).find((a) => a?.isOwner && !isFixture(a));
  if (controlled) return controlled;
  const last = lastCrafterUuid ? fromUuidSync(lastCrafterUuid) : null;
  if (last?.isOwner && !isFixture(last)) return last;
  if (!game.user.isGM && game.user.character) return game.user.character;
  const usable = (a) => !isFixture(a) && ["character", "npc"].includes(a.type);
  let options = game.actors.filter((a) => usable(a) && (game.user.isGM ? a.hasPlayerOwner : a.isOwner));
  // GM testing with no player-owned characters: offer every player character in the world.
  if (!options.length && game.user.isGM) options = game.actors.filter((a) => usable(a) && a.type === "character");
  if (options.length === 1) return options[0];
  if (!options.length) { ui.notifications.warn("No character to craft with."); return null; }
  const html = options.map((a) => `<option value="${a.id}">${esc(a.name)}</option>`).join("");
  const id = await foundry.applications.api.DialogV2.wait({
    window: { title: "Who's crafting?" }, rejectClose: false,
    content: `<div class="form-group"><label>Character</label><div class="form-fields"><select name="a">${html}</select></div></div>`,
    buttons: [{ action: "ok", label: "Open Workbench", default: true, callback: (ev, btn) => btn.form.elements.a.value }, { action: "cancel", label: "Cancel" }],
  });
  return game.actors.get(id) ?? null;
}

export async function openWorkbench({ actor = null, station = null, stationName = null } = {}) {
  actor = actor ?? (await chooseActor());
  if (!actor) return;
  const existing = Workbench.instances.get(actor.uuid);
  if (existing) {
    existing.station = station; existing.stationName = stationName;
    if (station) existing.tab = station;
    return existing.render({ force: true });
  }
  const app = new Workbench({ actor, station, stationName });
  Workbench.instances.set(actor.uuid, app);
  return app.render({ force: true });
}

/* ------------------------------------------------------------------ Workbench Station actors (map tokens) */

class WorkbenchStationSheet extends foundry.applications.api.DocumentSheetV2 {
  async render(options = {}) {
    const station = this.document.flags?.[MOD]?.station;
    if (station) openWorkbench({ station, stationName: this.document.name });
    return this;
  }
}

Hooks.once("init", () => {
  const DSC = foundry.applications.apps?.DocumentSheetConfig ?? globalThis.DocumentSheetConfig;
  DSC.registerSheet(Actor, MOD, WorkbenchStationSheet, { types: ["npc"], makeDefault: false, label: "Savage Fallout Workbench Station" });
});

Hooks.once("ready", () => {
  const api = game.modules.get(MOD)?.api;
  if (api) api.openWorkbench = openWorkbench;
  globalThis.SavageFallout = { ...(globalThis.SavageFallout ?? {}), openWorkbench };
  refreshModDescriptions();
});

/** GM, on load: refresh the name and Installed Mods list on already-modded gear (name prefixes, mod benefits). Stats are untouched. */
async function refreshModDescriptions() {
  if (!game.user.isGM || game.users.activeGM?.id !== game.user.id) return;
  const items = [...game.items, ...game.actors.flatMap((a) => [...a.items])];
  let n = 0;
  for (const item of items) {
    if (!(item.flags?.[MOD]?.modding?.installed ?? []).length) continue;
    const data = recompute(item.toObject());
    const upd = {};
    if (data.system.description !== item.system.description) upd["system.description"] = data.system.description;
    if (data.name !== item.name) upd.name = data.name;
    const mm = data.flags[MOD].modding, om = item.flags[MOD].modding;
    if (mm.autoName !== om.autoName || !!mm.nameLocked !== !!om.nameLocked) upd[`flags.${MOD}.modding`] = mm;
    if (Object.keys(upd).length) { await item.update(upd); n++; }
  }
  if (n) console.log(`Savage Fallout | refreshed mod notes on ${n} item(s)`);
}

// Station actors are visible (Limited) to everyone, so players can double-click the token.
Hooks.on("preCreateActor", (actor, data) => {
  if (!data.flags?.[MOD]?.station) return;
  actor.updateSource({ "ownership.default": CONST.DOCUMENT_OWNERSHIP_LEVELS.LIMITED, "flags.core.sheetClass": `${MOD}.WorkbenchStationSheet` });
});

// Token Controls toolbar button.
Hooks.on("getSceneControlButtons", (controls) => {
  const tool = { name: "sfWorkbench", title: "Workbench (Savage Fallout)", icon: "fas fa-hammer", button: true, visible: true, order: 50,
    onChange: () => openWorkbench({}), onClick: () => openWorkbench({}) };
  if (Array.isArray(controls)) controls.find((c) => c.name === "token")?.tools.push(tool);
  else { const t = controls.tokens ?? controls.token; if (t?.tools) t.tools.sfWorkbench = tool; }
});

// Character sheet menu entry. Registered as a real sheet action (no onClick), and guarded so a problem here can
// never break the sheet's own header buttons.
function openFromSheet() { openWorkbench({ actor: this.document }); }
Hooks.on("getHeaderControlsActorSheetV2", (app, controls) => {
  try {
    const a = app.document;
    if (!Array.isArray(controls) || !a?.isOwner || a.flags?.[MOD]?.station || !["character", "npc"].includes(a.type)) return;
    if (controls.some((c) => c?.action === "sfWorkbench")) return;
    const actions = app.options?.actions;
    if (!actions || Object.isFrozen(actions)) return;
    if (!actions.sfWorkbench) actions.sfWorkbench = openFromSheet;
    controls.push({ label: "Workbench", icon: "fa-solid fa-hammer", action: "sfWorkbench", visible: true });
  } catch (err) {
    console.error("Savage Fallout | couldn't add the Workbench sheet control", err);
  }
});

// Keep open workbenches in sync with inventory and Edge changes.
function refresh(doc) {
  const actor = doc?.documentName === "Token" ? doc.actor : (doc?.parent ?? doc);
  const app = actor && Workbench.instances.get(actor.uuid);
  if (app?.rendered) app.render();
}
for (const h of ["createItem", "updateItem", "deleteItem", "updateActor", "updateToken"]) Hooks.on(h, refresh);
